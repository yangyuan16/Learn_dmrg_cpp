#include<iostream>
using namespace std;
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<gsl/gsl_sf_coupling.h>

#include"common.h"
#include"sub.h"

//<J||T||J>=sqrt((2J+1)(J+1)J)
#define constant sqrt(6.0)*0.5	//spin-1/2
//#define constant sqrt(6.0)		//spin-1
//#define constant sqrt(15.0)		//spin-3/2
//#define constant sqrt(30.0)		//spin-2
//================================================================================================================
//The order of coupled basis is determined by Start[n_site][j_new], here "j_old" is ordered from small (j_new=j_ol//d+1/2) to large (j_new=j_old-1/2). Sometimes, only "j_old" small (j_new=j_old+1/2) exists.
//In this program, the order of angular momentum coupling is |J_old, J_n, J, M>, explicitly, |J_old, 1/2, J, M>.
//The order should not be changed in any place. In another order |1/2, J_old, J, M>, the matrix of the Hamiltonian//will have minus values of the elements in the off-diagonal blocks, which can be seen from the formula of expecta
//-tion value of <S_1*S_2> in the coupled basis. This can also be seen in the matrix of S_Dia and S_M_Dia.
//Therefore, there are two kinds of sequences that should be noticed in this part, the sequence of coupled basis
//and the sequence of angular momentum coupling!!!
//================================================================================================================

//================================================BLAS ROUTINES===================================================
extern "C" {
void dsymm_(char *side, char *uplo, const int *m, const int *n, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);

void dgemm_(char *transa, char *transb, const int *m, const int *n, const int *k, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);
}
//===============================================================================================================

//========================================Initialize system and environment blocks===============================
//      Initialize the system block: In this code, only a spin site in the initial step
//===============================================================================================================
Sub::Sub(Parameter &para):SubCommon() {
	IndexNo=0;

	TotSiteNo=1;    		//Start with only one spin site
	Sys_Number_Jn=1;        	//Sys_Number_Jn denotes the number of J

	CreateSpace1();
	Sys_Value_Jn[0]=para.S;      	//Sys_value_Jn=2*J
	Sys_SubBlockNumber_Jn[0]=1;     //Only one series of states with J

	operator_number=1;		//para.Table_sys[0]==para.Table_env[0]=1
	Create_H();
	Create_S_Dia();
	Create_S_M_Dia();

	S_Dia[0][0][0]=constant;	//cout<<"\n S_Dia="<<S_Dia[0][0][0]<<endl;
}

//==========================================Read in data from hard disks=========================================
//===========Read in space variables: TotSiteNo, Sys_Number_Jn, Sys_Value_Jn, Sys_SubBlockNumber_Jn
Sub::Sub(char *space, const int &i, const int &lsys):SubCommon("space", i, lsys) {}

//===========Read in operator variables: TotSiteNo, operator_number, Sys_Number_Jn, Sys_Value_Jn, Sys_SubBlockNumb//er_Jn, **H, ***S_Dia, ***S_M_Dia
Sub::Sub(const int &i, const int &lsys):SubCommon(i, lsys) {}
//===============================================================================================================

//===============================================================================================================
//                      	Add a new site or both Infite and Finite sweep:  sysnew=sys+n
//===============================================================================================================

//=====================================New space for both sysnew and envnew======================================
// The variables of this subroutine: TotSiteNo, IndexNo, Sys_Number_Jn, *Sys_Value_Jn, *Sys_SubBlockNumber_Jn.
//===============================================================================================================
Sub::Sub(const int &i, Parameter &para, Sub &old):SubCommon() {
	IndexNo=1;

	TotSiteNo=old.TotSiteNo+1;
	GetSysNumberJn(para, old);

        CreateSpace1();
        FindDim(para, old);

  //------Store the angular momentum magnitude for wave function transformation in class superenergy-------------
	FILE *fw=fopen(Combine(Combine("new_block/", i), TotSiteNo), "wb");//"i"=1 (2) stand for sys (env).
        fwrite(&Sys_Number_Jn, sizeof(int), 1, fw);
        fwrite(Sys_Value_Jn, sizeof(int), Sys_Number_Jn, fw);
        fwrite(Sys_SubBlockNumber_Jn, sizeof(int), Sys_Number_Jn, fw);

        for(int j=0; j<para.S+1; j++) {	//2J+1
                fwrite(IndexOld[j], sizeof(int), Sys_Number_Jn, fw);
                fwrite(Start[j], sizeof(int), Sys_Number_Jn, fw);
        }

        fclose(fw);

}

//===============================================================================================================
//				Reduced density matrix of system and environment
//===============================================================================================================
Sub::Sub(Sub &new_space):SubCommon() {
        IndexNo=4;

        TotSiteNo=new_space.TotSiteNo;
        Sys_Number_Jn=new_space.Sys_Number_Jn;

        CreateSpace1();

        for(int i=0; i<Sys_Number_Jn; i++) {
                Sys_Value_Jn[i]=new_space.Sys_Value_Jn[i];
                Sys_SubBlockNumber_Jn[i]=new_space.Sys_SubBlockNumber_Jn[i];
        }

        CreateSpace3();
}

//==========================================New operators for sysnew==============================================
// The variables of this subroutine: TotSiteNo, IndexNo, Sys_Number_Jn, Sys_Value_Jn, Sys_SubBlockNumber_Jn;
// operator_number, **H, ***S_Dia, ***S_M_Dia;
// **dm_wave_function, **dm_eigenvalues.
//================================================================================================================
Sub::Sub(char &sign, Parameter &para, Sub &sys, Sub &sysnew_space):SubCommon() {
	IndexNo=2;
	ope_sign=sign;

	TotSiteNo=sysnew_space.TotSiteNo;
	Sys_Number_Jn=sysnew_space.Sys_Number_Jn;

	CreateSpace1();

	for(int i=0; i<Sys_Number_Jn; i++) {
		Sys_Value_Jn[i]=sysnew_space.Sys_Value_Jn[i];	
		Sys_SubBlockNumber_Jn[i]=sysnew_space.Sys_SubBlockNumber_Jn[i];
	}

	operator_number=para.Table_sys[sys.TotSiteNo];	//sys.TotSiteNo==TotSiteNo-1

	if(ope_sign=='H') {
		Create_H();
	        NewH_Sys(para, sysnew_space, sys);
	}

	else if(ope_sign=='S') {
		Create_S_Dia();
	        NewS_Dia(1, para, sysnew_space, sys, para.Table_sys_site[sys.TotSiteNo-1], para.Table_sys_site[TotSiteNo-1]);
	}

	else if(ope_sign=='M') {
		Create_S_M_Dia();
	        NewS_M_Dia(1, para, sysnew_space, sys, para.Table_sys_site[sys.TotSiteNo-1], para.Table_sys_site[TotSiteNo-1]);
	}
}

//=========================================New operator for envnew===============================================
// The variables of this subroutine: IndexNo, TotSiteNo, Sys_Number_Jn, Sys_Value_Jn, Sys_SubBlockNumber_Jn;
// operator_number, **H, ***S_Dia, ***S_M_Dia;
// dm_wave_function, dm_eigenvalues.
//===============================================================================================================
Sub::Sub(char &sign, Sub &envnew_space, Sub &env, Parameter &para):SubCommon() {
	IndexNo=2;
	ope_sign=sign;

	TotSiteNo=envnew_space.TotSiteNo;
	Sys_Number_Jn=envnew_space.Sys_Number_Jn;

	CreateSpace1();

        for(int i=0; i<Sys_Number_Jn; i++) {
                Sys_Value_Jn[i]=envnew_space.Sys_Value_Jn[i];
                Sys_SubBlockNumber_Jn[i]=envnew_space.Sys_SubBlockNumber_Jn[i];
        }

	int totalsite=2*TotSiteNo;                              //Total site of sys+ns+ne+env
        for(int i=1; i<para.N_x; i++) {
                if((i+1)*para.N_u*para.N_y>=totalsite) {        //(i+1) is the number of column
                        StartSite=(i+1)*para.N_u*para.N_y-1;    //StartSite of the first site of envnew!!!
                        break;
                }
        }
       
	operator_number=para.Table_env[env.TotSiteNo];//env.TotSiteNo==TotSiteNo-1

        if(ope_sign=='H') {
                Create_H();
	        NewH_Env(para, envnew_space, env);
        }

        else if(ope_sign=='S') {
                Create_S_Dia();
	        NewS_Dia(2, para, envnew_space, env, para.Table_env_site[env.TotSiteNo-1], para.Table_env_site[TotSiteNo-1]);
        }

        else if(ope_sign=='M') {
                Create_S_M_Dia();
	        NewS_M_Dia(2, para, envnew_space, env, para.Table_env_site[env.TotSiteNo-1], para.Table_env_site[TotSiteNo-1]);
        }
}

//=================================New environment for Finite sweep===============================================
//                      Add a new site to environment for finite sweep,  envnew=env+n
//================================================================================================================
Sub::Sub(char &sign, char &f, Parameter &para, Sub &env, Sub &envnew_space):SubCommon() {
	IndexNo=2;
	ope_sign=sign;

	TotSiteNo=envnew_space.TotSiteNo;
	Sys_Number_Jn=envnew_space.Sys_Number_Jn;

        CreateSpace1();

        for(int i=0; i<Sys_Number_Jn; i++) {
                Sys_Value_Jn[i]=envnew_space.Sys_Value_Jn[i];
                Sys_SubBlockNumber_Jn[i]=envnew_space.Sys_SubBlockNumber_Jn[i];
        }

  //------Find the new operators---------------------------------------------------------------------------------
        StartSite=para.N-1;     //StartSite is alwasy the last site of the lattice!!!
	operator_number=para.Table_env[env.TotSiteNo];

        if(ope_sign=='H') {
                Create_H();
                NewH_Env(para, envnew_space, env);
        }

        else if(ope_sign=='S') {
                Create_S_Dia();
                NewS_Dia(2, para, envnew_space, env, para.Table_env_site[env.TotSiteNo-1], para.Table_env_site[TotSiteNo-1]);
        }

        else if(ope_sign=='M') {
                Create_S_M_Dia();
                NewS_M_Dia(2, para, envnew_space, env, para.Table_env_site[env.TotSiteNo-1], para.Table_env_site[TotSiteNo-1]);
        }
}

//==========================New system and environment for finite sweep without operators=========================//	New system and environment for finite sweep with only creating new Hilbert space, but not to create and
//  renew operators
//===============================================================================================================
Sub::Sub(Parameter &para, char *nooperator, Sub &old) {
	IndexNo=1;	//only part of createspace1() 

	TotSiteNo=old.TotSiteNo+1;
	GetSysNumberJn(para, old);

	CreateSpace1();
	FindDim(para, old);
}

//=============================================Get Sys_Number_Jn=================================================
inline void Sub::GetSysNumberJn(Parameter &para, Sub &old) {

        int J_min, J_max, J_num, index;
        int number=0;

        for(int i=0; i<old.Sys_Number_Jn; i++) {
                J_min=abs(old.Sys_Value_Jn[i]-para.S);
                J_max=old.Sys_Value_Jn[i]+para.S;
                J_num=(J_max-J_min)/2+1;

                number+=J_num;
        }

        int *S_Value=new int [number];
	int *S_new=new int [number];
	for(int i=0; i<number; i++) {
		S_Value[i]=0;	S_new[i]=0;
	}

	index=0;
        for(int i=0; i<old.Sys_Number_Jn; i++) {
                J_min=abs(old.Sys_Value_Jn[i]-para.S);	//cout<<"\n J_min="<<J_min;
                J_max=old.Sys_Value_Jn[i]+para.S;	//cout<<"\n J_max="<<J_max;
                J_num=(J_max-J_min)/2+1;		//cout<<"\n J_num="<<J_num;

                for(int j=0; j<J_num; j++)
                        S_Value[index+j]=J_min+2*j;

		index+=J_num;
        }

	index=1;
	S_new[0]=S_Value[0];

	for(int i=1; i<number; i++) {

		int count=0;
		for(int j=0; j<index; j++) {	
			if(S_Value[i]!=S_new[j])
				count++;
			else break;
		}

		if(count==index)
			S_new[index++]=S_Value[i];

	}

	Sys_Number_Jn=index;
	cout<<"\n Sys_Number_Jn="<<Sys_Number_Jn<<endl;

	delete [] S_Value;	delete [] S_new;
}

//================================================Find Dim=======================================================
//Find the matrix structure of sysnew:including the Sys_Number_Jn, Sys_SubBlockNumber_Jn, and Sys_Value_Jn
//===============================================================================================================
inline void Sub::FindDim(Parameter &para, Sub &old) {

        int J_min, J_max, J_num, index;
        int number=0;

        for(int i=0; i<old.Sys_Number_Jn; i++) {
                J_min=abs(old.Sys_Value_Jn[i]-para.S);
                J_max=old.Sys_Value_Jn[i]+para.S;
                J_num=(J_max-J_min)/2+1;

                number+=J_num;
        }

        int *S_Value=new int [number];
	int *S_old_num=new int [number];
	for(int i=0; i<number; i++) {
		S_Value[i]=0;	S_old_num[i]=0;
	}

	index=0;
        for(int i=0; i<old.Sys_Number_Jn; i++) {

                J_min=abs(old.Sys_Value_Jn[i]-para.S);	//cout<<"\n J_min="<<J_min;
                J_max=old.Sys_Value_Jn[i]+para.S;	//cout<<"\n J_max="<<J_max;
                J_num=(J_max-J_min)/2+1;		//cout<<"\n J_num="<<J_num;

                for(int j=0; j<J_num; j++) {

                        S_Value[index+j]=J_min+2*j;
			S_old_num[index+j]=i;

		}

		index+=J_num;

        }

	for(int i=0; i<number; i++)	//rearrange from small to large for both new and old spin
	for(int j=i+1; j<number; j++) {
		if(S_Value[i]>S_Value[j]) {
			int n=S_old_num[i];	S_old_num[i]=S_old_num[j];	S_old_num[j]=n;
			int m=S_Value[i];	S_Value[i]=S_Value[j];		S_Value[j]=m;
		}
		else if(S_Value[i]==S_Value[j] && S_old_num[i]>S_old_num[j]) {
			int n=S_old_num[i];     S_old_num[i]=S_old_num[j];      S_old_num[j]=n;
                        int m=S_Value[i];       S_Value[i]=S_Value[j];          S_Value[j]=m;
		}
	}

	index=0;	//Find Sys_Value_Jn, Sys_SubBlockNumber_Jn, IndexOld, and Start arrays
	Sys_Value_Jn[0]=S_Value[0];
	Sys_SubBlockNumber_Jn[0]+=old.Sys_SubBlockNumber_Jn[S_old_num[0]];
	for(int n=0; n<para.S+1; n++)
	if(S_Value[0]==old.Sys_Value_Jn[S_old_num[0]]+para.S-2*n) {	
		IndexOld[n][0]=S_old_num[0];	Start[n][0]=0;
	}

	for(int i=1; i<number; i++) {

		if(S_Value[i]!=S_Value[i-1]) {

			index++;
			Sys_Value_Jn[index]=S_Value[i];
			Sys_SubBlockNumber_Jn[index]+=old.Sys_SubBlockNumber_Jn[S_old_num[i]];
		
			for(int n=0; n<para.S+1; n++)
			if(S_Value[i]==old.Sys_Value_Jn[S_old_num[i]]+para.S-2*n) {	
				IndexOld[n][index]=S_old_num[i];	Start[n][index]=0;
			}

		}

		else if(S_Value[i]==S_Value[i-1]) {

			for(int n=0; n<para.S+1; n++)
			if(S_Value[i]==old.Sys_Value_Jn[S_old_num[i]]+para.S-2*n) {	
				IndexOld[n][index]=S_old_num[i];	Start[n][index]=Sys_SubBlockNumber_Jn[index];
			}

			Sys_SubBlockNumber_Jn[index]+=old.Sys_SubBlockNumber_Jn[S_old_num[i]];

		}

	}

	delete [] S_Value;	delete [] S_old_num;

//	for(int i=0; i<Sys_Number_Jn; i++)
//		cout<<"\n Sys_Value_Jn["<<i<<"]="<<Sys_Value_Jn[i]<<"\t Sys_SubBlockNumber["<<i<<"]="<<Sys_SubBlockNumber_Jn[i]<<endl;

//	for(int i=0; i<para.S+1; i++)
//	for(int j=0; j<Sys_Number_Jn; j++)
//		cout<<"\n IndexOld["<<i<<"]["<<j<<"]="<<IndexOld[i][j]<<"\t Start["<<i<<"]["<<j<<"]="<<Start[i][j];

}

//================================================================================================================
//================================================================================================================

//===============================================Subroutines=====================================================
//===============================================NewH_Sys========================================================
inline void Sub::NewH_Sys(Parameter &para, Sub &sysnew_space, Sub &sys) {
  //------Define the variables to use in this subroutine---------------------------------------------------------
	int oldJn, oldJm, a_sysnew, a_sysnew_t, position;
	int SiteNum=para.N*sys.TotSiteNo;//sys.TotSiteNo is the number of the new added site, to use in Table!
	double factor;

  //------Create the 6j coefficient------------------------------------------------------------------------------
	Create_6j_H(para, sys);

        FILE *fp=fopen(Combine(Combine("6j_factor/H/", 1),  sysnew_space.TotSiteNo), "wb");

        for(int i=0; i<sys.Sys_Number_Jn; i++)
        for(int j=0; j<sys.Sys_Number_Jn; j++)
                fwrite(six_j_H[i][j], sizeof(double), Sys_Number_Jn, fp);

        fclose(fp);

  //------NewH_Sys_Old-------------------------------------------------------------------------------------------
        for(int i=0; i<Sys_Number_Jn; i++)
        for(int n=0; n<para.S+1; n++)
        if((oldJn=sysnew_space.IndexOld[n][i])!=-1) {

                position=(Sys_SubBlockNumber_Jn[i]+1)*sysnew_space.Start[n][i];
		SubDim=sys.Sys_SubBlockNumber_Jn[oldJn]*sys.Sys_SubBlockNumber_Jn[oldJn];

                for(int a_sys=0; a_sys<SubDim; a_sys++) {
                        a_sysnew=position+Sys_SubBlockNumber_Jn[i]*(a_sys/sys.Sys_SubBlockNumber_Jn[oldJn])+a_sys%sys.Sys_SubBlockNumber_Jn[oldJn];			  
                        H[i][a_sysnew]+=sys.H[oldJn][a_sys];
                }
        }

  //------NewH_Sys_Old_N-----------------------------------------------------------------------------------------
        for(int site=0; site<sys.operator_number; site++) 
        if(para.Table[SiteNum+para.Table_sys_site[sys.TotSiteNo-1][site]]!=0) {

                for(int j=0; j<Sys_Number_Jn; j++)
                for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=sysnew_space.IndexOld[n][j])!=-1)
                if((oldJm=sysnew_space.IndexOld[m][j])!=-1) {

                        if(oldJn==oldJm && sys.Sys_Value_Jn[oldJn]!=0) {

                                position=(Sys_SubBlockNumber_Jn[j]+1)*sysnew_space.Start[n][j];
                                factor=para.Interaction[SiteNum+para.Table_sys_site[sys.TotSiteNo-1][site]]*pow(-1.0,(Sys_Value_Jn[j]+sys.Sys_Value_Jn[oldJn]+para.S)/2)*six_j_H[oldJn][oldJn][j]*constant;
				SubDim=sys.Sys_SubBlockNumber_Jn[oldJn]*sys.Sys_SubBlockNumber_Jn[oldJn];

                                for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                        a_sysnew=position+Sys_SubBlockNumber_Jn[j]*(a_sys/sys.Sys_SubBlockNumber_Jn[oldJn])+a_sys%sys.Sys_SubBlockNumber_Jn[oldJn];
                                        H[j][a_sysnew]+=factor*sys.S_Dia[site][oldJn][a_sys];
                                }
                        }

                        else if((oldJn+1)==oldJm && (sys.Sys_Value_Jn[oldJm]-sys.Sys_Value_Jn[oldJn])==2) {

                                position=Sys_SubBlockNumber_Jn[j]*sysnew_space.Start[m][j]+sysnew_space.Start[n][j];
                                factor=para.Interaction[SiteNum+para.Table_sys_site[sys.TotSiteNo-1][site]]*pow(-1.0,(Sys_Value_Jn[j]+sys.Sys_Value_Jn[oldJm]+para.S)/2)*six_j_H[oldJn][oldJm][j]*constant;
				SubDim=sys.Sys_SubBlockNumber_Jn[oldJn]*sys.Sys_SubBlockNumber_Jn[oldJm];

                                for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                        a_sysnew=position+Sys_SubBlockNumber_Jn[j]*(a_sys/sys.Sys_SubBlockNumber_Jn[oldJn])+a_sys%sys.Sys_SubBlockNumber_Jn[oldJn];
					a_sysnew_t=Sys_SubBlockNumber_Jn[j]*(a_sysnew%Sys_SubBlockNumber_Jn[j])+a_sysnew/Sys_SubBlockNumber_Jn[j];
                                        H[j][a_sysnew]+=factor*sys.S_M_Dia[site][oldJn][a_sys];
                                        H[j][a_sysnew_t]+=factor*sys.S_M_Dia[site][oldJn][a_sys];//transpose element of the Hamiltonian matrix. Hamiltonian matrix is a symmetric real matrix. For only system block here, the Hamiltonian matrix can be devided to "four" sub-blocks or just composed of "one" sub-block according to the quantum numbers, because the column- and row-indices are the same with each other. If not, the transpose element may not be directly calculated like this.
                                }
                        }
                }
        }

  //------Delete the 6j coefficient-------------------------------------------------------------------------------
	Delete_6j_H(sys);
}

//==============================================Create_6j_H======================================================
inline void Sub::Create_6j_H(Parameter &para, Sub &sys) {	//6j{J_1,n, J_n, J_1, 1, J_1_p, J_n}

	six_j_H=new double ** [sys.Sys_Number_Jn];
	for(int i=0; i<sys.Sys_Number_Jn; i++) {
		six_j_H[i]=new double * [sys.Sys_Number_Jn];
		for(int j=0; j<sys.Sys_Number_Jn; j++) {
			six_j_H[i][j]=new double [Sys_Number_Jn];
			for(int k=0; k<Sys_Number_Jn; k++) {
				six_j_H[i][j][k]=gsl_sf_coupling_6j(Sys_Value_Jn[k], para.S, sys.Sys_Value_Jn[i], 2, sys.Sys_Value_Jn[j], para.S);
			}
		} 
	}

}

//==============================================Delete_6j_H======================================================
inline void Sub::Delete_6j_H(Sub &sys) {
	for(int i=0; i<sys.Sys_Number_Jn; i++) {
		for(int j=0; j<sys.Sys_Number_Jn; j++) {
			delete [] six_j_H[i][j];
		}
	delete [] six_j_H[i];
	}
	delete [] six_j_H;
}

//===============================================NewH_Env========================================================
inline void Sub::NewH_Env(Parameter &para, Sub &envnew_space, Sub &env) {
  //------Define the variables to be used in this subroutine-----------------------------------------------------
	int SiteNum=para.N*(StartSite-env.TotSiteNo)+StartSite; //Table[ne][StartSite] of env+ne
	int oldJn, oldJm, a_envnew, a_envnew_t, position;
	double factor;

  //------Create the 6j coefficient------------------------------------------------------------------------------
	Create_6j_H(para, env);

        FILE *fp=fopen(Combine(Combine("6j_factor/H/", 2),  envnew_space.TotSiteNo), "wb");

        for(int i=0; i<env.Sys_Number_Jn; i++)
        for(int j=0; j<env.Sys_Number_Jn; j++)
                fwrite(six_j_H[i][j], sizeof(double), Sys_Number_Jn, fp);

        fclose(fp);

  //------NewH_Env_Old-------------------------------------------------------------------------------------------
        for(int i=0; i<Sys_Number_Jn; i++)
        for(int n=0; n<para.S+1; n++)
        if((oldJn=envnew_space.IndexOld[n][i])!=-1) {

                position=(Sys_SubBlockNumber_Jn[i]+1)*envnew_space.Start[n][i];
		SubDim=env.Sys_SubBlockNumber_Jn[oldJn]*env.Sys_SubBlockNumber_Jn[oldJn];

                for(int a_env=0; a_env<SubDim; a_env++) {
                        a_envnew=position+Sys_SubBlockNumber_Jn[i]*(a_env/env.Sys_SubBlockNumber_Jn[oldJn])+a_env%env.Sys_SubBlockNumber_Jn[oldJn];
                        H[i][a_envnew]+=env.H[oldJn][a_env];
                }
        }

  //------NewH_Env_Old_N------------------------------------------------------------------------------------------
	for(int site=0; site<env.operator_number; site++)
        if(para.Table[SiteNum-para.Table_env_site[env.TotSiteNo-1][site]]!=0) {

                for(int j=0; j<Sys_Number_Jn; j++)
                for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=envnew_space.IndexOld[n][j])!=-1)
                if((oldJm=envnew_space.IndexOld[m][j])!=-1) {

                        if(oldJn==oldJm && env.Sys_Value_Jn[oldJn]!=0) {

                                position=(Sys_SubBlockNumber_Jn[j]+1)*envnew_space.Start[n][j];
                                factor=para.Interaction[SiteNum-para.Table_env_site[env.TotSiteNo-1][site]]*pow(-1.0,(Sys_Value_Jn[j]+env.Sys_Value_Jn[oldJn]+para.S)/2)*six_j_H[oldJn][oldJn][j]*constant;
		                SubDim=env.Sys_SubBlockNumber_Jn[oldJn]*env.Sys_SubBlockNumber_Jn[oldJn];

                                for(int a_env=0; a_env<SubDim; a_env++) {
                                        a_envnew=position+Sys_SubBlockNumber_Jn[j]*(a_env/env.Sys_SubBlockNumber_Jn[oldJn])+a_env%env.Sys_SubBlockNumber_Jn[oldJn];
                                        H[j][a_envnew]+=factor*env.S_Dia[site][oldJn][a_env];
                                }
                        }

                        else if((oldJn+1)==oldJm && (env.Sys_Value_Jn[oldJm]-env.Sys_Value_Jn[oldJn])==2) {

                                position=Sys_SubBlockNumber_Jn[j]*envnew_space.Start[m][j]+envnew_space.Start[n][j];
                                factor=para.Interaction[SiteNum-para.Table_env_site[env.TotSiteNo-1][site]]*pow(-1.0,(Sys_Value_Jn[j]+env.Sys_Value_Jn[oldJm]+para.S)/2)*six_j_H[oldJn][oldJm][j]*constant;
		                SubDim=env.Sys_SubBlockNumber_Jn[oldJn]*env.Sys_SubBlockNumber_Jn[oldJm];

                                for(int a_env=0; a_env<SubDim; a_env++) {
                                        a_envnew=position+Sys_SubBlockNumber_Jn[j]*(a_env/env.Sys_SubBlockNumber_Jn[oldJn])+a_env%env.Sys_SubBlockNumber_Jn[oldJn];
					a_envnew_t=Sys_SubBlockNumber_Jn[j]*(a_envnew%Sys_SubBlockNumber_Jn[j])+a_envnew/Sys_SubBlockNumber_Jn[j];
                                        H[j][a_envnew]+=factor*env.S_M_Dia[site][oldJn][a_env];
					H[j][a_envnew_t]+=factor*env.S_M_Dia[site][oldJn][a_env];
                                }
                        }
                }
        }

  //------Delete the 6j coefficient-------------------------------------------------------------------------------
	Delete_6j_H(env);
}

//===================================================NewS_Dia=====================================================
//				  S_Dia matrix is also Hermitian matrix
//================================================================================================================
inline void Sub::NewS_Dia(const int &block, Parameter &para, Sub &space, Sub &old, int *table_old, int *table_new) {
  //------Define variables to use in this subroutine-------------------------------------------------------------
  	int oldJn, oldJm, position, a_new, a_new_t;
	double factor;

  //------Create_6j_S_Dia----------------------------------------------------------------------------------------
	double ***six_j_S_Dia;
 	six_j_S_Dia=new double ** [old.Sys_Number_Jn];
        for(int i=0; i<old.Sys_Number_Jn; i++) {
                six_j_S_Dia[i]=new double * [old.Sys_Number_Jn];
                for(int j=0; j<old.Sys_Number_Jn; j++) {
                        six_j_S_Dia[i][j]=new double [Sys_Number_Jn];
                        for(int k=0; k<Sys_Number_Jn; k++) {
                                six_j_S_Dia[i][j][k]=gsl_sf_coupling_6j(old.Sys_Value_Jn[i], Sys_Value_Jn[k], para.S, Sys_Value_Jn[k], old.Sys_Value_Jn[j], 2);
                        }
                }
        }

        FILE *fp=fopen(Combine(Combine("6j_factor/S_Dia_old/", block),  space.TotSiteNo), "wb");

        for(int i=0; i<old.Sys_Number_Jn; i++)
        for(int j=0; j<old.Sys_Number_Jn; j++)
                fwrite(six_j_S_Dia[i][j], sizeof(double), Sys_Number_Jn, fp);

        fclose(fp);

  //------Create_6j_S_Dia_N---------------------------------------------------------------------------------------
	double **six_j_S_Dia_N;
	six_j_S_Dia_N=new double * [Sys_Number_Jn];
        for(int i=0; i<Sys_Number_Jn; i++) {
                six_j_S_Dia_N[i]=new double [old.Sys_Number_Jn];
                for(int j=0; j<old.Sys_Number_Jn; j++) {
                        six_j_S_Dia_N[i][j]=gsl_sf_coupling_6j(para.S, Sys_Value_Jn[i], old.Sys_Value_Jn[j], Sys_Value_Jn[i], para.S, 2);
                }
        }

        FILE *fr=fopen(Combine(Combine("6j_factor/S_Dia_n/", block), space.TotSiteNo), "wb");

        for(int i=0; i<Sys_Number_Jn; i++)
                fwrite(six_j_S_Dia_N[i], sizeof(double), old.Sys_Number_Jn, fr);

        fclose(fr);

  //------NewS_Dia-----------------------------------------------------------------------------------------------
        for(int site=0; site<operator_number; site++) {

		for(int site_old=0; site_old<old.operator_number; site_old++)
		if(table_old[site_old]==table_new[site]) {

                	for(int j=0; j<Sys_Number_Jn; j++)
			if(Sys_Value_Jn[j]!=0) {
                		for(int n=0; n<para.S+1; n++)
                		for(int m=0; m<para.S+1; m++)
                		if((oldJn=space.IndexOld[n][j])!=-1 && (oldJm=space.IndexOld[m][j])!=-1) {
                        		if(oldJn==oldJm && old.Sys_Value_Jn[oldJn]!=0) {//constraints of 6j coefficient
                                		position=(Sys_SubBlockNumber_Jn[j]+1)*space.Start[n][j];
                                		factor=pow(-1.0, (old.Sys_Value_Jn[oldJn]+Sys_Value_Jn[j]+2+para.S)/2)*(Sys_Value_Jn[j]+1.0)*six_j_S_Dia[oldJn][oldJm][j];
				                SubDim=old.Sys_SubBlockNumber_Jn[oldJn]*old.Sys_SubBlockNumber_Jn[oldJn];

                                		for(int a_old=0; a_old<SubDim; a_old++) {
                                        		a_new=position+Sys_SubBlockNumber_Jn[j]*(a_old/old.Sys_SubBlockNumber_Jn[oldJn])+a_old%old.Sys_SubBlockNumber_Jn[oldJn];
                                        		S_Dia[site][j][a_new]+=factor*old.S_Dia[site_old][oldJn][a_old];
                                		}
                        		}

                        		else if((oldJm-oldJn)==1 && (old.Sys_Value_Jn[oldJm]-old.Sys_Value_Jn[oldJn])==2) {
 
	                               		position=Sys_SubBlockNumber_Jn[j]*space.Start[m][j]+space.Start[n][j];
                                		factor=pow(-1.0, (old.Sys_Value_Jn[oldJn]+Sys_Value_Jn[j]+2+para.S)/2)*(Sys_Value_Jn[j]+1.0)*six_j_S_Dia[oldJn][oldJm][j];
				                SubDim=old.Sys_SubBlockNumber_Jn[oldJn]*old.Sys_SubBlockNumber_Jn[oldJm];

                                		for(int a_old=0; a_old<SubDim; a_old++) {
                                        		a_new=position+Sys_SubBlockNumber_Jn[j]*(a_old/old.Sys_SubBlockNumber_Jn[oldJn])+a_old%old.Sys_SubBlockNumber_Jn[oldJn];
                                        		a_new_t=Sys_SubBlockNumber_Jn[j]*(a_new%Sys_SubBlockNumber_Jn[j])+a_new/Sys_SubBlockNumber_Jn[j];
                                        		S_Dia[site][j][a_new]+=factor*old.S_M_Dia[site_old][oldJn][a_old];
                                        		S_Dia[site][j][a_new_t]+=factor*old.S_M_Dia[site_old][oldJn][a_old];	//Hermitian conjugate
                                		}
                        		}
                		}
			}
        	}

		if(table_new[site]==TotSiteNo-1) { 
        		for(int j=0; j<Sys_Number_Jn; j++)
			if(Sys_Value_Jn[j]!=0) {
        			for(int n=0; n<para.S+1; n++)
        			if((oldJn=space.IndexOld[n][j])!=-1) {
                			position=Sys_SubBlockNumber_Jn[j]+1;
                			factor=pow(-1.0, (Sys_Value_Jn[j]+old.Sys_Value_Jn[oldJn]+2+para.S)/2)*(Sys_Value_Jn[j]+1.0)*six_j_S_Dia_N[j][oldJn]*constant;
                			for(int a_old=0; a_old<old.Sys_SubBlockNumber_Jn[oldJn]; a_old++) {//only the diagonal items are nonzero!!!
                        			a_new=position*(space.Start[n][j]+a_old);
                        			S_Dia[site][j][a_new]+=factor;
                			}
				}
        		}
		}

	}

  //------Delete_6j_S_Dia-----------------------------------------------------------------------------------------
 	for(int i=0; i<old.Sys_Number_Jn; i++) {
                for(int j=0; j<old.Sys_Number_Jn; j++) {
                        delete [] six_j_S_Dia[i][j];
                }
        delete [] six_j_S_Dia[i];
        }
        delete [] six_j_S_Dia;

  //------Delete_6j_S_Dia_N--------------------------------------------------------------------------------------
  	for(int i=0; i<Sys_Number_Jn; i++)
                delete [] six_j_S_Dia_N[i];
        delete [] six_j_S_Dia_N;

}

//===================================================NewS_M_Dia===================================================
inline void Sub::NewS_M_Dia(const int &block, Parameter &para, Sub &space, Sub &old, int *table_old, int *table_new) {
  //------Define variables to use in this subroutine-------------------------------------------------------------
  	int oldJn, oldJm, position, a_new;
        double factor;

  //------Create_6j_S_M_Dia--------------------------------------------------------------------------------------
  	double ***six_j_S_M_Dia;
	six_j_S_M_Dia=new double ** [old.Sys_Number_Jn];
        for(int i=0; i<old.Sys_Number_Jn; i++) {
                six_j_S_M_Dia[i]=new double * [old.Sys_Number_Jn];
                for(int j=0; j<old.Sys_Number_Jn; j++) {
                        six_j_S_M_Dia[i][j]=new double [Sys_Number_Jn-1];
                        for(int k=0; k<Sys_Number_Jn-1; k++) {
                                six_j_S_M_Dia[i][j][k]=gsl_sf_coupling_6j(old.Sys_Value_Jn[i], Sys_Value_Jn[k], para.S, Sys_Value_Jn[k+1], old.Sys_Value_Jn[j], 2);
                        }
                }
        }

        FILE *fp=fopen(Combine(Combine("6j_factor/S_M_Dia_old/", block), space.TotSiteNo), "wb");

        for(int i=0; i<old.Sys_Number_Jn; i++)
        for(int j=0; j<old.Sys_Number_Jn; j++)
                fwrite(six_j_S_M_Dia[i][j], sizeof(double), Sys_Number_Jn-1, fp);

        fclose(fp);

  //------Create_6j_S_M_Dia_N------------------------------------------------------------------------------------
  	double **six_j_S_M_Dia_N;
  	six_j_S_M_Dia_N=new double * [Sys_Number_Jn-1];
        for(int i=0; i<Sys_Number_Jn-1; i++) {
                six_j_S_M_Dia_N[i]=new double [old.Sys_Number_Jn];
                for(int j=0; j<old.Sys_Number_Jn; j++) {
                        six_j_S_M_Dia_N[i][j]=gsl_sf_coupling_6j(para.S, Sys_Value_Jn[i], old.Sys_Value_Jn[j], Sys_Value_Jn[i+1], para.S, 2);
                }
        }

        FILE *fr=fopen(Combine(Combine("6j_factor/S_M_Dia_n/", block), space.TotSiteNo), "wb");

        for(int i=0; i<Sys_Number_Jn-1; i++)
                fwrite(six_j_S_M_Dia_N[i], sizeof(double), old.Sys_Number_Jn, fr);

        fclose(fr);

  //------NewS_M_Dia_Old-----------------------------------------------------------------------------------------
        for(int site=0; site<operator_number; site++) {
		for(int site_old=0; site_old<old.operator_number; site_old++)
		if(table_old[site_old]==table_new[site]) {
                	for(int j=0; j<Sys_Number_Jn-1; j++)
                	if((Sys_Value_Jn[j+1]-Sys_Value_Jn[j])==2) {
                        	for(int n=0; n<para.S+1; n++)
                        	for(int m=0; m<para.S+1; m++)
                        	if((oldJn=space.IndexOld[n][j])!=-1 && (oldJm=space.IndexOld[m][j+1])!=-1) {

                                	if(oldJn==oldJm && old.Sys_Value_Jn[oldJn]!=0) {

                                        	position=Sys_SubBlockNumber_Jn[j]*space.Start[m][j+1]+space.Start[n][j];
                                        	factor=pow(-1.0, (old.Sys_Value_Jn[oldJn]+Sys_Value_Jn[j+1]+2+para.S)/2)*sqrt((Sys_Value_Jn[j]+1.0)*(Sys_Value_Jn[j+1]+1.0))*six_j_S_M_Dia[oldJn][oldJm][j];
				                SubDim=old.Sys_SubBlockNumber_Jn[oldJn]*old.Sys_SubBlockNumber_Jn[oldJn];

                                        	for(int a_old=0; a_old<SubDim; a_old++) {
                                                	a_new=position+Sys_SubBlockNumber_Jn[j]*(a_old/old.Sys_SubBlockNumber_Jn[oldJn])+a_old%old.Sys_SubBlockNumber_Jn[oldJn];
                                                	S_M_Dia[site][j][a_new]+=factor*old.S_Dia[site_old][oldJn][a_old];
                                        	}
                                	}

                                	else if((oldJn-oldJm)==1 && (old.Sys_Value_Jn[oldJn]-old.Sys_Value_Jn[oldJm])==2) {
 
	                                       	position=Sys_SubBlockNumber_Jn[j]*space.Start[m][j+1]+space.Start[n][j];
                                        	factor=-pow(-1.0, (old.Sys_Value_Jn[oldJn]+Sys_Value_Jn[j+1]+2+para.S)/2)*sqrt((Sys_Value_Jn[j]+1.0)*(Sys_Value_Jn[j+1]+1.0))*six_j_S_M_Dia[oldJn][oldJm][j];
				                SubDim=old.Sys_SubBlockNumber_Jn[oldJn]*old.Sys_SubBlockNumber_Jn[oldJm];

                                        	for(int a_old=0; a_old<SubDim; a_old++) {
                                                	a_new=position+Sys_SubBlockNumber_Jn[j]*(a_old%old.Sys_SubBlockNumber_Jn[oldJm])+a_old/old.Sys_SubBlockNumber_Jn[oldJm];
							S_M_Dia[site][j][a_new]+=factor*old.S_M_Dia[site_old][oldJm][a_old];
                                        	}
                                	}

                                	else if((oldJm-oldJn)==1 && (old.Sys_Value_Jn[oldJm]-old.Sys_Value_Jn[oldJn])==2) {

                                        	position=Sys_SubBlockNumber_Jn[j]*space.Start[m][j+1]+space.Start[n][j];
                                        	factor=pow(-1.0, (old.Sys_Value_Jn[oldJn]+Sys_Value_Jn[j+1]+2+para.S)/2)*sqrt((Sys_Value_Jn[j]+1.0)*(Sys_Value_Jn[j+1]+1.0))*six_j_S_M_Dia[oldJn][oldJm][j];
                                                SubDim=old.Sys_SubBlockNumber_Jn[oldJn]*old.Sys_SubBlockNumber_Jn[oldJm];

                                        	for(int a_old=0; a_old<SubDim; a_old++) {
                                                	a_new=position+Sys_SubBlockNumber_Jn[j]*(a_old/old.Sys_SubBlockNumber_Jn[oldJn])+a_old%old.Sys_SubBlockNumber_Jn[oldJn];
                                                	S_M_Dia[site][j][a_new]+=factor*old.S_M_Dia[site_old][oldJn][a_old];
                                        	}
                                	}
                        	}
                	}
        	}

		if(table_new[site]==TotSiteNo-1) {
        		for(int j=0; j<Sys_Number_Jn-1; j++)
        		if((Sys_Value_Jn[j+1]-Sys_Value_Jn[j])==2) {
                		for(int n=0; n<para.S+1; n++)
                		for(int m=0; m<para.S+1; m++) {
                       			if((oldJn=space.IndexOld[n][j])!=-1 && (oldJm=space.IndexOld[m][j+1])!=-1)
					if(oldJn==oldJm) {
                                		position=Sys_SubBlockNumber_Jn[j]*space.Start[m][j+1]+space.Start[n][j];
                                		factor=pow(-1.0, (old.Sys_Value_Jn[oldJn]+Sys_Value_Jn[j]+para.S+2)/2)*sqrt((Sys_Value_Jn[j]+1.0)*(Sys_Value_Jn[j+1]+1.0))*six_j_S_M_Dia_N[j][oldJn]*constant;
                                		for(int a_old=0; a_old<old.Sys_SubBlockNumber_Jn[oldJn]; a_old++) {
                                        		a_new=position+(Sys_SubBlockNumber_Jn[j]+1)*a_old;
                                        		S_M_Dia[site][j][a_new]+=factor;
                                		}
                        		}
                		}
        		}
		}

	}

  //------Delete_6j_S_M_Dia--------------------------------------------------------------------------------------
  	for(int i=0; i<old.Sys_Number_Jn; i++) {
                for(int j=0; j<old.Sys_Number_Jn; j++) {
                        delete [] six_j_S_M_Dia[i][j];
                }
        delete [] six_j_S_M_Dia[i];
        }
        delete [] six_j_S_M_Dia;

  //------Delete_6j_S_M_Dia_N------------------------------------------------------------------------------------
 	for(int i=0; i<Sys_Number_Jn-1; i++)
                delete [] six_j_S_M_Dia_N[i];
        delete [] six_j_S_M_Dia_N;
}

//===============================================================================================================
//===============================================================================================================
//===============================================================================================================
//                             Truncate and renew the operators in infinite sweep
//===============================================================================================================
Sub::Sub(Parameter &para, Sub &density):SubCommon() {
	IndexNo=3;	//only CreateSpace1();

        TotSiteNo=density.TotSiteNo;

        Truncate(para, density, para.StateNoKept);

	if (mmin<para.StateNoKept)	para.untruncated_site++;//count the number of untruncated sites!!!
	cout<<"\n para.untruncated_site="<<para.untruncated_site<<endl;

//	delete [] OldSub;
}

//===============================================================================================================
Sub::Sub(Parameter &para, char &sign, Sub &density, Sub &trun_space, Sub &old) {
	IndexNo=2;		//IndexNo!=1
	ope_sign=sign;

        trans_N='N';    trans_T='T';
        alpha=1.0;      beta=0.0;

	TotSiteNo=trun_space.TotSiteNo;
	operator_number=old.operator_number;

	Sys_Number_Jn=trun_space.Sys_Number_Jn;

	CreateSpace1();
	OldSub=new int [Sys_Number_Jn];

	for(int i=0; i<Sys_Number_Jn; i++) {
		Sys_Value_Jn[i]=trun_space.Sys_Value_Jn[i];
		Sys_SubBlockNumber_Jn[i]=trun_space.Sys_SubBlockNumber_Jn[i];
		OldSub[i]=trun_space.OldSub[i];
	}

	if(ope_sign=='H') {
		Create_H();
		NewH(density, old);
	}

	else if(ope_sign=='S') {
		Create_S_Dia();
		NewS_Dia(density, old);
	}

	else if(ope_sign=='M') {
		Create_S_M_Dia();
		NewS_M_Dia(density, old);
	}

	delete [] OldSub;
}

//===============================================================================================================
//===============================================================================================================
//				Truncate and renew operators in finite sweep
//===============================================================================================================
Sub::Sub(Parameter &para, Sub &density, const int &optimalstate):SubCommon() {
	IndexNo=3;

        TotSiteNo=density.TotSiteNo;

        Truncate(para, density, optimalstate);

//	delete [] OldSub;
}

//===============================================================================================================
//              		Truncate:Relocate the good quantum numbers
//===============================================================================================================
inline void Sub::Truncate(Parameter &para, Sub &old, const int &optimalstate) {
        int i, j, m=0, TotStateNo=0;
        for(i=0; i<old.Sys_Number_Jn; i++)
                TotStateNo+=old.Sys_SubBlockNumber_Jn[i];    //total number of the untruncated basis

        int *Dim2=new int [old.Sys_Number_Jn];
        int *N_i=new int [TotStateNo];
        double *N_e=new double [TotStateNo];

        for(i=0; i<old.Sys_Number_Jn; i++) {
                Dim2[i]=0;
                for(j=0; j<old.Sys_SubBlockNumber_Jn[i]; j++) {
                        N_i[m]=i;                            //N_i record the J number of the states
                        N_e[m++]=old.dm_eig[i][j];           //N_e record the eigenvalues of the states
                }
        }

        for(i=0; i<TotStateNo; i++)
        for(j=i+1; j<TotStateNo; j++) {
                if(N_e[i]<N_e[j]) {
                        int n=N_i[i];  N_i[i]=N_i[j];  N_i[j]=n;
                        double e=N_e[i];  N_e[i]=N_e[j];  N_e[j]=e;
                }
        }   // rearrange from big to small

	mmin=(m>optimalstate ? optimalstate : m );

        double trunc_error=1.0;
        for(i=0; i<mmin; i++) {
                ++(Dim2[N_i[i]]);       //find the numbers of the new basis with certain J number
                trunc_error-=N_e[i]*(old.Sys_Value_Jn[N_i[i]]+1.0);
        }
	cout<<"\n Truncation Error="<<trunc_error<<endl;
	FILE *LOG=fopen("LOG", "a+");
	fprintf(LOG, "Truncation Error is %f\n", trunc_error);
        fprintf(LOG, "\n\n");
        fclose(LOG);

        Sys_Number_Jn=0;
        for(i=0; i<old.Sys_Number_Jn; i++) {
                if(Dim2[i]!=0)  ++Sys_Number_Jn;
        }

        CreateSpace1();

        OldSub=new int [Sys_Number_Jn];
        for(i=0, m=0; i<old.Sys_Number_Jn; i++) {
                if(Dim2[i]!=0) {
                        Sys_Value_Jn[m]=old.Sys_Value_Jn[i];
                        Sys_SubBlockNumber_Jn[m]=Dim2[i];
                        OldSub[m++]=i;
                }
        }

        delete [] Dim2;
        delete [] N_i;
    	delete [] N_e;
}

//================================================================================================================
//						Truncate and renew H
//================================================================================================================
inline void Sub::NewH(Sub &density, Sub &old) {
//------------------------------------Matrix-Matrix multiplication by BLAS routine dgemm-------------------------
	for(int i=0; i<Sys_Number_Jn; i++) {
		SubDim=old.Sys_SubBlockNumber_Jn[OldSub[i]]*Sys_SubBlockNumber_Jn[i];//Dim of middle matrix
	
		double * f_sub=new double [SubDim];	
		for(int j=0; j<SubDim; j++)	f_sub[j]=(double) 0;

		dgemm_(&trans_N, &trans_N, &old.Sys_SubBlockNumber_Jn[OldSub[i]], &Sys_SubBlockNumber_Jn[i], &old.Sys_SubBlockNumber_Jn[OldSub[i]], &alpha, old.H[OldSub[i]], &old.Sys_SubBlockNumber_Jn[OldSub[i]], density.dm_wave[OldSub[i]], &old.Sys_SubBlockNumber_Jn[OldSub[i]], &beta, f_sub, &old.Sys_SubBlockNumber_Jn[OldSub[i]]);

		dgemm_(&trans_T, &trans_N, &Sys_SubBlockNumber_Jn[i], &Sys_SubBlockNumber_Jn[i], &old.Sys_SubBlockNumber_Jn[OldSub[i]], &alpha, density.dm_wave[OldSub[i]], &old.Sys_SubBlockNumber_Jn[OldSub[i]], f_sub, &old.Sys_SubBlockNumber_Jn[OldSub[i]], &beta, H[i], &Sys_SubBlockNumber_Jn[i]);

		delete [] f_sub;
	}
}

//================================================================================================================
//      				Truncate and renew the S_Dia
//================================================================================================================
inline void Sub::NewS_Dia(Sub &density, Sub &old) {
//-------------------------------Matrix-Matrix multiplication by BLAS routine dgemm------------------------------
	for(int site=0; site<operator_number; site++) {
		for(int i=0; i<Sys_Number_Jn; i++) {
			SubDim=old.Sys_SubBlockNumber_Jn[OldSub[i]]*Sys_SubBlockNumber_Jn[i];

                	double * f_sub=new double [SubDim];
       	        	for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                	dgemm_(&trans_N, &trans_N, &old.Sys_SubBlockNumber_Jn[OldSub[i]], &Sys_SubBlockNumber_Jn[i], &old.Sys_SubBlockNumber_Jn[OldSub[i]], &alpha, old.S_Dia[site][OldSub[i]], &old.Sys_SubBlockNumber_Jn[OldSub[i]], density.dm_wave[OldSub[i]], &old.Sys_SubBlockNumber_Jn[OldSub[i]], &beta, f_sub, &old.Sys_SubBlockNumber_Jn[OldSub[i]]);

                	dgemm_(&trans_T, &trans_N, &Sys_SubBlockNumber_Jn[i], &Sys_SubBlockNumber_Jn[i], &old.Sys_SubBlockNumber_Jn[OldSub[i]], &alpha, density.dm_wave[OldSub[i]], &old.Sys_SubBlockNumber_Jn[OldSub[i]], f_sub, &old.Sys_SubBlockNumber_Jn[OldSub[i]], &beta, S_Dia[site][i], &Sys_SubBlockNumber_Jn[i]);

                	delete [] f_sub;
		}
	}
}

//================================================================================================================
//     		 			Truncate and renew the S_M_Dia
//================================================================================================================
inline void Sub::NewS_M_Dia(Sub &density, Sub &old) {
//-----------------------------Matrix-Matrix multiplication by BLAS routine dgemm--------------------------------
	int Sys_Number=Sys_Number_Jn-1;

	for(int site=0; site<operator_number; site++) {
		for(int i=0; i<Sys_Number; i++)
		if((Sys_Value_Jn[i+1]-Sys_Value_Jn[i])==2 && (old.Sys_Value_Jn[OldSub[i+1]]-old.Sys_Value_Jn[OldSub[i]])==2) {
			SubDim=old.Sys_SubBlockNumber_Jn[OldSub[i]]*Sys_SubBlockNumber_Jn[i+1];

                        double * f_sub=new double [SubDim];
                        for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                        dgemm_(&trans_N, &trans_N, &old.Sys_SubBlockNumber_Jn[OldSub[i]], &Sys_SubBlockNumber_Jn[i+1], &old.Sys_SubBlockNumber_Jn[OldSub[i+1]], &alpha, old.S_M_Dia[site][OldSub[i]], &old.Sys_SubBlockNumber_Jn[OldSub[i]], density.dm_wave[OldSub[i+1]], &old.Sys_SubBlockNumber_Jn[OldSub[i+1]], &beta, f_sub, &old.Sys_SubBlockNumber_Jn[OldSub[i]]);

                        dgemm_(&trans_T, &trans_N, &Sys_SubBlockNumber_Jn[i], &Sys_SubBlockNumber_Jn[i+1], &old.Sys_SubBlockNumber_Jn[OldSub[i]], &alpha, density.dm_wave[OldSub[i]], &old.Sys_SubBlockNumber_Jn[OldSub[i]], f_sub, &old.Sys_SubBlockNumber_Jn[OldSub[i]], &beta, S_M_Dia[site][i], &Sys_SubBlockNumber_Jn[i]);

                        delete [] f_sub;
		}
	}
}

//==========================Delete the Sub class: the delete program is in the class SubCommon===================
Sub::~Sub() {}
//======================================================END=======================================================
