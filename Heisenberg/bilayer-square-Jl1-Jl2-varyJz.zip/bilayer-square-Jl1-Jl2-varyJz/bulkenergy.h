class BulkEnergy {

public:

	BulkEnergy(const int &lsys, Parameter &para, Super &sup);
        ~BulkEnergy();

private:

	char trans_N, trans_T, side_R, side_L, uplo;
	double alpha, beta;

  //----Create spaces for matrices and functions
	double *correlation_function;

	double **WaveFunction_block;
	double **WaveFunction_config_2;
	double **WaveFunction_config_3;

	inline void CreateSpace(const int &lsys, Parameter &para);

	inline void CreateFunction(Super &sup);

	inline void DeleteSpace(const int &lsys, Parameter &para);

	inline void DeleteFunction(Super &sup);

	//------A_N-matrices
	int *A_N_Sys_Number_Jn;
	int **A_N_Sys_Value_Jn;
	int **A_N_Sys_SubBlockNumber_Jn;
	int ***A_N_IndexOld;
	int ***A_N_Start;

	double ****A_six_j_S_Dia_old;
        double ***A_six_j_S_Dia_n;
        double ****A_six_j_S_M_Dia_old;
        double ***A_six_j_S_M_Dia_n;
	double ****A_six_j_H;

	//------B_N-matrices
	int *B_N_Sys_Number_Jn;
	int **B_N_Sys_Value_Jn;
	int **B_N_Sys_SubBlockNumber_Jn;
	int ***B_N_IndexOld;
	int ***B_N_Start;

	double ****B_six_j_S_Dia_old;
        double ***B_six_j_S_Dia_n;
        double ****B_six_j_S_M_Dia_old;
        double ***B_six_j_S_M_Dia_n;
	double ****B_six_j_H;

	//------A-matrices
	int *A_Sys_Number_Jn;
	int **A_Sys_Value_Jn;
	int **A_Sys_SubBlockNumber_Jn;
	int **A_density_dim;
	int **A_OldSub;
	double ***A;

	//------B-matrices
	int *B_Sys_Number_Jn;
	int **B_Sys_Value_Jn;
	int **B_Sys_SubBlockNumber_Jn;
	int **B_density_dim;
	int **B_OldSub;
	double ***B;

	inline void Correlation_sys(const int &lsys, Parameter &para, Super &sup);
	inline void Correlation_env(const int &lsys, Parameter &para, Super &sup);
	inline void Correlation_ns_ne(const int &lsys, Parameter &para, Super &sup);
	inline void Correlation_sys_env_memory(const int &lsys, Parameter &para, Super &sup);
        inline void Correlation_sys_env_cpu(const int &lsys, Parameter &para, Super &sup);

	double **Si_Dia_old_A, **Si_M_Dia_old_A, **Si_Dia_new_A, **Si_M_Dia_new_A;
        double **Si_Dia_old_B, **Si_M_Dia_old_B, **Si_Dia_new_B, **Si_M_Dia_new_B;

	inline void New_A_Si_initial(const int &n_num, Parameter &para);
	inline void New_B_Si_initial(const int &n_num, Parameter &para);

	inline void New_A_Si_new(const int &n_num, Parameter &para);
	inline void New_B_Si_new(const int &n_num, Parameter &para);

	inline void Truncate_A_Si(const int &n_num);
	inline void Truncate_B_Si(const int &n_num);

	double **SiSj_old_A, **SiSj_new_A;
	double **SiSj_old_B, **SiSj_new_B;

	inline void Initial_A_SiSj(const int &n_num, Parameter &para);
	inline void Initial_B_SiSj(const int &n_num, Parameter &para);

	inline void New_A_SiSj(const int &n_num, Parameter &para);
	inline void New_B_SiSj(const int &n_num, Parameter &para);

	inline void Truncate_A_SiSj(const int &n_num);
	inline void Truncate_B_SiSj(const int &n_num);

	inline void Print(Parameter &para);
};
