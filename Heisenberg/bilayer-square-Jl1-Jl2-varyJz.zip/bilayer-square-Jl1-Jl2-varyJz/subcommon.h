class SubCommon {
public:
	SubCommon();					//Initialize the system and environment
	
	SubCommon(char *space, const int &i, const int &lsys);	//Read angular space from hard disk
	SubCommon(const int &i, const int &lsys);	//Read operators from hard disk
	
  //------Initialize blocks
  	int IndexNo;
	int TotSiteNo;          	//Total site numbers of the spins
        int Sys_Number_Jn;      	//The number of angular momentum number J of the system block

        void CreateSpace1();
        int *Sys_Value_Jn;      	//Sys_Value_Jn=2*Jn
        int *Sys_SubBlockNumber_Jn;	//The number of the angular momentum with the same J
        int **IndexOld;
        int **Start;

	void Create_H();
	void Create_S_Dia();
	void Create_S_M_Dia();
	char ope_sign;
	int operator_number;		//Number of sites that operators need to be stored
	double **H;			//Hamiltonian of system and environment blocks
	double ***S_Dia;        	//matrix of the irreducible matrix element Sn in the diagonal blocks
	double ***S_M_Dia;      	//matrix of the irreducible matrix element Sn in the minor diagonal blocks

	void CreateSpace3();		//Create space for truncation
	double **dm_eig;
	double **dm_wave;

	int *OldSub;

  //------Save to disk
	void Print_space(const int &i, const int &lsys);
	void Print_operator_H(const int &i, const int &lsys);
	void Print_operator_S_Dia(const int &i, const int &lsys);
	void Print_operator_S_M_Dia(const int &i, const int &lsys);

  //------Delete SubCommon functions
	~SubCommon();			//Delete the SubCommon functions!!!

private:

	inline void FreeSpace_H();                     
	inline void FreeSpace_S_Dia();
	inline void FreeSpace_S_M_Dia();
 
	inline void FreeSpace1();                      
};
