#include<iostream>
using namespace std;
#include<math.h>
#include<time.h>
#include<assert.h>
#include<stdlib.h>
#include<stdio.h>
#include<mkl.h>
#include<gsl/gsl_sf_coupling.h>

#include"sub.h"
#include"super.h"
#include"common.h"

//<J||T||J>=sqrt((2J+1)(J+1)J)
#define constant sqrt(6.0)*0.5        //spin-1/2
//#define constant sqrt(6.0)            //spin-1
//#define constant sqrt(15.0)             //spin-3/2
//#define constant sqrt(30.0)           //spin-2

//===============================================BLAS ROUTINES===================================================
extern "C" {
void daxpy_(const int *n, const double *alpha, double *x, const int *incx, double *y, const int *incy);

void dsymm_(char *side, char *uplo, const int *m, const int *n, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);

void dgemm_(char *transa, char *transb, const int *m, const int *n, const int *k, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);
}
//===============================================================================================================

//========================Constructe the subspace with given quantum number for Infinite sweep====================
Super::Super(Parameter &para, Sub *sys_space1, Sub *env_space1, Sub *sysnew_space1, Sub *envnew_space1) {
	destruct='s';	//"s" stands for creating space for block

	sys_space=sys_space1;
	env_space=env_space1;
        sysnew_space=sysnew_space1;
	envnew_space=envnew_space1;

        if( (sys_space->TotSiteNo+env_space->TotSiteNo+2) < para.Total_j )
                QuantumNumber=(sys_space->TotSiteNo+env_space->TotSiteNo+2);

        else  QuantumNumber=para.Total_j;

	AllocateBlockNumber(para);
}

//=================================Allocate Block Number for TargetSpin==========================================
// Find the Hibert space for the TargetSpin and allocate space to store the variables to mark the spaces for conf
// -igurations 1 and 2!!! Configuration 1: (sys+ns & env+ne); Configuration 2: (sys+ne & env+ns)!!!
//===============================================================================================================
inline void Super::AllocateBlockNumber(Parameter &para) {
  //------Find the total block number of the wavefunction matrix for a given targetspin--------------------------
	int J_sys_n, J_e_env, J_min, J_max, J_num, oldJ_sys, oldJ_env;

        index=0;
        BlockNumber_for_TargetSpin=0;   Dim=0;

        for(int j_sysnew=0; j_sysnew<sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sysnew_space->Sys_Value_Jn[j_sysnew]-envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sysnew_space->Sys_Value_Jn[j_sysnew]+envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++)
                if(QuantumNumber==J_min+2*n) {
                                for(int j_n=0; j_n<para.S+1; j_n++)
                                for(int j_e=0; j_e<para.S+1; j_e++)
                                if(sysnew_space->IndexOld[j_n][j_sysnew]!=-1 && envnew_space->IndexOld[j_e][j_envnew]!=-1) {
                                        BlockNumber_for_TargetSpin++;
                                }
                }
        }

  //------Create Space for J_sys, J_env, J_sysnew, J_envnew, Dim_block-------------------------------------------
	J_sys=new int [BlockNumber_for_TargetSpin];
        J_env=new int [BlockNumber_for_TargetSpin];
        J_sysnew=new int [BlockNumber_for_TargetSpin];
        J_envnew=new int [BlockNumber_for_TargetSpin];
        Dim_block=new int [BlockNumber_for_TargetSpin];

        for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                J_sys[i]=0;     J_env[i]=0;     J_sysnew[i]=0;  J_envnew[i]=0;  Dim_block[i]=0;
        }

  //------Initialize the values of the above vectors-------------------------------------------------------------
	for(int j_sysnew=0; j_sysnew<sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sysnew_space->Sys_Value_Jn[j_sysnew]-envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sysnew_space->Sys_Value_Jn[j_sysnew]+envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++)
                if(QuantumNumber==J_min+2*n) {
                        for(int j_n=0; j_n<para.S+1; j_n++)
                        for(int j_e=0; j_e<para.S+1; j_e++)
                        if((oldJ_sys=sysnew_space->IndexOld[j_n][j_sysnew])!=-1 && (oldJ_env=envnew_space->IndexOld[j_e][j_envnew])!=-1) {
                                J_sys[index]=oldJ_sys;          J_env[index]=oldJ_env;
                                J_sysnew[index]=j_sysnew;       J_envnew[index]=j_envnew;
                                Dim_block[index++]=sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]*env_space->Sys_SubBlockNumber_Jn[oldJ_env];
                        }
                        break;
                }
        }

  //------Initialize the wavefunction----------------------------------------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin; i++)
                Dim+=Dim_block[i];

	WaveFunction=new double [Dim];
//	WaveFunction_excited=new double [Dim];

        for(int i=0; i<Dim; i++) {
		WaveFunction[i]=(double) 0;      //WaveFunction_excited[i]=(double) 0;
	}

       	WaveFunction_block=new double * [BlockNumber_for_TargetSpin];
//	WaveFunction_excited_block=new double * [BlockNumber_for_TargetSpin];

        for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
       	        WaveFunction_block[i]=new double [Dim_block[i]];
//		WaveFunction_excited_block[i]=new double [Dim_block[i]];
                for(int j=0; j<Dim_block[i]; j++) {
       	                WaveFunction_block[i][j]=(double) 0;
//			WaveFunction_excited_block[i][j]=(double) 0;
		}
       	}

        cout<<"\n Dimension of the diagonalizing subspace="<<Dim;
}

//=============================Set the variables for diagonalization process=====================================
Super::Super(char *iteration, Parameter &para, Sub *sys1, Sub *env1, Super &space) {
	destruct='d';	//'d' stands for creating space for diagonalizaiton

	sys=sys1;
	env=env1;

  //------Initialize the parameters for BLAS subroutines---------------------------------------------------------
	N=para.N;	inc=1;
	side_L='L';     side_R='R';     uplo='U';
	trans_N='N';    trans_T='T';
	beta=1.0;       alpha_p=1.0;    beta_p=0.0;

        if( (sys->TotSiteNo+env->TotSiteNo+2) < para.Total_j )
                QuantumNumber=sys->TotSiteNo+env->TotSiteNo+2;

        else
        QuantumNumber=para.Total_j;

  //-------------------------------------geometry (path) dependent------------------------------
	if(iteration=="finite")	{
		StartSite=N-1;
	}

	else if(iteration=="infinite") {
//		StartSite=2*sys->TotSiteNo+1;	//For 1D chain
                int totalsite=sys->TotSiteNo+env->TotSiteNo+2;
                for(int i=1; i<para.N_x; i++) {
                        if((i+1)*para.N_u*para.N_y>=totalsite) {
                                StartSite=(i+1)*para.N_u*para.N_y-1;
                                break;
                        }
                }
        }

  //------Allocate Interaction Table-----------------------------------------------------------------------------
	Table=new int [N*N];
	Interaction=new double [N*N];
	for(int i=0; i<N*N; i++) {
		Table[i]=para.Table[i];
		Interaction[i]=para.Interaction[i];
	}

  //------Find the sites with interactions outside the block in system and environment---------------------------
	operator_number_sys=para.Table_sys[sys->TotSiteNo-1];
	operator_number_env=para.Table_env[env->TotSiteNo-1];

	Table_sys=new int [operator_number_sys];
	Table_env=new int [operator_number_env];

	for(int i=0; i<operator_number_sys; i++)
		Table_sys[i]=para.Table_sys_site[sys->TotSiteNo-1][i];

	for(int i=0; i<operator_number_env; i++)
		Table_env[i]=para.Table_env_site[env->TotSiteNo-1][i];
 
  //------Read space variables from subroutine space
	BlockNumber_for_TargetSpin=space.BlockNumber_for_TargetSpin;
        Dim=space.Dim;

        J_sys=new int [BlockNumber_for_TargetSpin];
        J_env=new int [BlockNumber_for_TargetSpin];
        J_sysnew=new int [BlockNumber_for_TargetSpin];
        J_envnew=new int [BlockNumber_for_TargetSpin];
        Dim_block=new int [BlockNumber_for_TargetSpin];

        for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                J_sys[i]=space.J_sys[i];        J_env[i]=space.J_env[i];     J_sysnew[i]=space.J_sysnew[i];
                J_envnew[i]=space.J_envnew[i];  Dim_block[i]=space.Dim_block[i];
        }

  //------Allocate Tables denoting the index between *f and **f for diagonalizaiton------------------------------
    //------Create Space
	Table_1to2_Num=new int [Dim];
	Table_1to2_Site=new int [Dim];
	for(int i=0; i<Dim; i++) {
		Table_1to2_Num[i]=0;    Table_1to2_Site[i]=0;
	}

	Table_2to1=new int * [BlockNumber_for_TargetSpin];
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
		Table_2to1[i]=new int [Dim_block[i]];
		for(int j=0; j<Dim_block[i]; j++)
			Table_2to1[i][j]=0;
	}

    //------Initialize the values for the above two Tables      
      //------For diagonalization with column-storage vectors----------------------------------------------------
	index=0;        //"index" denotes the "site" here!!!, "site_s" denotes "site_block"!!!
	for(int i=0; i<BlockNumber_for_TargetSpin; i++)   
	for(int j=0; j<env->Sys_SubBlockNumber_Jn[J_env[i]]; j++)  //These two lines indicate the
	for(int k=0; k<sys->Sys_SubBlockNumber_Jn[J_sys[i]]; k++) {//column-main storage!!!
		site_s=j*sys->Sys_SubBlockNumber_Jn[J_sys[i]]+k;
		Table_1to2_Num[index]=i;        	//index==site
		Table_1to2_Site[index]=site_s;  	//index==site
		Table_2to1[i][site_s]=index;    	//index==site
		index++;                        	//index==site
        }

      //------For diagonalization with row-storage vectors-------------------------------------------------------
/*	index=0;
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) 
	for(int j=0; j<sys->Sys_SubBlockNumber_Jn[J_sys[i]]; j++) 
	for(int k=0; k<env->Sys_SubBlockNumber_Jn[J_env[i]]; k++) {
		site_s=k*sys->Sys_SubBlockNumber_Jn[J_sys[i]]+j;
		Table_1to2_Num[index]=i;
		Table_1to2_Site[index]=site_s;
		Table_2to1[i][site_s]=index;
		index++;
        }
*/
 //------Allocate f1, f2, g1 and g2 for Matrix-Vector multiplication---------------------------------------------
	f1=new double * [BlockNumber_for_TargetSpin]; 	
	g1=new double * [BlockNumber_for_TargetSpin];
	f2=new double * [BlockNumber_for_TargetSpin];
	g2=new double * [BlockNumber_for_TargetSpin];
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
		f1[i]=new double [Dim_block[i]];	g1[i]=new double [Dim_block[i]];
		f2[i]=new double [Dim_block[i]];	g2[i]=new double [Dim_block[i]];
		for(int j=0; j<Dim_block[i]; j++) {
			f1[i][j]=0.0;		g1[i][j]=0.0;
			f2[i][j]=0.0;		g2[i][j]=0.0;
		}
 	}

        S_Dia_sys = new double * [ sys->Sys_Number_Jn ];
        for( int i = 0; i < sys->Sys_Number_Jn; i++ ) {

                dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i];

                S_Dia_sys[i] = new double [dimension];

                for( int j = 0; j < dimension; j++ )

                        S_Dia_sys[i][j] = 0.0;

        }

        S_M_Dia_sys = new double * [ sys->Sys_Number_Jn - 1 ];
        for( int i = 0; i < sys->Sys_Number_Jn - 1; i++ ) {

                dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i+1];

                S_M_Dia_sys[i] = new double [dimension];

                for( int j = 0; j < dimension; j++ )

                        S_M_Dia_sys[i][j] = 0.0;

        }

        S_Dia_env = new double * [ env->Sys_Number_Jn ];
        for( int i = 0; i < env->Sys_Number_Jn; i++ ) {

                dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i];

                S_Dia_env[i] = new double [dimension];

                for( int j = 0; j < dimension; j++ )

                        S_Dia_env[i][j] = 0.0;

        }

        S_M_Dia_env = new double * [ env->Sys_Number_Jn - 1 ];
        for( int i = 0; i < env->Sys_Number_Jn - 1; i++ ) {

                dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i+1];

                S_M_Dia_env[i] = new double [dimension];

                for( int j = 0; j < dimension; j++ )

                        S_M_Dia_env[i][j] = 0.0;

        }

  //------6j and 9j coefficients for configurations 1, and 2-----------------------------------------------------
        Allocate_6j_config_1_2(para, space);
        Allocate_9j_config_2(para, space);

  //------Allocate the block information for the wave function of cinfigure 3------------------------------------
	AllocateBlockNumber_config_3(para);	
	Allocate_6j_config_3(para);
	Allocate_9j_config_3(para, space);
}

//===============================================================================================================
//					Super for the calculations of measurements
//===============================================================================================================
Super::Super(Sub *sys_space1, Sub *env_space1, Sub *sysnew_space1, Sub *envnew_space1, Parameter &para) {
        destruct='m';   //"m" stands for creating space for measurements

        QuantumNumber=para.Total_j;

        sys=sys_space1;
        env=env_space1;
        sysnew_space=sysnew_space1;
        envnew_space=envnew_space1;

        int J_sys_n, J_e_env, J_min, J_max, J_num, oldJ_sys, oldJ_env;

        index=0;
        BlockNumber_for_TargetSpin=0;   Dim=0;

        for(int j_sysnew=0; j_sysnew<sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sysnew_space->Sys_Value_Jn[j_sysnew]-envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sysnew_space->Sys_Value_Jn[j_sysnew]+envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++)
                if(QuantumNumber==J_min+2*n) {
                                for(int j_n=0; j_n<para.S+1; j_n++)
                                for(int j_e=0; j_e<para.S+1; j_e++)
                                if(sysnew_space->IndexOld[j_n][j_sysnew]!=-1 && envnew_space->IndexOld[j_e][j_envnew]!=-1) {
                                        BlockNumber_for_TargetSpin++;
                                }
                }
        }

        J_sys=new int [BlockNumber_for_TargetSpin];
        J_env=new int [BlockNumber_for_TargetSpin];
        J_sysnew=new int [BlockNumber_for_TargetSpin];
        J_envnew=new int [BlockNumber_for_TargetSpin];
        Dim_block=new int [BlockNumber_for_TargetSpin];

        for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                J_sys[i]=0;     J_env[i]=0;     J_sysnew[i]=0;  J_envnew[i]=0;  Dim_block[i]=0;
        }

        for(int j_sysnew=0; j_sysnew<sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sysnew_space->Sys_Value_Jn[j_sysnew]-envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sysnew_space->Sys_Value_Jn[j_sysnew]+envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++)
                if(QuantumNumber==J_min+2*n) {
                        for(int j_n=0; j_n<para.S+1; j_n++)
                        for(int j_e=0; j_e<para.S+1; j_e++)
                        if((oldJ_sys=sysnew_space->IndexOld[j_n][j_sysnew])!=-1 && (oldJ_env=envnew_space->IndexOld[j_e][j_envnew])!=-1) {
                                J_sys[index]=oldJ_sys;          J_env[index]=oldJ_env;
                                J_sysnew[index]=j_sysnew;       J_envnew[index]=j_envnew;
                                Dim_block[index++]=sys->Sys_SubBlockNumber_Jn[oldJ_sys]*env->Sys_SubBlockNumber_Jn[oldJ_env];
                        }
                        break;
                }
        }

  //------
        int i_g, i_f;
        int Length=BlockNumber_for_TargetSpin*BlockNumber_for_TargetSpin;

        six_j_1_sys_n=new double [Length];
        six_j_1_e_env=new double [Length];

        for(int i=0; i<Length; i++) {
                i_g=i/BlockNumber_for_TargetSpin;//stands for the index of "g" function, "g" function is bra
                i_f=i%BlockNumber_for_TargetSpin;//stands for the index of "f" function  "f" function is ket

                six_j_1_sys_n[i]=gsl_sf_coupling_6j(sysnew_space->Sys_Value_Jn[J_sysnew[i_f]], para.S, sys->Sys_Value_Jn[J_sys[i_g]], 2, sys->Sys_Value_Jn[J_sys[i_f]], para.S)*pow(-1.0, (para.S+sysnew_space->Sys_Value_Jn[J_sysnew[i_f]]+sys->Sys_Value_Jn[J_sys[i_f]])/2)*constant; //for angular momentum coupling: |(J_sys, J_n)J_(sys,n)>
                six_j_1_e_env[i]=gsl_sf_coupling_6j(envnew_space->Sys_Value_Jn[J_envnew[i_f]], para.S, env->Sys_Value_Jn[J_env[i_g]], 2, env->Sys_Value_Jn[J_env[i_f]], para.S)*pow(-1.0, (para.S+envnew_space->Sys_Value_Jn[J_envnew[i_f]]+env->Sys_Value_Jn[J_env[i_f]])/2)*constant;//for angular momentum coupling: |(J_env, J_e)J_(env,e)>
        }

  //------
        nine_j_config_2=new double * [BlockNumber_for_TargetSpin];

        for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin; j++)
                if(J_sys[j]==J_sys[i] && J_env[j]==J_env[i]) {
                        index++;
                }

                nine_j_config_2[i]=new double [index];
                for(int n=0; n<index; n++)
                        nine_j_config_2[i][n]=(double) 0;
        }

        for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin; j++)
                if(J_sys[j]==J_sys[i] && J_env[j]==J_env[i]) {                        
                        alpha=sqrt((sysnew_space->Sys_Value_Jn[J_sysnew[i]]+1.0)*(envnew_space->Sys_Value_Jn[J_envnew[i]]+1.0)*(sysnew_space->Sys_Value_Jn[J_sysnew[j]]+1.0)*(envnew_space->Sys_Value_Jn[J_envnew[j]]+1.0))*(QuantumNumber+1.0)*pow(-1.0,(-sysnew_space->Sys_Value_Jn[J_sysnew[i]]+envnew_space->Sys_Value_Jn[J_envnew[i]]-sysnew_space->Sys_Value_Jn[J_sysnew[j]]+envnew_space->Sys_Value_Jn[J_envnew[j]]-2*(sys->Sys_Value_Jn[J_sys[i]]+env->Sys_Value_Jn[J_env[i]])-4.0*QuantumNumber)/2);
                        for(int m_n=0; m_n<para.S+1; m_n++)
                        for(int m_e=0; m_e<para.S+1; m_e++)
                        for(int m_1=0; m_1<sys->Sys_Value_Jn[J_sys[i]]+1; m_1++)
                        for(int m_2=0; m_2<env->Sys_Value_Jn[J_env[i]]+1; m_2++)
                        if((2*(m_n+m_e+m_1+m_2-para.S)-sys->Sys_Value_Jn[J_sys[i]]-env->Sys_Value_Jn[J_env[i]])==QuantumNumber) {                                
                                nine_j_config_2[i][index]+=alpha*gsl_sf_coupling_3j(sys->Sys_Value_Jn[J_sys[i]], para.S, sysnew_space->Sys_Value_Jn[J_sysnew[j]], -sys->Sys_Value_Jn[J_sys[i]]+2*m_1, -para.S+2*m_e, para.S-2*(m_e+m_1)+sys->Sys_Value_Jn[J_sys[i]])*gsl_sf_coupling_3j(env->Sys_Value_Jn[J_env[i]], para.S, envnew_space->Sys_Value_Jn[J_envnew[j]], -env->Sys_Value_Jn[J_env[i]]+2*m_2, -para.S+2*m_n, para.S-2*(m_n+m_2)+env->Sys_Value_Jn[J_env[i]])*gsl_sf_coupling_3j(sysnew_space->Sys_Value_Jn[J_sysnew[j]], envnew_space->Sys_Value_Jn[J_envnew[j]], QuantumNumber, -para.S+2*(m_e+m_1)-sys->Sys_Value_Jn[J_sys[i]], -para.S+2*(m_n+m_2)-env->Sys_Value_Jn[J_env[i]], -QuantumNumber)*gsl_sf_coupling_3j(sys->Sys_Value_Jn[J_sys[i]], para.S, sysnew_space->Sys_Value_Jn[J_sysnew[i]], -sys->Sys_Value_Jn[J_sys[i]]+2*m_1, -para.S+2*m_n, para.S-2*(m_n+m_1)+sys->Sys_Value_Jn[J_sys[i]])*gsl_sf_coupling_3j(env->Sys_Value_Jn[J_env[i]], para.S, envnew_space->Sys_Value_Jn[J_envnew[i]], -env->Sys_Value_Jn[J_env[i]]+2*m_2, -para.S+2*m_e, para.S-2*(m_e+m_2)+env->Sys_Value_Jn[J_env[i]])*gsl_sf_coupling_3j(sysnew_space->Sys_Value_Jn[J_sysnew[i]], envnew_space->Sys_Value_Jn[J_envnew[i]], QuantumNumber, -para.S+2*(m_n+m_1)-sys->Sys_Value_Jn[J_sys[i]], -para.S+2*(m_e+m_2)-env->Sys_Value_Jn[J_env[i]], -QuantumNumber);
                        }
                        index++;
                }
        }

  //------
        BlockNumber_for_TargetSpin_config_3=0;
        int J_mid, J_mid_max, J_mid_min;
        for(int jsys=0; jsys<sys->Sys_Number_Jn; jsys++)
        for(int jenv=0; jenv<env->Sys_Number_Jn; jenv++) {
                J_min=abs(sys->Sys_Value_Jn[jsys]-env->Sys_Value_Jn[jenv]);
                J_max=sys->Sys_Value_Jn[jsys]+env->Sys_Value_Jn[jenv];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++) {
                        J_mid=J_min+2*n;
                        for(int m=0; m<para.S+1; m++) {//"m" is the coupled angular momentum of two S spins
                                J_mid_max=J_mid+2*m;
                                J_mid_min=abs(J_mid-2*m);
                                for(int k=0; k<(J_mid_max-J_mid_min)/2+1; k++)
                                if(J_mid_min+2*k==QuantumNumber)       BlockNumber_for_TargetSpin_config_3++;
                        }
                }
        }

        J_sys_config_3=new int [BlockNumber_for_TargetSpin_config_3];
        J_env_config_3=new int [BlockNumber_for_TargetSpin_config_3];
        J_sysnew_config_3=new int [BlockNumber_for_TargetSpin_config_3];
        J_envnew_config_3=new int [BlockNumber_for_TargetSpin_config_3];
        Dim_block_config_3=new int [BlockNumber_for_TargetSpin_config_3];

        for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
                J_sys_config_3[i]=0;     J_env_config_3[i]=0;     J_sysnew_config_3[i]=0;
                J_envnew_config_3[i]=0;  Dim_block_config_3[i]=0;
        }

        index=0;
        for(int jsys=0; jsys<sys->Sys_Number_Jn; jsys++)
        for(int jenv=0; jenv<env->Sys_Number_Jn; jenv++) {
                J_min=abs(sys->Sys_Value_Jn[jsys]-env->Sys_Value_Jn[jenv]);
                J_max=sys->Sys_Value_Jn[jsys]+env->Sys_Value_Jn[jenv];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++) {
                        J_mid=J_min+2*n;
                        for(int m=0; m<para.S+1; m++) {
                                J_mid_max=J_mid+2*m;
                                J_mid_min=abs(J_mid-2*m);
                                for(int k=0; k<(J_mid_max-J_mid_min)/2+1; k++)
                                if(J_mid_min+2*k==QuantumNumber) {
                                        J_sys_config_3[index]=jsys;     J_env_config_3[index]=jenv;
                                        J_sysnew_config_3[index]=J_mid;  J_envnew_config_3[index]=2*m;
                                        Dim_block_config_3[index++]=sys->Sys_SubBlockNumber_Jn[jsys]*env->Sys_SubBlockNumber_Jn[jenv];
                                }
                        }
                }
        }

        six_j_1_config_3=new double * [BlockNumber_for_TargetSpin_config_3];
        for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++) {
                        if(J_sysnew_config_3[j]==J_sysnew_config_3[i] && J_envnew_config_3[j]==J_envnew_config_3[i] && abs(sys->Sys_Value_Jn[J_sys_config_3[i]]-sys->Sys_Value_Jn[J_sys_config_3[j]])<=2 && abs(env->Sys_Value_Jn[J_env_config_3[i]]-env->Sys_Value_Jn[J_env_config_3[j]])<=2) {
                                index++;
                        }
                }
                six_j_1_config_3[i]=new double [index];
                for(int n=0; n<index; n++) {
                        six_j_1_config_3[i][n]=(double) 0;
                }
        }

        for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++)                
		if(J_sysnew_config_3[j]==J_sysnew_config_3[i] && J_envnew_config_3[j]==J_envnew_config_3[i] && abs(sys->Sys_Value_Jn[J_sys_config_3[i]]-sys->Sys_Value_Jn[J_sys_config_3[j]])<=2 && abs(env->Sys_Value_Jn[J_env_config_3[i]]-env->Sys_Value_Jn[J_env_config_3[j]])<=2) {                        
			six_j_1_config_3[i][index++]=pow(-1.0, (sys->Sys_Value_Jn[J_sys_config_3[j]]+env->Sys_Value_Jn[J_env_config_3[i]]+J_sysnew_config_3[i])/2)*gsl_sf_coupling_6j(J_sysnew_config_3[i], env->Sys_Value_Jn[J_env_config_3[i]], sys->Sys_Value_Jn[J_sys_config_3[i]], 2, sys->Sys_Value_Jn[J_sys_config_3[j]], env->Sys_Value_Jn[J_env_config_3[j]]);
                }
        }

        six_j_2_config_3=new double [BlockNumber_for_TargetSpin_config_3];        
	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++)
                six_j_2_config_3[i]=J_envnew_config_3[i]*(J_envnew_config_3[i]/2.0+1.0)/4.0-para.S*(para.S/2.0+1.0)/2.0;

  //------
        nine_j_config_3=new double * [BlockNumber_for_TargetSpin_config_3];
        for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin; j++) {
                        if(J_sys[j]==J_sys_config_3[i] && J_env[j]==J_env_config_3[i])
                                index++;                
		}                
		nine_j_config_3[i]=new double [index];
                for(int n=0; n<index; n++) {                        
			nine_j_config_3[i][n]=(double) 0;                
		}
        }

        for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin; j++) {                        
			if(J_sys[j]==J_sys_config_3[i] && J_env[j]==J_env_config_3[i]) {
                                nine_j_config_3[i][index++]=gsl_sf_coupling_9j(sys->Sys_Value_Jn[J_sys[j]], env->Sys_Value_Jn[J_env[j]], J_sysnew_config_3[i], para.S, para.S, J_envnew_config_3[i], sysnew_space->Sys_Value_Jn[J_sysnew[j]], envnew_space->Sys_Value_Jn[J_envnew[j]], QuantumNumber)*sqrt((J_sysnew_config_3[i]+1.0)*(J_envnew_config_3[i]+1.0)*(sysnew_space->Sys_Value_Jn[J_sysnew[j]]+1.0)*(envnew_space->Sys_Value_Jn[J_envnew[j]]+1.0));
                        }
                }
        }

        nine_j_config_3_inverse=new double * [BlockNumber_for_TargetSpin];
        for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++) {
                        if(J_sys_config_3[j]==J_sys[i] && J_env_config_3[j]==J_env[i]) {
                                index++;
                        }
                }
                nine_j_config_3_inverse[i]=new double [index];
                for(int n=0; n<index; n++) {
                        nine_j_config_3_inverse[i][n]=(double) 0;
                }
        }

        for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++) {
                        if(J_sys_config_3[j]==J_sys[i] && J_env_config_3[j]==J_env[i]) {     
	                        nine_j_config_3_inverse[i][index++]=gsl_sf_coupling_9j(sys->Sys_Value_Jn[J_sys[i]], para.S, sysnew_space->Sys_Value_Jn[J_sysnew[i]], env->Sys_Value_Jn[J_env[i]], para.S, envnew_space->Sys_Value_Jn[J_envnew[i]], J_sysnew_config_3[j], J_envnew_config_3[j], QuantumNumber)*sqrt((J_sysnew_config_3[j]+1.0)*(J_envnew_config_3[j]+1.0)*(sysnew_space->Sys_Value_Jn[J_sysnew[i]]+1.0)*(envnew_space->Sys_Value_Jn[J_envnew[i]]+1.0));            
			}                
		}        
	}

}

//=============================Alocate the 6j coefficients for configurations 1 and 2=============================
//	Including the NN interaction "J" and "<J||S||J>" in this defined 6j coefficients!!!
//	For different order of angular momentum couplings, this item should be revised accordingly!!!
//================================================================================================================
inline void Super::Allocate_6j_config_1_2(Parameter &para, Super &space) {
	int i_g, i_f;
	int Length=BlockNumber_for_TargetSpin*BlockNumber_for_TargetSpin;

	six_j_1_sys_n=new double [Length];
	six_j_1_e_env=new double [Length];

	for(int i=0; i<Length; i++) {
		i_g=i/BlockNumber_for_TargetSpin;//stands for the index of "g" function, "g" function is bra
		i_f=i%BlockNumber_for_TargetSpin;//stands for the index of "f" function  "f" function is ket

		six_j_1_sys_n[i]=gsl_sf_coupling_6j(space.sysnew_space->Sys_Value_Jn[J_sysnew[i_f]], para.S, sys->Sys_Value_Jn[J_sys[i_g]], 2, sys->Sys_Value_Jn[J_sys[i_f]], para.S)*pow(-1.0, (para.S+space.sysnew_space->Sys_Value_Jn[J_sysnew[i_f]]+sys->Sys_Value_Jn[J_sys[i_f]])/2)*constant; //for angular momentum coupling: |(J_sys, J_n)J_(sys,n)>

		six_j_1_e_env[i]=gsl_sf_coupling_6j(space.envnew_space->Sys_Value_Jn[J_envnew[i_f]], para.S, env->Sys_Value_Jn[J_env[i_g]], 2, env->Sys_Value_Jn[J_env[i_f]], para.S)*pow(-1.0, (para.S+space.envnew_space->Sys_Value_Jn[J_envnew[i_f]]+env->Sys_Value_Jn[J_env[i_f]])/2)*constant;//for angular momentum coupling: |(J_env, J_e)J_(env,e)>
	}
}

//==============================Allocate the 9j coefficients for configuration 2==================================
//Define the 9j coefficient for the basis transformation between configurations 1 and 2!!! From (sys+ns & env+ne)
//to (sys+ne & env+ns)!!! Obtained directly by the definition of 9j coefficient from 3j coefficients!!!
//================================================================================================================
inline void Super::Allocate_9j_config_2(Parameter &para, Super &space) {
  //------Create space--------------------------------------------------------------------------------------------
	nine_j_config_2=new double * [BlockNumber_for_TargetSpin];

	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
		index=0;

		for(int j=0; j<BlockNumber_for_TargetSpin; j++) 
		if(J_sys[j]==J_sys[i] && J_env[j]==J_env[i]) {
			index++;
		}

		nine_j_config_2[i]=new double [index];
		for(int n=0; n<index; n++)  
			nine_j_config_2[i][n]=(double) 0;
	}

  //------Initialize 9-j coefficient for config_2----------------------------------------------------------------
  	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
		index=0;
		for(int j=0; j<BlockNumber_for_TargetSpin; j++) 
		if(J_sys[j]==J_sys[i] && J_env[j]==J_env[i]) { 
			alpha=sqrt((space.sysnew_space->Sys_Value_Jn[J_sysnew[i]]+1.0)*(space.envnew_space->Sys_Value_Jn[J_envnew[i]]+1.0)*(space.sysnew_space->Sys_Value_Jn[J_sysnew[j]]+1.0)*(space.envnew_space->Sys_Value_Jn[J_envnew[j]]+1.0))*(QuantumNumber+1.0)*pow(-1.0,(-space.sysnew_space->Sys_Value_Jn[J_sysnew[i]]+space.envnew_space->Sys_Value_Jn[J_envnew[i]]-space.sysnew_space->Sys_Value_Jn[J_sysnew[j]]+space.envnew_space->Sys_Value_Jn[J_envnew[j]]-2*(sys->Sys_Value_Jn[J_sys[i]]+env->Sys_Value_Jn[J_env[i]])-4.0*QuantumNumber)/2);//"alpha" denotes "factor"!!!
			for(int m_n=0; m_n<para.S+1; m_n++)
			for(int m_e=0; m_e<para.S+1; m_e++)
	        	for(int m_1=0; m_1<sys->Sys_Value_Jn[J_sys[i]]+1; m_1++)
                        for(int m_2=0; m_2<env->Sys_Value_Jn[J_env[i]]+1; m_2++)
			if((2*(m_n+m_e+m_1+m_2-para.S)-sys->Sys_Value_Jn[J_sys[i]]-env->Sys_Value_Jn[J_env[i]])==QuantumNumber) {
				nine_j_config_2[i][index]+=alpha*gsl_sf_coupling_3j(sys->Sys_Value_Jn[J_sys[i]], para.S, space.sysnew_space->Sys_Value_Jn[J_sysnew[j]], -sys->Sys_Value_Jn[J_sys[i]]+2*m_1, -para.S+2*m_e, para.S-2*(m_e+m_1)+sys->Sys_Value_Jn[J_sys[i]])*gsl_sf_coupling_3j(env->Sys_Value_Jn[J_env[i]], para.S, space.envnew_space->Sys_Value_Jn[J_envnew[j]], -env->Sys_Value_Jn[J_env[i]]+2*m_2, -para.S+2*m_n, para.S-2*(m_n+m_2)+env->Sys_Value_Jn[J_env[i]])*gsl_sf_coupling_3j(space.sysnew_space->Sys_Value_Jn[J_sysnew[j]], space.envnew_space->Sys_Value_Jn[J_envnew[j]], QuantumNumber, -para.S+2*(m_e+m_1)-sys->Sys_Value_Jn[J_sys[i]], -para.S+2*(m_n+m_2)-env->Sys_Value_Jn[J_env[i]], -QuantumNumber)*gsl_sf_coupling_3j(sys->Sys_Value_Jn[J_sys[i]], para.S, space.sysnew_space->Sys_Value_Jn[J_sysnew[i]], -sys->Sys_Value_Jn[J_sys[i]]+2*m_1, -para.S+2*m_n, para.S-2*(m_n+m_1)+sys->Sys_Value_Jn[J_sys[i]])*gsl_sf_coupling_3j(env->Sys_Value_Jn[J_env[i]], para.S, space.envnew_space->Sys_Value_Jn[J_envnew[i]], -env->Sys_Value_Jn[J_env[i]]+2*m_2, -para.S+2*m_e, para.S-2*(m_e+m_2)+env->Sys_Value_Jn[J_env[i]])*gsl_sf_coupling_3j(space.sysnew_space->Sys_Value_Jn[J_sysnew[i]], space.envnew_space->Sys_Value_Jn[J_envnew[i]], QuantumNumber, -para.S+2*(m_n+m_1)-sys->Sys_Value_Jn[J_sys[i]], -para.S+2*(m_e+m_2)-env->Sys_Value_Jn[J_env[i]], -QuantumNumber);
			}
			index++;
		}
	}
}

//==========================Allocate block information of wavefunction for configuration 3========================
//Find Hilbert space and create spaces for the variables to mark the blocks!!! Configuration 3: (sys+env, ns+ne)
//================================================================================================================
inline void Super::AllocateBlockNumber_config_3(Parameter &para) {
  //------Find the total block number of the wavefunction matrix for a given targetspin--------------------------
	BlockNumber_for_TargetSpin_config_3=0;
	int J_min, J_max, J_num, J_mid, J_mid_max, J_mid_min;
	for(int jsys=0; jsys<sys->Sys_Number_Jn; jsys++)
	for(int jenv=0; jenv<env->Sys_Number_Jn; jenv++) {
		J_min=abs(sys->Sys_Value_Jn[jsys]-env->Sys_Value_Jn[jenv]);
		J_max=sys->Sys_Value_Jn[jsys]+env->Sys_Value_Jn[jenv];
		J_num=(J_max-J_min)/2+1;
		for(int n=0; n<J_num; n++) {
			J_mid=J_min+2*n;
			for(int m=0; m<para.S+1; m++) {//"m" is the coupled angular momentum of two S spins
				J_mid_max=J_mid+2*m;
				J_mid_min=abs(J_mid-2*m);
				for(int k=0; k<(J_mid_max-J_mid_min)/2+1; k++)
				if(J_mid_min+2*k==QuantumNumber)	BlockNumber_for_TargetSpin_config_3++;
			}
		}
	}
//	cout<<"\n BlockNumber_for_TargetSpin_config_3="<<BlockNumber_for_TargetSpin_config_3;

 //------Create space for J_sys_config_3, J_env_config_3, J_sysnew_config_3, J_envnew_config_3, Dim_block_config_3
	J_sys_config_3=new int [BlockNumber_for_TargetSpin_config_3];
        J_env_config_3=new int [BlockNumber_for_TargetSpin_config_3];
        J_sysnew_config_3=new int [BlockNumber_for_TargetSpin_config_3];
        J_envnew_config_3=new int [BlockNumber_for_TargetSpin_config_3];
        Dim_block_config_3=new int [BlockNumber_for_TargetSpin_config_3];

        for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
                J_sys_config_3[i]=0;     J_env_config_3[i]=0;     J_sysnew_config_3[i]=0;  
		J_envnew_config_3[i]=0;  Dim_block_config_3[i]=0;
        }

  //------Initialize the above arraies---------------------------------------------------------------------------
  //J_sysnew_config_3 denotes (sys+env), and J_envnew_config_3 denotes (ns+ne), J_sys denotes (sys), J_env (env)!
	index=0;
  	for(int jsys=0; jsys<sys->Sys_Number_Jn; jsys++)
        for(int jenv=0; jenv<env->Sys_Number_Jn; jenv++) {
                J_min=abs(sys->Sys_Value_Jn[jsys]-env->Sys_Value_Jn[jenv]);
                J_max=sys->Sys_Value_Jn[jsys]+env->Sys_Value_Jn[jenv];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++) {
                        J_mid=J_min+2*n;
                        for(int m=0; m<para.S+1; m++) {
                                J_mid_max=J_mid+2*m;
                                J_mid_min=abs(J_mid-2*m);
                                for(int k=0; k<(J_mid_max-J_mid_min)/2+1; k++)
                                if(J_mid_min+2*k==QuantumNumber) {
         				J_sys_config_3[index]=jsys;	J_env_config_3[index]=jenv;
					J_sysnew_config_3[index]=J_mid;  J_envnew_config_3[index]=2*m;
					Dim_block_config_3[index++]=sys->Sys_SubBlockNumber_Jn[jsys]*env->Sys_SubBlockNumber_Jn[jenv];
				}
                        }
                }
        }

  //------Check the Dimensions of the different configurations!!!------------------------------------------------
	Dim_config_3=0;

	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++)
		Dim_config_3+=Dim_block_config_3[i];

	if(Dim_config_3!=Dim)	cout<<"\n Error: Dim_config_3 is not equal to Dim_config_1,2"<<endl;

  //------Create space for wave function f3 and g3---------------------------------------------------------------
        f3=new double * [BlockNumber_for_TargetSpin_config_3];
        g3=new double * [BlockNumber_for_TargetSpin_config_3];
        for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
                f3[i]=new double [Dim_block_config_3[i]];        g3[i]=new double [Dim_block_config_3[i]];
                for(int j=0; j<Dim_block_config_3[i]; j++) {
                        f3[i][j]=(double) 0;            g3[i][j]=(double) 0;
                }
        }
}

//====================================Allocate 6j coefficients for configuration 3===============================
inline void Super::Allocate_6j_config_3(Parameter &para) {
//------Create space for six_j_1_config_3------------------------------------------------------------------------
	six_j_1_config_3=new double * [BlockNumber_for_TargetSpin_config_3];
	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
		index=0;
		for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++) {
			if(J_sysnew_config_3[j]==J_sysnew_config_3[i] && J_envnew_config_3[j]==J_envnew_config_3[i] && abs(sys->Sys_Value_Jn[J_sys_config_3[i]]-sys->Sys_Value_Jn[J_sys_config_3[j]])<=2 && abs(env->Sys_Value_Jn[J_env_config_3[i]]-env->Sys_Value_Jn[J_env_config_3[j]])<=2) {
				index++;
			}
		}
		six_j_1_config_3[i]=new double [index];
		for(int n=0; n<index; n++) {
			six_j_1_config_3[i][n]=(double) 0;
		}
	}

  //------Initialize six_j_1_config_3------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
		index=0;
		for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++) 
               	if(J_sysnew_config_3[j]==J_sysnew_config_3[i] && J_envnew_config_3[j]==J_envnew_config_3[i] && abs(sys->Sys_Value_Jn[J_sys_config_3[i]]-sys->Sys_Value_Jn[J_sys_config_3[j]])<=2 && abs(env->Sys_Value_Jn[J_env_config_3[i]]-env->Sys_Value_Jn[J_env_config_3[j]])<=2) {
			six_j_1_config_3[i][index++]=pow(-1.0, (sys->Sys_Value_Jn[J_sys_config_3[j]]+env->Sys_Value_Jn[J_env_config_3[i]]+J_sysnew_config_3[i])/2)*gsl_sf_coupling_6j(J_sysnew_config_3[i], env->Sys_Value_Jn[J_env_config_3[i]], sys->Sys_Value_Jn[J_sys_config_3[i]], 2, sys->Sys_Value_Jn[J_sys_config_3[j]], env->Sys_Value_Jn[J_env_config_3[j]]);
		}
	}

//------Create space for six_j_1_config_3_diaele for the use in calculating the diagonal elements of H matrix----
	six_j_1_config_3_diaele=new double [BlockNumber_for_TargetSpin_config_3];
	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
		six_j_1_config_3_diaele[i]=pow(-1.0, (sys->Sys_Value_Jn[J_sys_config_3[i]]+env->Sys_Value_Jn[J_env_config_3[i]]+J_sysnew_config_3[i])/2)*gsl_sf_coupling_6j(J_sysnew_config_3[i], env->Sys_Value_Jn[J_env_config_3[i]], sys->Sys_Value_Jn[J_sys_config_3[i]], 2, sys->Sys_Value_Jn[J_sys_config_3[i]], env->Sys_Value_Jn[J_env_config_3[i]]);
	}

//------Create and Initialize six_j_2_config_3---------------------------------
  	six_j_2_config_3=new double [BlockNumber_for_TargetSpin_config_3];
  	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) 
		six_j_2_config_3[i]=J_envnew_config_3[i]*(J_envnew_config_3[i]/2.0+1.0)/4.0-para.S*(para.S/2.0+1.0)/2.0;
}

//============================Allocate 9j coefficients for the configuration 3===================================
inline void Super::Allocate_9j_config_3(Parameter &para, Super &space) {
//-----------------------------------------9j coefficient for config 3--------------------------------------------
  //------Create space
        nine_j_config_3=new double * [BlockNumber_for_TargetSpin_config_3];
        for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin; j++) {
                	if(J_sys[j]==J_sys_config_3[i] && J_env[j]==J_env_config_3[i]) 
                        	index++;
		}
                nine_j_config_3[i]=new double [index];
                for(int n=0; n<index; n++) {
                        nine_j_config_3[i][n]=(double) 0;
		}
        }

  //------Initialize 9-j coefficient
//-------------------------------------Obtained by the 9-j coefficient formula-----------------------------------
  	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {//<(J1,J2)J12;(Jn,Je)Jne|(J1,Jn)J1n;(J2,Je)J2e>
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin; j++) {
                	if(J_sys[j]==J_sys_config_3[i] && J_env[j]==J_env_config_3[i]) {
                        	nine_j_config_3[i][index++]=gsl_sf_coupling_9j(sys->Sys_Value_Jn[J_sys[j]], env->Sys_Value_Jn[J_env[j]], J_sysnew_config_3[i], para.S, para.S, J_envnew_config_3[i], space.sysnew_space->Sys_Value_Jn[J_sysnew[j]], space.envnew_space->Sys_Value_Jn[J_envnew[j]], QuantumNumber)*sqrt((J_sysnew_config_3[i]+1.0)*(J_envnew_config_3[i]+1.0)*(space.sysnew_space->Sys_Value_Jn[J_sysnew[j]]+1.0)*(space.envnew_space->Sys_Value_Jn[J_envnew[j]]+1.0));
			}
		}
        }

//----------------------------------------------------------------------------------------------------------------
//----------------------------------------inverse 9-j coefficient for config 3------------------------------------
  //------Create space
        nine_j_config_3_inverse=new double * [BlockNumber_for_TargetSpin];
        for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++) {
               		if(J_sys_config_3[j]==J_sys[i] && J_env_config_3[j]==J_env[i]) {
                        	index++;
			}
                }
                nine_j_config_3_inverse[i]=new double [index];
                for(int n=0; n<index; n++) {
                        nine_j_config_3_inverse[i][n]=(double) 0;
		}
        }

//-------------------------------------Obtained by the 9-j formula------------------------------------------------
  //------Initialize inverse 9-j coefficient <(J1,Jn)J1n;(J2,Je)J2e|(J1,J2)J12;(Jn,Je)Jne>
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++) {
                	if(J_sys_config_3[j]==J_sys[i] && J_env_config_3[j]==J_env[i]) {
                        	nine_j_config_3_inverse[i][index++]=gsl_sf_coupling_9j(sys->Sys_Value_Jn[J_sys[i]], para.S, space.sysnew_space->Sys_Value_Jn[J_sysnew[i]], env->Sys_Value_Jn[J_env[i]], para.S, space.envnew_space->Sys_Value_Jn[J_envnew[i]], J_sysnew_config_3[j], J_envnew_config_3[j], QuantumNumber)*sqrt((J_sysnew_config_3[j]+1.0)*(J_envnew_config_3[j]+1.0)*(space.sysnew_space->Sys_Value_Jn[J_sysnew[i]]+1.0)*(space.envnew_space->Sys_Value_Jn[J_envnew[i]]+1.0));
			}
		}
        }
//----------------------------------------------------------------------------------------------------------------
}

//====================================Free the space of constructing the Hamiltonian==============================
Super::~Super() {
	if(destruct=='s') {
//		cout<<"\n delete super space";
		delete [] J_sys;	delete [] J_env;	delete [] J_sysnew;	delete [] J_envnew;
		delete [] Dim_block;	

		delete [] WaveFunction; 		//delete [] WaveFunction_excited;

		for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
			delete [] WaveFunction_block[i];	//delete [] WaveFunction_excited_block[i];
		}
		delete [] WaveFunction_block;			//delete [] WaveFunction_excited_block;
	}

	else if(destruct=='d') { 
//		cout<<"\n delete super diagonalization";
          //------Delete the tables
                delete [] Table;		delete [] Interaction;
		delete [] Table_sys;		delete [] Table_env;

                delete [] Table_1to2_Num;       delete [] Table_1to2_Site;

		for(int i=0; i<BlockNumber_for_TargetSpin; i++) 
                        delete [] Table_2to1[i]; 
                delete [] Table_2to1;

	  //------Delete the variables of configurations 1 and 2
	     //------block numbers
		delete [] J_sys;                delete [] J_env;        delete [] J_sysnew;
		delete [] J_envnew;             delete [] Dim_block;

	     //------wave functions
		for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                	delete [] f1[i];        delete [] g1[i];	delete [] f2[i];	delete [] g2[i];
                }
                delete [] f1;	delete [] g1;	delete [] f2;	delete [] g2;

	     //------6j coefficients
                delete [] six_j_1_sys_n;        delete [] six_j_1_e_env;

	     //------9j coefficient
		for(int i=0; i<BlockNumber_for_TargetSpin; i++)
                	delete [] nine_j_config_2[i];
                delete [] nine_j_config_2;

	  //------Delete the variables of configuration 3
	     //------block numbers
		delete [] J_sys_config_3;       delete [] J_env_config_3;       delete [] J_sysnew_config_3;
                delete [] J_envnew_config_3;    delete [] Dim_block_config_3;

	     //------wave functions
		for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
			delete [] f3[i];	delete [] g3[i];
		}
		delete [] f3;			delete [] g3;

         //-------Delete S_Dia and S_M_Dia
                for(int i=0; i<sys->Sys_Number_Jn; i++) {
                        delete [] S_Dia_sys[i];
                }
                delete [] S_Dia_sys;

                for(int i=0; i<sys->Sys_Number_Jn-1; i++) {
                        delete [] S_M_Dia_sys[i];
                }
                delete [] S_M_Dia_sys;

                for(int i=0; i<env->Sys_Number_Jn; i++) {
                        delete [] S_Dia_env[i];
                }
                delete [] S_Dia_env;

                for(int i=0; i<env->Sys_Number_Jn-1; i++) {
                        delete [] S_M_Dia_env[i];
                }
                delete [] S_M_Dia_env;

	     //------6j coefficients
		for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) 
                	delete [] six_j_1_config_3[i];     
		delete [] six_j_1_config_3;

		delete [] six_j_1_config_3_diaele;
		delete [] six_j_2_config_3;
 
	     //------9j coefficients
		for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) 
                        delete [] nine_j_config_3[i];
                delete [] nine_j_config_3;    

	        for(int i=0; i<BlockNumber_for_TargetSpin; i++) 
			delete [] nine_j_config_3_inverse[i];
		delete [] nine_j_config_3_inverse;
	}
	
	else if(destruct=='m') {
                delete [] J_sys;                delete [] J_env;        delete [] J_sysnew;                
		delete [] J_envnew;             delete [] Dim_block;

                delete [] six_j_1_sys_n;        delete [] six_j_1_e_env;

                for(int i=0; i<BlockNumber_for_TargetSpin; i++)     
	                delete [] nine_j_config_2[i];
        	        delete [] nine_j_config_2;

                delete [] J_sys_config_3;       delete [] J_env_config_3;       delete [] J_sysnew_config_3;
                delete [] J_envnew_config_3;    delete [] Dim_block_config_3;

                for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++)        
	                delete [] six_j_1_config_3[i];
        	delete [] six_j_1_config_3;

                delete [] six_j_2_config_3;

                for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++)        
	                delete [] nine_j_config_3[i];
        	delete [] nine_j_config_3;

                for(int i=0; i<BlockNumber_for_TargetSpin; i++)    
                        delete [] nine_j_config_3_inverse[i];
                delete [] nine_j_config_3_inverse;
	}
}

//===========================================getMatrixDiagonalElement============================================
void Super::getMatrixDiagElement(double *f, const int &dim) {
//--------------------------------------Realization by direct multiplication-------------------------------------
//	for(int i=0; i<dim; i++)
//		f[i]+=1.0;

//------entries of the diagonal elements of the Hamiltonian matrix-----------------------------------------------
	int a_sys, a_env, Num_six_j, old_sys, old_env;

    //------Contributions from H_sys, H_env, H_sys_ns, and H_env_ne----------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
		Num_six_j=i*BlockNumber_for_TargetSpin+i;

                for(int j=0; j<Dim_block[i]; j++) {
                        a_sys=j%sys->Sys_SubBlockNumber_Jn[J_sys[i]];
                        a_env=j/sys->Sys_SubBlockNumber_Jn[J_sys[i]];

                        old_sys=a_sys*sys->Sys_SubBlockNumber_Jn[J_sys[i]]+a_sys;
                        old_env=a_env*env->Sys_SubBlockNumber_Jn[J_env[i]]+a_env;

		     //------contributions from H_sys and H_env--------------------------------------------------
                        f[Table_2to1[i][j]]+=(sys->H[J_sys[i]][old_sys]+env->H[J_env[i]][old_env]);

                     //------contributions from H_sys_ns and H_env_ne--------------------------------------------
                     	SiteNum=N*sys->TotSiteNo;
                        for(site_s=0; site_s<operator_number_sys; site_s++)
                        if(Table[SiteNum+Table_sys[site_s]]==1) {
                                f[Table_2to1[i][j]]+=Interaction[SiteNum+Table_sys[site_s]]*six_j_1_sys_n[Num_six_j]*sys->S_Dia[site_s][J_sys[i]][old_sys];
                        }
                
                        SiteNum=N*(StartSite-env->TotSiteNo)+StartSite;
                        for(site_e=0; site_e<operator_number_env; site_e++)
                        if(Table[SiteNum-Table_env[site_e]]==1) {
                                f[Table_2to1[i][j]]+=Interaction[SiteNum-Table_env[site_e]]*six_j_1_e_env[Num_six_j]*env->S_Dia[site_e][J_env[i]][old_env];
                        }
		}
	}

     //------contributions from H_sys_ne and H_env_ns------------------------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
		index=0;

		for(int i_p=0; i_p<BlockNumber_for_TargetSpin; i_p++) 
		if(J_sys[i_p]==J_sys[i] && J_env[i_p]==J_env[i]) {
			Num_six_j=i_p*BlockNumber_for_TargetSpin+i_p;

			for(int j=0; j<Dim_block[i]; j++) {
				a_sys=j%sys->Sys_SubBlockNumber_Jn[J_sys[i]];
				a_env=j/sys->Sys_SubBlockNumber_Jn[J_sys[i]];

				old_sys=a_sys*sys->Sys_SubBlockNumber_Jn[J_sys[i]]+a_sys;
				old_env=a_env*env->Sys_SubBlockNumber_Jn[J_env[i]]+a_env;

			    //------contributions from Interactions between system and ne------------------------
				SiteNum=N*(StartSite-env->TotSiteNo);
				for(site_s=0; site_s<operator_number_sys; site_s++)
				if(Table[SiteNum+Table_sys[site_s]]==1) {			
					f[Table_2to1[i][j]]+=Interaction[SiteNum+Table_sys[site_s]]*nine_j_config_2[i][index]*nine_j_config_2[i][index]*six_j_1_sys_n[Num_six_j]*sys->S_Dia[site_s][J_sys[i]][old_sys];
				}

			    //------contributions from Interactions between environment and ns-------------------
				SiteNum=N*sys->TotSiteNo+StartSite;
				for(site_e=0; site_e<operator_number_env; site_e++)
				if(Table[SiteNum-Table_env[site_e]]==1) {
					f[Table_2to1[i][j]]+=Interaction[SiteNum-Table_env[site_e]]*nine_j_config_2[i][index]*nine_j_config_2[i][index]*six_j_1_e_env[Num_six_j]*env->S_Dia[site_e][J_env[i]][old_env];
				}
			}
		
			index++;
		}
	}

    //------Contributions from H_sys_env and H_n_e---------------------------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
		index=0;

		for(int i_p=0; i_p<BlockNumber_for_TargetSpin_config_3; i_p++)
		if(J_sys_config_3[i_p]==J_sys[i] && J_env_config_3[i_p]==J_env[i]) {

			for(int j=0; j<Dim_block[i]; j++) {
				a_sys=j%sys->Sys_SubBlockNumber_Jn[J_sys[i]];
				a_env=j/sys->Sys_SubBlockNumber_Jn[J_sys[i]];

				old_sys=a_sys*sys->Sys_SubBlockNumber_Jn[J_sys[i]]+a_sys;
				old_env=a_env*env->Sys_SubBlockNumber_Jn[J_env[i]]+a_env;

			     //------contributions from Interactions between system and environment--------------
				for(site_s=0; site_s<operator_number_sys; site_s++)
				for(site_e=0; site_e<operator_number_env; site_e++)
				if(Table[N*Table_sys[site_s]+StartSite-Table_env[site_e]]==1) {
					f[Table_2to1[i][j]]+=Interaction[N*Table_sys[site_s]+StartSite-Table_env[site_e]]*nine_j_config_3_inverse[i][index]*nine_j_config_3_inverse[i][index]*six_j_1_config_3_diaele[i_p]*sys->S_Dia[site_s][J_sys[i]][old_sys]*env->S_Dia[site_e][J_env[i]][old_env];
				}

			     //------contributions from Interaction between ns and ne----------------------------
				if(Table[N*sys->TotSiteNo+StartSite-env->TotSiteNo]==1)
					f[Table_2to1[i][j]]+=Interaction[N*sys->TotSiteNo+StartSite-env->TotSiteNo]*nine_j_config_3_inverse[i][index]*nine_j_config_3_inverse[i][index]*six_j_2_config_3[i_p];

			}

			index++;
		}
	}
}

//=======================================Matrix-Vector Multiplication=============================================
void Super::H_V(const double *f, double *g, const int &dim) {
  //------Initialize the vectors----------------------------------------------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) 
	for(int j=0; j<Dim_block[i]; j++) {
		f1[i][j]=0.0;	g1[i][j]=0.0;
		f2[i][j]=0.0;	g2[i][j]=0.0;
	}
	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++)
	for(int j=0; j<Dim_block_config_3[i]; j++) {
		f3[i][j]=0.0;    g3[i][j]=0.0;
	}

  //------Read from f to f1 and initialize g to zero--------------------------------------------------------------
	for(int i=0; i<dim; i++) {
		g[i]=0.0;	f1[Table_1to2_Num[i]][Table_1to2_Site[i]]=f[i];
	}
  
  //------Read from f1 to f2--------------------------------------------------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
		index=0;
                for(int j=0; j<BlockNumber_for_TargetSpin; j++) 
               	if(J_sys[j]==J_sys[i] && J_env[j]==J_env[i]) {
			daxpy_(&Dim_block[i], &nine_j_config_2[i][index++], f1[j], &inc, f2[i], &inc);
                }
        }

  //------Read from f1 to f3--------------------------------------------------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
		index=0;	
		for(int j=0; j<BlockNumber_for_TargetSpin; j++) 
		if(J_sys[j]==J_sys_config_3[i] && J_env[j]==J_env_config_3[i]) {
			daxpy_(&Dim_block_config_3[i], &nine_j_config_3[i][index++], f1[j], &inc, f3[i], &inc);
		}
	}

  //------The first configuration: sys+ns+ne+env-----------------------------------------------------------------
	H_Sys_and_Env();//H of system and environment
	H_Sys_Ns();	//H between system sites and ns
	H_Ne_Env();	//H between environment sites and ne

  //------The second configuration: sys+ne+ns+env----------------------------------------------------------------
	H_Sys_Ne();	//H between system sites and ne
	H_Ns_Env();	//H between environment sites and ns 

  //------Read from g2 to g1-------------------------------------------------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
                index=0;       
                for(int j=0; j<BlockNumber_for_TargetSpin; j++)
                if(J_sys[j]==J_sys[i] && J_env[j]==J_env[i]) {
                        daxpy_(&Dim_block[i], &nine_j_config_2[i][index++], g2[j], &inc, g1[i], &inc);
		}
        }
 
  //------The third configuration: sys+env+ns+ne-----------------------------------------------------------------
	H_Ns_Ne();	//H between ns and ne
	H_Sys_Env();	//H between system and environment sites

  //------Read from g3 to g1-------------------------------------------------------------------------------------
  	for(int i=0; i<BlockNumber_for_TargetSpin; i++) {
		index=0;
		for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++) 
		if(J_sys_config_3[j]==J_sys[i] && J_env_config_3[j]==J_env[i]) {		
			daxpy_(&Dim_block[i], &nine_j_config_3_inverse[i][index++], g3[j], &inc, g1[i], &inc);
		}
	}
  
  //------Read from g1 to g--------------------------------------------------------------------------------------
	for(int i=0; i<BlockNumber_for_TargetSpin; i++)
	for(int j=0; j<Dim_block[i]; j++)
		g[Table_2to1[i][j]]=g1[i][j];
}

//=======================================H Hamiltonian acting on the vector f====================================
//		g[a1,a2]=H_sys[a1,a1']*f[a1',a2]		g[a1,a2]=f[a1,a2']*H_env[a2',a2]
//===============================================================================================================
inline void Super::H_Sys_and_Env() {

	for(int l=0; l<BlockNumber_for_TargetSpin; l++) {
		dsymm_(&side_L, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &alpha_p, sys->H[J_sys[l]], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], f1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &beta, g1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
		dsymm_(&side_R, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &alpha_p, env->H[J_env[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], f1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &beta, g1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
	}

}

//=============================H between systems sites and ns acting on the vector f=============================
inline void Super::H_Sys_Ns() {

	SiteNum=N*sys->TotSiteNo;	//The added site n_s with the number N*sys->TotSiteNo in Table

        for( int i = 0; i < sys->Sys_Number_Jn; i++ ) {

                dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i];

                for( int j = 0; j < dimension; j++ )

                        S_Dia_sys[i][j] = 0.0;

        }

        for( int i = 0; i < sys->Sys_Number_Jn - 1; i++ ) {

                dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i+1];

                for( int j = 0; j < dimension; j++ )

                        S_M_Dia_sys[i][j] = 0.0;

        }

        for( site_s = 0; site_s < operator_number_sys; site_s++ )
        if( Table[ SiteNum + Table_sys[site_s]] != 0 ) {

                for( int i = 0; i < sys->Sys_Number_Jn; i++ ) {

                        alpha = Interaction[ SiteNum + Table_sys[site_s]];
                        dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i];
                        daxpy_(&dimension, &alpha, sys->S_Dia[site_s][i], &inc, S_Dia_sys[i], &inc);

                }

                for( int i = 0; i < sys->Sys_Number_Jn - 1; i++ ) {

                        alpha = Interaction[ SiteNum + Table_sys[site_s]];
                        dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i+1];
                        daxpy_(&dimension, &alpha, sys->S_M_Dia[site_s][i], &inc, S_M_Dia_sys[i], &inc);

                }

        }


	for(int l=0; l<BlockNumber_for_TargetSpin; l++) {//Order number of function "g1"

		for(int i=0; i<BlockNumber_for_TargetSpin; i++)//Order number of function "f1"
		if(J_sysnew[i]==J_sysnew[l] && J_envnew[i]==J_envnew[l] && J_env[i]==J_env[l]) {

			if(i==l && sys->Sys_Value_Jn[J_sys[i]]!=0) {//J_sys[i]==J_sys[l]
				alpha=six_j_1_sys_n[l*BlockNumber_for_TargetSpin+i];
                                dsymm_(&side_L, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &alpha, S_Dia_sys[J_sys[l]], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], f1[i], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &beta, g1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                        else if(J_sys[i]-J_sys[l]==1 && sys->Sys_Value_Jn[J_sys[i]]-sys->Sys_Value_Jn[J_sys[l]]==2) {
                                alpha=six_j_1_sys_n[l*BlockNumber_for_TargetSpin+i];
                                dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], &alpha, S_M_Dia_sys[J_sys[l]], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], f1[i], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], &beta, g1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                        else if(J_sys[l]-J_sys[i]==1 && sys->Sys_Value_Jn[J_sys[l]]-sys->Sys_Value_Jn[J_sys[i]]==2) {
                                alpha=-six_j_1_sys_n[l*BlockNumber_for_TargetSpin+i];
                                dgemm_(&trans_T, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], &alpha, S_M_Dia_sys[J_sys[i]], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], f1[i], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], &beta, g1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
			} 
		}
	}

}

//==========================H between environment sites and ne acting on the vector f============================
inline void Super::H_Ne_Env() {

	SiteNum=N*(StartSite-env->TotSiteNo)+StartSite;

        for( int i = 0; i < env->Sys_Number_Jn; i++ ) {

                dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i];

                for( int j = 0; j < dimension; j++ )

                        S_Dia_env[i][j] = 0.0;

        }

        for( int i = 0; i < env->Sys_Number_Jn - 1; i++ ) {

                dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i+1];

                for( int j = 0; j < dimension; j++ )

                        S_M_Dia_env[i][j] = 0.0;

        }

        for( site_e = 0; site_e < operator_number_env; site_e++ )
        if( Table[ SiteNum - Table_env[site_e]] != 0 ) {

                for( int i = 0; i < env->Sys_Number_Jn; i++ ) {

                        alpha = Interaction[ SiteNum - Table_env[site_e] ];
                        dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i];
                        daxpy_(&dimension, &alpha, env->S_Dia[site_e][i], &inc, S_Dia_env[i], &inc);

                }

                for( int i = 0; i < env->Sys_Number_Jn - 1; i++ ) {

                        alpha = Interaction[ SiteNum - Table_env[site_e] ];
                        dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i+1];
                        daxpy_(&dimension, &alpha, env->S_M_Dia[site_e][i], &inc, S_M_Dia_env[i], &inc);

                }

        }

        for(int l=0; l<BlockNumber_for_TargetSpin; l++) {//Order number of function "g1"

                for(int i=0; i<BlockNumber_for_TargetSpin; i++)//Order number of function "f1"
                if(J_sysnew[i]==J_sysnew[l] && J_envnew[i]==J_envnew[l] && J_sys[i]==J_sys[l]) {
                        if(i==l && env->Sys_Value_Jn[J_env[i]]!=0)  {
                                alpha=six_j_1_e_env[l*BlockNumber_for_TargetSpin+i];
                                dsymm_(&side_R, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &alpha, S_Dia_env[J_env[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], f1[i], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &beta, g1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                        else if(J_env[i]-J_env[l]==1 && env->Sys_Value_Jn[J_env[i]]-env->Sys_Value_Jn[J_env[l]]==2) {
                                alpha=six_j_1_e_env[l*BlockNumber_for_TargetSpin+i];
                                dgemm_(&trans_N, &trans_T, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &env->Sys_SubBlockNumber_Jn[J_env[i]], &alpha, f1[i], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], S_M_Dia_env[J_env[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &beta, g1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                        else if(J_env[l]-J_env[i]==1 && env->Sys_Value_Jn[J_env[l]]-env->Sys_Value_Jn[J_env[i]]==2) {
                                alpha=-six_j_1_e_env[l*BlockNumber_for_TargetSpin+i];
                                dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &env->Sys_SubBlockNumber_Jn[J_env[i]], &alpha, f1[i], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], S_M_Dia_env[J_env[i]], &env->Sys_SubBlockNumber_Jn[J_env[i]], &beta, g1[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                }
        }

}

//===========================H between system sites and ne site acting on f2=====================================
inline void Super::H_Sys_Ne() {

	SiteNum=N*(StartSite-env->TotSiteNo);

        for( int i = 0; i < sys->Sys_Number_Jn; i++ ) {

                dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i];

                for( int j = 0; j < dimension; j++ )

                        S_Dia_sys[i][j] = 0.0;

        }

        for( int i = 0; i < sys->Sys_Number_Jn - 1; i++ ) {

                dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i+1];

                for( int j = 0; j < dimension; j++ )

                        S_M_Dia_sys[i][j] = 0.0;

        }

        for( site_s = 0; site_s < operator_number_sys; site_s++ )
        if( Table[ SiteNum + Table_sys[site_s]] != 0 ) {

                for( int i = 0; i < sys->Sys_Number_Jn; i++ ) {

                        alpha = Interaction[ SiteNum + Table_sys[site_s]];
                        dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i];
                        daxpy_(&dimension, &alpha, sys->S_Dia[site_s][i], &inc, S_Dia_sys[i], &inc);

                }

                for( int i = 0; i < sys->Sys_Number_Jn - 1; i++ ) {

                        alpha = Interaction[ SiteNum + Table_sys[site_s]];
                        dimension = sys->Sys_SubBlockNumber_Jn[i] * sys->Sys_SubBlockNumber_Jn[i+1];
                        daxpy_(&dimension, &alpha, sys->S_M_Dia[site_s][i], &inc, S_M_Dia_sys[i], &inc);

                }

        }

        for(int l=0; l<BlockNumber_for_TargetSpin; l++) {//Number of function "g2"

	        for(int i=0; i<BlockNumber_for_TargetSpin; i++)//Number of function "f2"
                if(J_sysnew[i]==J_sysnew[l] && J_envnew[i]==J_envnew[l] && J_env[i]==J_env[l]) {
       	        	if(i==l && sys->Sys_Value_Jn[J_sys[i]]!=0) {
				alpha=six_j_1_sys_n[l*BlockNumber_for_TargetSpin+i];
                                dsymm_(&side_L, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &alpha, S_Dia_sys[J_sys[l]], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], f2[i], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &beta, g2[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                        else if(J_sys[i]-J_sys[l]==1 && sys->Sys_Value_Jn[J_sys[i]]-sys->Sys_Value_Jn[J_sys[l]]==2) {
                                alpha=six_j_1_sys_n[l*BlockNumber_for_TargetSpin+i];
                                dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], &alpha, S_M_Dia_sys[J_sys[l]], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], f2[i], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], &beta, g2[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                        else if(J_sys[l]-J_sys[i]==1 && sys->Sys_Value_Jn[J_sys[l]]-sys->Sys_Value_Jn[J_sys[i]]==2) {
                                alpha=-six_j_1_sys_n[l*BlockNumber_for_TargetSpin+i];
                                dgemm_(&trans_T, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], &alpha, S_M_Dia_sys[J_sys[i]], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], f2[i], &sys->Sys_SubBlockNumber_Jn[J_sys[i]], &beta, g2[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                }
        }

}

//===========================H between environment sites and ns acting in f2=====================================
inline void Super::H_Ns_Env() {

	SiteNum=N*sys->TotSiteNo+StartSite;

        for( int i = 0; i < env->Sys_Number_Jn; i++ ) {

                dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i];

                for( int j = 0; j < dimension; j++ )

                        S_Dia_env[i][j] = 0.0;

        }

        for( int i = 0; i < env->Sys_Number_Jn - 1; i++ ) {

                dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i+1];

                for( int j = 0; j < dimension; j++ )

                        S_M_Dia_env[i][j] = 0.0;

        }

        for( site_e = 0; site_e < operator_number_env; site_e++ )
        if( Table[ SiteNum - Table_env[site_e]] != 0 ) {

                for( int i = 0; i < env->Sys_Number_Jn; i++ ) {

                        alpha = Interaction[ SiteNum - Table_env[site_e] ];
                        dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i];
                        daxpy_(&dimension, &alpha, env->S_Dia[site_e][i], &inc, S_Dia_env[i], &inc);

                }

                for( int i = 0; i < env->Sys_Number_Jn - 1; i++ ) {

                        alpha = Interaction[ SiteNum - Table_env[site_e] ];
                        dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i+1];
                        daxpy_(&dimension, &alpha, env->S_M_Dia[site_e][i], &inc, S_M_Dia_env[i], &inc);

                }

        }

        for(int l=0; l<BlockNumber_for_TargetSpin; l++) {//number of function "g2"

                for(int i=0; i<BlockNumber_for_TargetSpin; i++)//number of function "f2"
                if(J_sysnew[i]==J_sysnew[l] && J_envnew[i]==J_envnew[l] && J_sys[i]==J_sys[l]) {

                        if(i==l && env->Sys_Value_Jn[J_env[i]]!=0) {
                                alpha=six_j_1_e_env[l*BlockNumber_for_TargetSpin+i];
                                dsymm_(&side_R, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &alpha, S_Dia_env[J_env[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], f2[i], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &beta, g2[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                        else if(J_env[i]-J_env[l]==1 && env->Sys_Value_Jn[J_env[i]]-env->Sys_Value_Jn[J_env[l]]==2) {
                                alpha=six_j_1_e_env[l*BlockNumber_for_TargetSpin+i];
                                dgemm_(&trans_N, &trans_T, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &env->Sys_SubBlockNumber_Jn[J_env[i]], &alpha, f2[i], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], S_M_Dia_env[J_env[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &beta, g2[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                        else if(J_env[l]-J_env[i]==1 && env->Sys_Value_Jn[J_env[l]]-env->Sys_Value_Jn[J_env[i]]==2) {
                                alpha=-six_j_1_e_env[l*BlockNumber_for_TargetSpin+i];
                                dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys[l]], &env->Sys_SubBlockNumber_Jn[J_env[l]], &env->Sys_SubBlockNumber_Jn[J_env[i]], &alpha, f2[i], &sys->Sys_SubBlockNumber_Jn[J_sys[l]], S_M_Dia_env[J_env[i]], &env->Sys_SubBlockNumber_Jn[J_env[i]], &beta, g2[l], &sys->Sys_SubBlockNumber_Jn[J_sys[l]]);
                        }
                }
        }

}

//==========================================H between ns and ne acting on f3=====================================
inline void Super::H_Ns_Ne() {

  	if(Table[N*sys->TotSiteNo+StartSite-env->TotSiteNo] != 0 )
	for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {

		alpha=six_j_2_config_3[i]*Interaction[N*sys->TotSiteNo+StartSite-env->TotSiteNo];
		daxpy_(&Dim_block_config_3[i], &alpha, f3[i], &inc, g3[i], &inc);

	}

}

//====================================H between system and environment sites acting on f3========================
inline void Super::H_Sys_Env() {

	int mul;
	double six_j;

	for(site_s=0; site_s<operator_number_sys; site_s++) {

                for( int i = 0; i < env->Sys_Number_Jn; i++ ) {

                        dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i];

                        for( int j = 0; j < dimension; j++ )

                                S_Dia_env[i][j] = 0.0;

                }

                for( int i = 0; i < env->Sys_Number_Jn - 1; i++ ) {

                        dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i+1];

                        for( int j = 0; j < dimension; j++ )

                                S_M_Dia_env[i][j] = 0.0;

                }

                for( site_e = 0; site_e < operator_number_env; site_e++ )
                if( Table[N*Table_sys[site_s] + StartSite - Table_env[site_e]] != 0 ) {

                        for( int i = 0; i < env->Sys_Number_Jn; i++ ) {

                                alpha = Interaction[ N * Table_sys[site_s] + StartSite - Table_env[site_e] ];
                                dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i];
                                daxpy_(&dimension, &alpha, env->S_Dia[site_e][i], &inc, S_Dia_env[i], &inc);

                        }

                        for( int i = 0; i < env->Sys_Number_Jn - 1; i++ ) {

                                alpha = Interaction[ N * Table_sys[site_s] + StartSite - Table_env[site_e] ];
                                dimension = env->Sys_SubBlockNumber_Jn[i] * env->Sys_SubBlockNumber_Jn[i+1];
                                daxpy_(&dimension, &alpha, env->S_M_Dia[site_e][i], &inc, S_M_Dia_env[i], &inc);

                        }

                }

		for(int i=0; i<BlockNumber_for_TargetSpin_config_3; i++) {
			index=0;
			for(int j=0; j<BlockNumber_for_TargetSpin_config_3; j++) 
			if(J_sysnew_config_3[j]==J_sysnew_config_3[i] && J_envnew_config_3[j]==J_envnew_config_3[i] && abs(sys->Sys_Value_Jn[J_sys_config_3[i]]-sys->Sys_Value_Jn[J_sys_config_3[j]])<=2 && abs(env->Sys_Value_Jn[J_env_config_3[i]]-env->Sys_Value_Jn[J_env_config_3[j]])<=2) {
			//------1
				if(i==j && sys->Sys_Value_Jn[J_sys_config_3[i]]!=0 && env->Sys_Value_Jn[J_env_config_3[i]]!=0) {
					alpha=six_j_1_config_3[i][index];
					mul=sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]*env->Sys_SubBlockNumber_Jn[J_env_config_3[i]];
					double * f_sub=new double [mul];
					for(int s=0; s<mul; s++)	f_sub[s]=(double) 0;
					dsymm_(&side_R, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &alpha_p, S_Dia_env[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], f3[j], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &beta_p, f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);				
					dsymm_(&side_L, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &alpha, sys->S_Dia[site_s][J_sys_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &beta, g3[i], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
					delete [] f_sub;
				}
			//------2
				else if(J_sys_config_3[i]==J_sys_config_3[j] && sys->Sys_Value_Jn[J_sys_config_3[i]]!=0 && J_env_config_3[j]-J_env_config_3[i]==1 && env->Sys_Value_Jn[J_env_config_3[j]]-env->Sys_Value_Jn[J_env_config_3[i]]==2) {
					alpha=six_j_1_config_3[i][index];
					mul=sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]*env->Sys_SubBlockNumber_Jn[J_env_config_3[i]];	
					double * f_sub=new double [mul];
                                       	for(int s=0; s<mul; s++)    f_sub[s]=(double) 0;
					dgemm_(&trans_N, &trans_T, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[j]], &alpha_p, f3[j], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], S_M_Dia_env[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &beta_p, f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
					dsymm_(&side_L, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &alpha, sys->S_Dia[site_s][J_sys_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &beta, g3[i], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
					delete [] f_sub;
				}	
			//------3
				else if(J_sys_config_3[i]==J_sys_config_3[j] && sys->Sys_Value_Jn[J_sys_config_3[i]]!=0 && J_env_config_3[i]-J_env_config_3[j]==1 && env->Sys_Value_Jn[J_env_config_3[i]]-env->Sys_Value_Jn[J_env_config_3[j]]==2) {
                                       	alpha=-six_j_1_config_3[i][index];
                                       	mul=sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]*env->Sys_SubBlockNumber_Jn[J_env_config_3[i]];
                                       	double * f_sub=new double [mul];
                                       	for(int s=0; s<mul; s++)    f_sub[s]=(double) 0;
                                       	dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[j]], &alpha_p, f3[j], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], S_M_Dia_env[J_env_config_3[j]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[j]], &beta_p, f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
                                       	dsymm_(&side_L, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &alpha, sys->S_Dia[site_s][J_sys_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &beta, g3[i], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
                                       	delete [] f_sub;
				}
			//------4
				else if(J_sys_config_3[j]-J_sys_config_3[i]==1 && sys->Sys_Value_Jn[J_sys_config_3[j]]-sys->Sys_Value_Jn[J_sys_config_3[i]]==2 && J_env_config_3[i]==J_env_config_3[j] && env->Sys_Value_Jn[J_env_config_3[i]]!=0) {
					alpha=six_j_1_config_3[i][index];
                                       	mul=sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]*env->Sys_SubBlockNumber_Jn[J_env_config_3[i]];
                                       	double * f_sub=new double [mul];
                                       	for(int s=0; s<mul; s++)    f_sub[s]=(double) 0;
					dsymm_(&side_R, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &alpha_p, S_Dia_env[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], f3[j], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &beta_p, f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]);
					dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &alpha, sys->S_M_Dia[site_s][J_sys_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &beta, g3[i], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
					delete [] f_sub;
				}	
			//------5
				else if(J_sys_config_3[j]-J_sys_config_3[i]==1 && sys->Sys_Value_Jn[J_sys_config_3[j]]-sys->Sys_Value_Jn[J_sys_config_3[i]]==2 && J_env_config_3[j]-J_env_config_3[i]==1 && env->Sys_Value_Jn[J_env_config_3[j]]-env->Sys_Value_Jn[J_env_config_3[i]]==2) {
					alpha=six_j_1_config_3[i][index];
                                       	mul=sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]*env->Sys_SubBlockNumber_Jn[J_env_config_3[i]];
                                       	double * f_sub=new double [mul];
                                       	for(int s=0; s<mul; s++)    f_sub[s]=(double) 0;
					dgemm_(&trans_N, &trans_T, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[j]], &alpha_p, f3[j], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], S_M_Dia_env[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &beta_p, f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]);
					dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &alpha, sys->S_M_Dia[site_s][J_sys_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &beta, g3[i], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
                                       	delete [] f_sub;
				}	
			//------6
				else if(J_sys_config_3[j]-J_sys_config_3[i]==1 && sys->Sys_Value_Jn[J_sys_config_3[j]]-sys->Sys_Value_Jn[J_sys_config_3[i]]==2 && J_env_config_3[i]-J_env_config_3[j]==1 && env->Sys_Value_Jn[J_env_config_3[i]]-env->Sys_Value_Jn[J_env_config_3[j]]==2) {
                                       	alpha=-six_j_1_config_3[i][index];
                                       	mul=sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]*env->Sys_SubBlockNumber_Jn[J_env_config_3[i]];
                                       	double * f_sub=new double [mul];
                                       	for(int s=0; s<mul; s++)    f_sub[s]=(double) 0;
                                       	dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[j]], &alpha_p, f3[j], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], S_M_Dia_env[J_env_config_3[j]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[j]], &beta_p, f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]);
                                       	dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &alpha, sys->S_M_Dia[site_s][J_sys_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &beta, g3[i], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
                                       	delete [] f_sub;
				}	
			//------7
				else if(J_sys_config_3[i]-J_sys_config_3[j]==1 && sys->Sys_Value_Jn[J_sys_config_3[i]]-sys->Sys_Value_Jn[J_sys_config_3[j]]==2 && J_env_config_3[i]==J_env_config_3[j] && env->Sys_Value_Jn[J_env_config_3[i]]!=0) {
                                       	alpha=-six_j_1_config_3[i][index];
                                       	mul=sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]*env->Sys_SubBlockNumber_Jn[J_env_config_3[i]];
                                       	double * f_sub=new double [mul];
                                       	for(int s=0; s<mul; s++)    f_sub[s]=(double) 0;
                                       	dsymm_(&side_R, &uplo, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &alpha_p, S_Dia_env[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], f3[j], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &beta_p, f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]);
                                       	dgemm_(&trans_T, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &alpha, sys->S_M_Dia[site_s][J_sys_config_3[j]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &beta, g3[i], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
                                       	delete [] f_sub;
				}		
			//------8
				else if(J_sys_config_3[i]-J_sys_config_3[j]==1 && sys->Sys_Value_Jn[J_sys_config_3[i]]-sys->Sys_Value_Jn[J_sys_config_3[j]]==2 && J_env_config_3[j]-J_env_config_3[i]==1 && env->Sys_Value_Jn[J_env_config_3[j]]-env->Sys_Value_Jn[J_env_config_3[i]]==2) {
                                       	alpha=-six_j_1_config_3[i][index];
                                       	mul=sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]*env->Sys_SubBlockNumber_Jn[J_env_config_3[i]];
                                       	double * f_sub=new double [mul];
                                       	for(int s=0; s<mul; s++)    f_sub[s]=(double) 0;
                                       	dgemm_(&trans_N, &trans_T, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[j]], &alpha_p, f3[j], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], S_M_Dia_env[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &beta_p, f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]);
                                       	dgemm_(&trans_T, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &alpha, sys->S_M_Dia[site_s][J_sys_config_3[j]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &beta, g3[i], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
                                       	delete [] f_sub;
				}	
			//------9
				else if(J_sys_config_3[i]-J_sys_config_3[j]==1 && sys->Sys_Value_Jn[J_sys_config_3[i]]-sys->Sys_Value_Jn[J_sys_config_3[j]]==2 && J_env_config_3[i]-J_env_config_3[j]==1 && env->Sys_Value_Jn[J_env_config_3[i]]-env->Sys_Value_Jn[J_env_config_3[j]]==2) {
					alpha=six_j_1_config_3[i][index];
                                       	mul=sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]*env->Sys_SubBlockNumber_Jn[J_env_config_3[i]];
                                       	double * f_sub=new double [mul];
                                       	for(int s=0; s<mul; s++)    f_sub[s]=(double) 0;
                                       	dgemm_(&trans_N, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[j]], &alpha_p, f3[j], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], S_M_Dia_env[J_env_config_3[j]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[j]], &beta_p, f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]]);
                                       	dgemm_(&trans_T, &trans_N, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]], &env->Sys_SubBlockNumber_Jn[J_env_config_3[i]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &alpha, sys->S_M_Dia[site_s][J_sys_config_3[j]], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], f_sub, &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[j]], &beta, g3[i], &sys->Sys_SubBlockNumber_Jn[J_sys_config_3[i]]);
                                       	delete [] f_sub;
				}
				index++;	//index++ must be put here, it can't be include in the subroutines else if() below, beacause some of the 6j-coefficients should be not used!!!
			}	
		}
	}
}

//=====================================Normalize the WaveFunction================================================
void Super::NormalizedCopy(const double *f, double *g) {
        double res=(double) 0 ;
        for(int i=0; i<Dim; i++) res+=f[i]*f[i];
                res=sqrt(res);
        for(int j=0; j<Dim; j++)
                g[j]=f[j]/res;
}
//=====================================================END=======================================================
