#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
using namespace std;

#include"parameter.h"

//==================================Transmit the parameters in this class========================================
Parameter::Parameter(char &sign, const int &max_num, const int &s, const int &total_j, const int &statenokept, const int &n_u, const int &n_x, const int &n_y, const int &n, char &geometry, const double &j_n, const double &j_nn, const double &j_nnn) {

//-----------------------Transmit the parameters in main() to the variables defined in this class----------------
    S=s;            
	Total_j=total_j;        
	StateNoKept=statenokept;	
	N_u=n_u;	
	N_x=n_x;	
	N_y=n_y;	
	N=n;			
	untruncated_site=2; //denote the number of untruncated sites
	total_site=0;	
	Max_Num=max_num;	
	Sign=sign;
	Geometry=geometry;			
	J_n=j_n;			
	J_nn=j_nn;	
	J_nnn=j_nnn;

//------------------------------------Build the Table of interaction---------------------------------------------
	TotalSite=N*N;

	Table=new int [TotalSite];
	Interaction=new double [TotalSite];	
	for(int i=0; i<TotalSite; i++) {
		Table[i]=0;	Interaction[i]=0.0;
	}
	
	Build_Table_KagomeLattice();
}

//====================================Kagome Lattice==================================
inline void Parameter::Build_Table_KagomeLattice() {

	int site_1, site_2;
		//cout << "------------- Jz 方向 ------------------------------" <<endl;
        for(int i=0; i<N_x; i++)
        for(int j=0; j<N_y; j++) {

		site_1 = N_y * N_u * i + j * N_u;  site_2 = site_1 + 1;

		//cout << "site_1: " << site_1 << ", site_2: " << site_2 << endl; 

        Table[N*site_1 + site_2] = Table[N*site_2 + site_1] = 1;
        Interaction[N*site_1 + site_2] = Interaction[N*site_2 + site_1] = J_nnn;

        }                                                       
		//
		//cout << "----------------[Jy 方向 up layer]---------------------" << endl; 
        for(int i=0; i<N_x; i++)
        for(int j=0; j<N_y-1; j++) {

		site_1 = N_y * N_u * i + j * N_u;  site_2 = site_1 + 2;
		//cout << "site_1: " << site_1 << ", site_2: " << site_2 << endl; 

        Table[N*site_1 + site_2] = Table[N*site_2 + site_1] = 1;
        Interaction[N*site_1 + site_2] = Interaction[N*site_2 + site_1] = J_n;

        }                                                
		//
		//cout << "----------------[Jy 方向 down layer]--------------------" << endl;
        for(int i=0; i<N_x; i++)
        for(int j=0; j<N_y-1; j++) {

		site_1 = N_y * N_u * i + j * N_u + 1;  site_2 = site_1 + 2;
		//cout << "site_1: " << site_1 << ", site_2: " << site_2 << endl; 

        Table[N*site_1 + site_2] = Table[N*site_2 + site_1] = 1;
        Interaction[N*site_1 + site_2] = Interaction[N*site_2 + site_1] = J_nn;

        }                                                
		//
		//cout<< "--------------[Jx 方向 up layer 和 down layer]---------------" << endl;
        for(int i=0; i<N_x-1; i++)
        for(int j=0; j<N_y*N_u; j++) {

		site_1 = N_y * N_u * i + j;  site_2 = site_1 + N_u * N_y;
		//cout << "site_1: " << site_1 << ", site_2: " << site_2 << endl; 
        Table[N*site_1 + site_2] = Table[N*site_2 + site_1] = 1;
		if (site_1 % 2 == 0){
        	Interaction[N*site_1 + site_2] = Interaction[N*site_2 + site_1] = J_n; // up layer
		}else{Interaction[N*site_1 + site_2] = Interaction[N*site_2 + site_1] = J_nn;} // down layer
        }                                                

  //------------Number of the sites whose operators need to be stored: sys block-----------------
	int index, number;
	Table_sys=new int [N-2];
	Table_sys_site=new int * [N-2];

	for(int i=0; i<N-2; i++) {//i+1 is the number of sites in the block, sys block reaches the max length N-2
		index=0;

		for(int j=0; j<=i; j++) {
			number=N*j;

			for(int l=i+1; l<N; l++) 
			if(Table[number+l]!=0) { 
				index++;
				break;
			}
		}

		Table_sys[i]=index;
		Table_sys_site[i]=new int [index];
		
		index=0;
		for(int j=0; j<=i; j++) {
			number=N*j;

			for(int l=i+1; l<N; l++)
			if(Table[number+l]!=0) {
				Table_sys_site[i][index++]=j;
				break;
			}
		}
	}

  //----------Number of the sites whose operators need to be stored: env block-----------------------------------
	Table_env=new int [N-2];
	Table_env_site=new int * [N-2];

	for(int i=0; i<N-2; i++) {//i+1 is the length of the environment block
		index=0;

		for(int j=0; j<=i; j++) {
			number=N*(N-j-1);

			for(int l=0; l<N-i-1; l++)
			if(Table[number+l]!=0) {
				index++;
				break;
			}
		}

		Table_env[i]=index;
		Table_env_site[i]=new int [index];

		index=0;	
		for(int j=0; j<=i; j++) {
			number=N*(N-j-1);

			for(int l=0; l<N-i-1; l++)
			if(Table[number+l]!=0) {
				Table_env_site[i][index++]=j;//j is the position relative to the StartSite
				break;
			}
		}

	}

}

//======================================Delete parameter=========================================================
Parameter::~Parameter() {
	delete [] Interaction;		delete [] Table;
	delete [] Table_sys;		delete [] Table_env;

	for(int i=0; i<N-2; i++) {
		delete [] Table_sys_site[i];	delete [] Table_env_site[i];
	}
	delete [] Table_sys_site;		delete [] Table_env_site;
}
