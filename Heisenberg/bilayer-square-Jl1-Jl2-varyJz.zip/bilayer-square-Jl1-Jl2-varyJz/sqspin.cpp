#include<iostream>
using namespace std;
#include<math.h>
#include<time.h>
#include<assert.h>
#include<stdlib.h>
#include<stdio.h>
#include<gsl/gsl_sf_coupling.h>

#include"common.h"
#include"sub.h"
#include"super.h"
#include"sqspin.h"

#define constant sqrt(6.0)*0.5
//#define constant sqrt(6.0)
//===============================================================================================================
//						BLAS ROUTINES
//===============================================================================================================
extern "C" {
void daxpy_(const int *n, const double *alpha, double *x, const int *incx, double *y, const int *incy);

void dsymm_(char *side, char *uplo, const int *m, const int *n, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);

void dgemm_(char *transa, char *transb, const int *m, const int *n, const int *k, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);
}
//===============================================================================================================

//===============================================================================================================
//				Calculating the spin-spin correlation functions
//===============================================================================================================
Sqspin::Sqspin(const int &lsys, Parameter &para, Super &sup) {
//------Define variables-----------------------------------------------------------------------------------------
	trans_N='N';	trans_T='T';
	side_R='R';	side_L='L';
	uplo='U';

//------Create space for transformation matrices A and B, as well as other variables-----------------------------
	CreateSpace(lsys, para);	//matrices A, B and angular coupling coefficients
	CreateFunction(sup);		//The function in which the physical quantities averages are calculated

//------Calculate the spin-spin correlation functions------------------------------------------------------------
    //--Create space to store the correlation function
	correlation_function=new double [para.N*para.N];

    //--Initialize the values
        for(int i=0; i<para.N*para.N; i++)       {
                if(i/para.N==i%para.N)  correlation_function[i]=2.0;	//S*(S+1), for S=1/2, 0.75
                else                    correlation_function[i]=0.0;
        }

	Correlation_sys(lsys, para, sup);
	Correlation_env(para.N-lsys-2, para, sup);
	Correlation_ns_ne(lsys, para, sup);
//	Correlation_sys_env_memory(lsys, para, sup);	//for the case to save memory
	Correlation_sys_env_cpu(lsys, para, sup);	//for the case to use memory to increase speed

	Print(para);

        delete [] correlation_function;

//------Delete matrices A and B----------------------------------------------------------------------------------
	DeleteFunction(sup);
	DeleteSpace(lsys, para);
}


//===============================================================================================================
//===============================================================================================================
//===============================================================================================================
//					     Create Space for variables
//===============================================================================================================
inline void Sqspin::CreateSpace(const int &lsys, Parameter &para) {

	int A_site=lsys;
	int B_site=para.N-lsys-2;

//------Create space for A_N-matrices----------------------------------------------------------------------------
	A_N_Sys_Number_Jn=new int [A_site];
	A_N_Sys_Value_Jn=new int * [A_site];
	A_N_Sys_SubBlockNumber_Jn=new int * [A_site];
	A_N_IndexOld=new int ** [A_site];
	A_N_Start=new int ** [A_site];

  //----The first site-----------------------------------------------
	A_N_Sys_Number_Jn[0]=1;

	A_N_Sys_Value_Jn[0]=new int [1];
	A_N_Sys_Value_Jn[0][0]=para.S;

	A_N_Sys_SubBlockNumber_Jn[0]=new int [1];
	A_N_Sys_SubBlockNumber_Jn[0][0]=1;

	A_N_IndexOld[0]=new int * [para.S+1];
	A_N_Start[0]=new int * [para.S+1];
	for(int i=0; i<para.S+1; i++) {
		A_N_IndexOld[0][i]=new int [1];
		A_N_Start[0][i]=new int [1];
		for(int j=0; j<1; j++) {
			A_N_IndexOld[0][i][j]=0;
			A_N_Start[0][i][j]=0;
		}
	}

  //----Read other sites from disk------------------------------------
	for(int i=1; i<A_site; i++) {

		FILE *fr=fopen(Combine(Combine("new_block/", 1), i+1), "rb");	//"i"=1 stand for sys

		fread(&A_N_Sys_Number_Jn[i], sizeof(int), 1, fr);

		A_N_Sys_Value_Jn[i]=new int [A_N_Sys_Number_Jn[i]];
		A_N_Sys_SubBlockNumber_Jn[i]=new int [A_N_Sys_Number_Jn[i]];

		fread(A_N_Sys_Value_Jn[i], sizeof(int), A_N_Sys_Number_Jn[i], fr);
		fread(A_N_Sys_SubBlockNumber_Jn[i], sizeof(int), A_N_Sys_Number_Jn[i], fr);

		A_N_IndexOld[i]=new int * [para.S+1];
		A_N_Start[i]=new int * [para.S+1];
		for(int j=0; j<para.S+1; j++) {
			A_N_IndexOld[i][j]=new int [A_N_Sys_Number_Jn[i]];
			A_N_Start[i][j]=new int [A_N_Sys_Number_Jn[i]];
		}

		for(int j=0; j<para.S+1; j++) {
			fread(A_N_IndexOld[i][j], sizeof(int), A_N_Sys_Number_Jn[i], fr);
			fread(A_N_Start[i][j], sizeof(int), A_N_Sys_Number_Jn[i], fr);
		}

		fclose(fr);

	}

//------Create space for B_N-matrices----------------------------------------------------------------------------
	B_N_Sys_Number_Jn=new int [B_site];
	B_N_Sys_Value_Jn=new int * [B_site];
	B_N_Sys_SubBlockNumber_Jn=new int * [B_site];
	B_N_IndexOld=new int ** [B_site];
	B_N_Start=new int ** [B_site];

  //----The first site--------------------------------------------
	B_N_Sys_Number_Jn[0]=1;

        B_N_Sys_Value_Jn[0]=new int [1];
        B_N_Sys_Value_Jn[0][0]=para.S;

        B_N_Sys_SubBlockNumber_Jn[0]=new int [1];
        B_N_Sys_SubBlockNumber_Jn[0][0]=1;

        B_N_IndexOld[0]=new int * [para.S+1];
        B_N_Start[0]=new int * [para.S+1];
        for(int i=0; i<para.S+1; i++) {
                B_N_IndexOld[0][i]=new int [1];
                B_N_Start[0][i]=new int [1];
                for(int j=0; j<1; j++) {
                        B_N_IndexOld[0][i][j]=0;
                        B_N_Start[0][i][j]=0;
                }
        }

  //----Read other sites from disk---------------------------------
        for(int i=1; i<B_site; i++) {
                FILE *fr=fopen(Combine(Combine("new_block/", 2), i+1), "rb");//"i"=2 stand for env

                fread(&B_N_Sys_Number_Jn[i], sizeof(int), 1, fr);

                B_N_Sys_Value_Jn[i]=new int [B_N_Sys_Number_Jn[i]];
                B_N_Sys_SubBlockNumber_Jn[i]=new int [B_N_Sys_Number_Jn[i]];

                fread(B_N_Sys_Value_Jn[i], sizeof(int), B_N_Sys_Number_Jn[i], fr);
                fread(B_N_Sys_SubBlockNumber_Jn[i], sizeof(int), B_N_Sys_Number_Jn[i], fr);

                B_N_IndexOld[i]=new int * [para.S+1];
                B_N_Start[i]=new int * [para.S+1];
                for(int j=0; j<para.S+1; j++) {
                        B_N_IndexOld[i][j]=new int [B_N_Sys_Number_Jn[i]];
                        B_N_Start[i][j]=new int [B_N_Sys_Number_Jn[i]];
                }

		for(int j=0; j<para.S+1; j++) {
                        fread(B_N_IndexOld[i][j], sizeof(int), B_N_Sys_Number_Jn[i], fr);
                        fread(B_N_Start[i][j], sizeof(int), B_N_Sys_Number_Jn[i], fr);
                }

                fclose(fr);
        }

//------Create space for A-matrices------------------------------------------------------------------------------
	A_Sys_Number_Jn=new int [A_site];
	A_Sys_Value_Jn=new int * [A_site];
	A_Sys_SubBlockNumber_Jn=new int * [A_site];
	A_density_dim=new int * [A_site];
	A_OldSub=new int * [A_site];

	A=new double ** [A_site];

  //----The first site----------------------------------------------
  	A_Sys_Number_Jn[0]=1;

	A_Sys_Value_Jn[0]=new int [1];
	A_Sys_Value_Jn[0][0]=para.S;

	A_Sys_SubBlockNumber_Jn[0]=new int [1];
	A_Sys_SubBlockNumber_Jn[0][0]=1;
	
	A_density_dim[0]=new int [1];
	A_density_dim[0][0]=1;

	A_OldSub[0]=new int [1];
	A_OldSub[0][0]=0;
	
	A[0]=new double * [1];
	A[0][0]=new double [1];
	A[0][0][0]=1.0;

  //----Read other sites from disk----------------------------------
	for(int i=1; i<A_site; i++) {

		FILE *fp=fopen(Combine(Combine("truncated_density_eigenvector/", 1), i+1), "rb");

		fread(&A_Sys_Number_Jn[i], sizeof(int), 1, fp);
	
		A_Sys_Value_Jn[i]=new int [A_Sys_Number_Jn[i]];
		A_Sys_SubBlockNumber_Jn[i]=new int [A_Sys_Number_Jn[i]];
		A_density_dim[i]=new int [A_Sys_Number_Jn[i]];
		A_OldSub[i]=new int [A_Sys_Number_Jn[i]];

		fread(A_Sys_Value_Jn[i], sizeof(int), A_Sys_Number_Jn[i], fp);
		fread(A_Sys_SubBlockNumber_Jn[i], sizeof(int), A_Sys_Number_Jn[i], fp);
		fread(A_density_dim[i], sizeof(int), A_Sys_Number_Jn[i], fp);

		A[i]=new double * [A_Sys_Number_Jn[i]];
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) 
			A[i][j]=new double [A_density_dim[i][j]];

		for(int j=0; j<A_Sys_Number_Jn[i]; j++)
			fread(A[i][j], sizeof(double), A_density_dim[i][j], fp);

		fread(A_OldSub[i], sizeof(int), A_Sys_Number_Jn[i], fp);

		fclose(fp);
	}

//------Create space for B-matrices------------------------------------------------------------------------------
	B_Sys_Number_Jn=new int [B_site];
	B_Sys_Value_Jn=new int * [B_site];
	B_Sys_SubBlockNumber_Jn=new int * [B_site];
	B_density_dim=new int * [B_site];
	B_OldSub=new int * [B_site];

	B=new double ** [B_site];

  //----The first site------------------------------------------------
	B_Sys_Number_Jn[0]=1;

        B_Sys_Value_Jn[0]=new int [1];
        B_Sys_Value_Jn[0][0]=para.S;

        B_Sys_SubBlockNumber_Jn[0]=new int [1];
        B_Sys_SubBlockNumber_Jn[0][0]=1;

        B_density_dim[0]=new int [1];
        B_density_dim[0][0]=1;

	B_OldSub[0]=new int [1];
	B_OldSub[0][0]=0;

        B[0]=new double * [1];
        B[0][0]=new double [1];
	B[0][0][0]=1.0;

  //----Read other sites from disk-------------------------------------
	for(int i=1; i<B_site; i++) {

		FILE *fp=fopen(Combine(Combine("truncated_density_eigenvector/", 2), i+1), "rb");

		fread(&B_Sys_Number_Jn[i], sizeof(int), 1, fp);

		B_Sys_Value_Jn[i]=new int [B_Sys_Number_Jn[i]];
		B_Sys_SubBlockNumber_Jn[i]=new int [B_Sys_Number_Jn[i]];
		B_density_dim[i]=new int [B_Sys_Number_Jn[i]];
		B_OldSub[i]=new int [B_Sys_Number_Jn[i]];

		fread(B_Sys_Value_Jn[i], sizeof(int), B_Sys_Number_Jn[i], fp);
		fread(B_Sys_SubBlockNumber_Jn[i], sizeof(int), B_Sys_Number_Jn[i], fp);
		fread(B_density_dim[i], sizeof(int), B_Sys_Number_Jn[i], fp);

                B[i]=new double * [B_Sys_Number_Jn[i]];
                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                        B[i][j]=new double [B_density_dim[i][j]];

                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                        fread(B[i][j], sizeof(double), B_density_dim[i][j], fp);


		fread(B_OldSub[i], sizeof(int), B_Sys_Number_Jn[i], fp);

                fclose(fp);
        }

//------6j coefficients for A-blocks----------------------------------------------------------------------------- 
   //---A_six_j_S_Dia_old----------------------------------------------------------------------------------------
	A_six_j_S_Dia_old=new double *** [lsys-1];
        for(int i=0; i<lsys-1; i++) {
                A_six_j_S_Dia_old[i]=new double ** [A_Sys_Number_Jn[i]];
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			A_six_j_S_Dia_old[i][j]=new double * [A_Sys_Number_Jn[i]];
			for(int k=0; k<A_Sys_Number_Jn[i]; k++) 
				A_six_j_S_Dia_old[i][j][k]=new double [A_N_Sys_Number_Jn[i+1]];
		}

		FILE *fp=fopen(Combine(Combine("6j_factor/S_Dia_old/", 1), i+2), "rb");
		for(int j=0; j<A_Sys_Number_Jn[i]; j++)
		for(int k=0; k<A_Sys_Number_Jn[i]; k++)
			fread(A_six_j_S_Dia_old[i][j][k], sizeof(double), A_N_Sys_Number_Jn[i+1], fp);
               	fclose(fp);
        }

   //---A_six_j_S_Dia_n------------------------------------------------------------------------------------------
	A_six_j_S_Dia_n=new double ** [lsys-1];
	for(int i=0; i<lsys-1; i++) {
		A_six_j_S_Dia_n[i]=new double * [A_N_Sys_Number_Jn[i+1]];
		for(int j=0; j<A_N_Sys_Number_Jn[i+1]; j++) {
			A_six_j_S_Dia_n[i][j]=new double [A_Sys_Number_Jn[i]];
		}

		FILE *fa=fopen(Combine(Combine("6j_factor/S_Dia_n/", 1), i+2), "rb");
                for(int j=0; j<A_N_Sys_Number_Jn[i+1]; j++)
                        fread(A_six_j_S_Dia_n[i][j], sizeof(double), A_Sys_Number_Jn[i], fa);
                fclose(fa);
	}

   //---A_six_j_S_M_Dia_old--------------------------------------------------------------------------------------
	A_six_j_S_M_Dia_old=new double *** [lsys-1];
        for(int i=0; i<lsys-1; i++) {
                A_six_j_S_M_Dia_old[i]=new double ** [A_Sys_Number_Jn[i]];
                for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
                        A_six_j_S_M_Dia_old[i][j]=new double * [A_Sys_Number_Jn[i]];
                        for(int k=0; k<A_Sys_Number_Jn[i]; k++)
                                A_six_j_S_M_Dia_old[i][j][k]=new double [A_N_Sys_Number_Jn[i+1]-1];
                }

                FILE *fp=fopen(Combine(Combine("6j_factor/S_M_Dia_old/", 1), i+2), "rb");
                for(int j=0; j<A_Sys_Number_Jn[i]; j++)
                for(int k=0; k<A_Sys_Number_Jn[i]; k++)
                        fread(A_six_j_S_M_Dia_old[i][j][k], sizeof(double), A_N_Sys_Number_Jn[i+1]-1, fp);
                fclose(fp);
        }

   //---A_six_j_S_M_Dia_n----------------------------------------------------------------------------------------
	A_six_j_S_M_Dia_n=new double ** [lsys-1];
        for(int i=0; i<lsys-1; i++) {
                A_six_j_S_M_Dia_n[i]=new double * [A_N_Sys_Number_Jn[i+1]-1];
                for(int j=0; j<A_N_Sys_Number_Jn[i+1]-1; j++) {
                        A_six_j_S_M_Dia_n[i][j]=new double [A_Sys_Number_Jn[i]];
                }

                FILE *fa=fopen(Combine(Combine("6j_factor/S_M_Dia_n/", 1), i+2), "rb");
                for(int j=0; j<A_N_Sys_Number_Jn[i+1]-1; j++)
                        fread(A_six_j_S_M_Dia_n[i][j], sizeof(double), A_Sys_Number_Jn[i], fa);
                fclose(fa);
        }

   //---A_six_j_H------------------------------------------------------------------------------------------------
   	A_six_j_H=new double *** [lsys-1];
	for(int i=0; i<lsys-1; i++) {
		A_six_j_H[i]=new double ** [A_Sys_Number_Jn[i]];
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			A_six_j_H[i][j]=new double * [A_Sys_Number_Jn[i]];
			for(int k=0; k<A_Sys_Number_Jn[i]; k++)
				A_six_j_H[i][j][k]=new double [A_N_Sys_Number_Jn[i+1]];
		}

		FILE *fi=fopen(Combine(Combine("6j_factor/H/", 1), i+2), "rb");
		for(int j=0; j<A_Sys_Number_Jn[i]; j++)
		for(int k=0; k<A_Sys_Number_Jn[i]; k++)
			fread(A_six_j_H[i][j][k], sizeof(double), A_N_Sys_Number_Jn[i+1], fi);
		fclose(fi);
	}

//------6j coefficients for B-block------------------------------------------------------------------------------
   //---B_six_j_S_Dia_old----------------------------------------------------------------------------------------
	B_six_j_S_Dia_old=new double *** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_S_Dia_old[i]=new double ** [B_Sys_Number_Jn[i]];
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        B_six_j_S_Dia_old[i][j]=new double * [B_Sys_Number_Jn[i]];
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                                B_six_j_S_Dia_old[i][j][k]=new double [B_N_Sys_Number_Jn[i+1]];
                }

                FILE *fp=fopen(Combine(Combine("6j_factor/S_Dia_old/", 2), i+2), "rb");
                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                        fread(B_six_j_S_Dia_old[i][j][k], sizeof(double), B_N_Sys_Number_Jn[i+1], fp);
                fclose(fp);
        }

   //---B_six_j_S_Dia_n------------------------------------------------------------------------------------------
	B_six_j_S_Dia_n=new double ** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_S_Dia_n[i]=new double * [B_N_Sys_Number_Jn[i+1]];
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]; j++) {
                        B_six_j_S_Dia_n[i][j]=new double [B_Sys_Number_Jn[i]];
                }

                FILE *fa=fopen(Combine(Combine("6j_factor/S_Dia_n/", 2), i+2), "rb");
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]; j++)
                        fread(B_six_j_S_Dia_n[i][j], sizeof(double), B_Sys_Number_Jn[i], fa);
                fclose(fa);
        }

   //---B_six_j_S_M_Dia_old--------------------------------------------------------------------------------------
	B_six_j_S_M_Dia_old=new double *** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_S_M_Dia_old[i]=new double ** [B_Sys_Number_Jn[i]];
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        B_six_j_S_M_Dia_old[i][j]=new double * [B_Sys_Number_Jn[i]];
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                                B_six_j_S_M_Dia_old[i][j][k]=new double [B_N_Sys_Number_Jn[i+1]-1];
                }

                FILE *fp=fopen(Combine(Combine("6j_factor/S_M_Dia_old/", 2), i+2), "rb");
                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                        fread(B_six_j_S_M_Dia_old[i][j][k], sizeof(double), B_N_Sys_Number_Jn[i+1]-1, fp);
                fclose(fp);
        }

   //---B_six_j_S_M_Dia_n----------------------------------------------------------------------------------------
	B_six_j_S_M_Dia_n=new double ** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_S_M_Dia_n[i]=new double * [B_N_Sys_Number_Jn[i+1]-1];
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]-1; j++) {
                        B_six_j_S_M_Dia_n[i][j]=new double [B_Sys_Number_Jn[i]];
                }

                FILE *fa=fopen(Combine(Combine("6j_factor/S_M_Dia_n/", 2), i+2), "rb");
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]-1; j++)
                        fread(B_six_j_S_M_Dia_n[i][j], sizeof(double), B_Sys_Number_Jn[i], fa);
                fclose(fa);
        }

   //---B_six_j_H------------------------------------------------------------------------------------------------
	B_six_j_H=new double *** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_H[i]=new double ** [B_Sys_Number_Jn[i]];
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        B_six_j_H[i][j]=new double * [B_Sys_Number_Jn[i]];
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                                B_six_j_H[i][j][k]=new double [B_N_Sys_Number_Jn[i+1]];
                }

                FILE *fi=fopen(Combine(Combine("6j_factor/H/", 2), i+2), "rb");
                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                        fread(B_six_j_H[i][j][k], sizeof(double), B_N_Sys_Number_Jn[i+1], fi);
                fclose(fi);
        }
}

//===============================================================================================================
//			Create space for wavefunctions of configurations 2 and 3
//===============================================================================================================
inline void Sqspin::CreateFunction(Super &sup) {

	int inc=1;

  //----WaveFunction_config_1------------------------------------------------------------------------------------
        WaveFunction_block=new double * [sup.BlockNumber_for_TargetSpin];
        for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++) {
                WaveFunction_block[i]=new double [sup.Dim_block[i]];
                for(int j=0; j<sup.Dim_block[i]; j++)
                        WaveFunction_block[i][j]=0.0;
        }

        FILE *f=fopen("wavefunction/wavefunction_ground", "a+");
        for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++)
        for(int j=0; j<sup.Dim_block[i]; j++)
                fscanf(f, "%lf\n", &WaveFunction_block[i][j]);
        fclose(f);

  //----WaveFunction_config_2------------------------------------------------------------------------------------
	WaveFunction_config_2=new double * [sup.BlockNumber_for_TargetSpin];
	for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++) {
		WaveFunction_config_2[i]=new double [sup.Dim_block[i]];
		for(int j=0; j<sup.Dim_block[i]; j++) 
			WaveFunction_config_2[i][j]=0.0;
	}

	for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++) {
                int index=0;
                for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
                if(sup.J_sys[j]==sup.J_sys[i] && sup.J_env[j]==sup.J_env[i]) {
                        daxpy_(&sup.Dim_block[i], &sup.nine_j_config_2[i][index++], WaveFunction_block[j], &inc, WaveFunction_config_2[i], &inc);
                }
        }

  //----WaveFunction_config_3------------------------------------------------------------------------------------
	WaveFunction_config_3=new double * [sup.BlockNumber_for_TargetSpin_config_3];
        for(int i=0; i<sup.BlockNumber_for_TargetSpin_config_3; i++) {
                WaveFunction_config_3[i]=new double [sup.Dim_block_config_3[i]];
                for(int j=0; j<sup.Dim_block_config_3[i]; j++)
                        WaveFunction_config_3[i][j]=0.0;
        }

	for(int i=0; i<sup.BlockNumber_for_TargetSpin_config_3; i++) {
                int index=0;
                for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
                if(sup.J_sys[j]==sup.J_sys_config_3[i] && sup.J_env[j]==sup.J_env_config_3[i]) {
                        daxpy_(&sup.Dim_block_config_3[i], &sup.nine_j_config_3[i][index++], WaveFunction_block[j], &inc, WaveFunction_config_3[i], &inc);
                }
        }
}
//===============================================================================================================


//===============================================================================================================
//===============================================================================================================
//===============================================================================================================
//	Spin-Spin Correlation Functions:	Correlation function of sites in system and ns, ne
//===============================================================================================================
inline void Sqspin::Correlation_sys(const int &lsys, Parameter &para, Super &sup) {

//------Calculate the inner product of two wavefunctions for the calculation of correlation function-------------
   //---Create space for tmp_wavefunction, tmp_wavefunction_dia_config_1, and tmp_wavefunction_dia_config_2
	double **tmp_wavefunction, **tmp_wavefunction_dia_config_1, **tmp_wavefunction_dia_config_2;
	tmp_wavefunction=new double *[sup.sys->Sys_Number_Jn];
        tmp_wavefunction_dia_config_1=new double *[sup.sys->Sys_Number_Jn];
        tmp_wavefunction_dia_config_2=new double *[sup.sys->Sys_Number_Jn];

	for(int i=0; i<sup.sys->Sys_Number_Jn; i++) {
		int dim=sup.sys->Sys_SubBlockNumber_Jn[i]*sup.sys->Sys_SubBlockNumber_Jn[i];

		tmp_wavefunction[i]=new double [dim];
                tmp_wavefunction_dia_config_1[i]=new double [dim];
                tmp_wavefunction_dia_config_2[i]=new double [dim];
		
		for(int j=0; j<dim; j++) {
			tmp_wavefunction[i][j]=0.0;
                        tmp_wavefunction_dia_config_1[i][j]=0.0;
                        tmp_wavefunction_dia_config_2[i][j]=0.0;
		}
	}

  //----Initialize tmp_wavefunction
  	alpha=1.0;      beta=1.0;

	for(int i=0; i<sup.sys->Sys_Number_Jn; i++)
	for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
	if(sup.J_sys[j]==i) {
		dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[i], &sup.sys->Sys_SubBlockNumber_Jn[i], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env[j]], &alpha, WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[i], WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[i], &beta, tmp_wavefunction[i], &sup.sys->Sys_SubBlockNumber_Jn[i]);
	}

  //----Initialize tmp_wavefunction_dia_config_1,2
  	beta=1.0;

        for(int i=0; i<sup.sys->Sys_Number_Jn; i++)
        for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
        if(sup.J_sys[j]==i && sup.sys->Sys_Value_Jn[i]!=0) {
		alpha=sup.six_j_1_sys_n[j*sup.BlockNumber_for_TargetSpin+j]; 

                dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[i], &sup.sys->Sys_SubBlockNumber_Jn[i], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env[j]], &alpha, WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[i], WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[i], &beta, tmp_wavefunction_dia_config_1[i], &sup.sys->Sys_SubBlockNumber_Jn[i]);

                dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[i], &sup.sys->Sys_SubBlockNumber_Jn[i], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env[j]], &alpha, WaveFunction_config_2[j], &sup.sys->Sys_SubBlockNumber_Jn[i], WaveFunction_config_2[j], &sup.sys->Sys_SubBlockNumber_Jn[i], &beta, tmp_wavefunction_dia_config_2[i], &sup.sys->Sys_SubBlockNumber_Jn[i]);
        }

  //----Create space for tmp_wavefunction_m_config_1,2
        double **tmp_wavefunction_m_config_1, **tmp_wavefunction_m_config_2;
        tmp_wavefunction_m_config_1=new double *[sup.sys->Sys_Number_Jn-1];
        tmp_wavefunction_m_config_2=new double *[sup.sys->Sys_Number_Jn-1];

        for(int i=0; i<sup.sys->Sys_Number_Jn-1; i++) {
                int dim=sup.sys->Sys_SubBlockNumber_Jn[i]*sup.sys->Sys_SubBlockNumber_Jn[i+1];

                tmp_wavefunction_m_config_1[i]=new double [dim];
                tmp_wavefunction_m_config_2[i]=new double [dim];

                for(int j=0; j<dim; j++) {
                        tmp_wavefunction_m_config_1[i][j]=0.0;
                        tmp_wavefunction_m_config_2[i][j]=0.0;
                }
        }

  //----Initialize tmp_wavefunction_m_config_1,2
	beta=1.0;

 	for(int i=0; i<sup.sys->Sys_Number_Jn-1; i++)
	for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
	for(int k=0; k<sup.BlockNumber_for_TargetSpin; k++)
	if(sup.J_sys[j]==i && sup.J_sys[k]==i+1 && sup.J_sysnew[j]==sup.J_sysnew[k] && sup.J_envnew[j]==sup.J_envnew[k] && sup.J_env[j]==sup.J_env[k] && sup.sys->Sys_Value_Jn[i+1]-sup.sys->Sys_Value_Jn[i]==2) {
		alpha=sup.six_j_1_sys_n[j*sup.BlockNumber_for_TargetSpin+k];

		dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[i+1], &sup.sys->Sys_SubBlockNumber_Jn[i], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env[j]], &alpha, WaveFunction_block[k], &sup.sys->Sys_SubBlockNumber_Jn[i+1], WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[i], &beta, tmp_wavefunction_m_config_1[i], &sup.sys->Sys_SubBlockNumber_Jn[i+1]);

		dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[i+1], &sup.sys->Sys_SubBlockNumber_Jn[i], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env[j]], &alpha, WaveFunction_config_2[k], &sup.sys->Sys_SubBlockNumber_Jn[i+1], WaveFunction_config_2[j], &sup.sys->Sys_SubBlockNumber_Jn[i], &beta, tmp_wavefunction_m_config_2[i], &sup.sys->Sys_SubBlockNumber_Jn[i+1]);
	}

//------Calculate the spin-spin correlation function-------------------------------------------------------------
	for(int i=0; i<lsys; i++)
	if( i > 49 ) {

          //----Initialize Si operators--------------------------------------------------------------------------
		if(i==0)        New_A_Si_initial(0, para);
                else  {
                        New_A_Si_initial(i, para);
                        Truncate_A_Si(i);
                }
          
         //-----Transform Si operators---------------------------------------------------------------------------
         	for(int j=i+1; j<lsys; j++) {	//for Sj

		  //----Initialize SiSj operator
			Initial_A_SiSj(j, para);
			Truncate_A_SiSj(j);

		  //----Transform SiSj operator
			for(int k=j+1; k<lsys; k++) {
                        	New_A_SiSj(k, para);
                        	Truncate_A_SiSj(k);
                	}

		  //------Calculate the expectation value of correlation function
			alpha=1.0;      beta=0.0;

                	for(int j_1=0; j_1<sup.sys->Sys_Number_Jn; j_1++) {

                        	int dim=sup.sys->Sys_SubBlockNumber_Jn[j_1]*sup.sys->Sys_SubBlockNumber_Jn[j_1];

                        	double *matrix=new double [dim];
                        	for(int p=0; p<dim; p++)      matrix[p]=0.0;

                        	dsymm_(&side_R, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &alpha, SiSj_old_A[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], tmp_wavefunction[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[j_1]);

                        	for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[j_1]; p++) {
                                	correlation_function[i*para.N+j]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1])];
                                	correlation_function[j*para.N+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1])];
                        	}

				delete [] matrix; 
                	}

	                cout<<"\n"<<i<<"\t"<<j<<"\t"<<correlation_function[i*para.N+j]<<endl;

         	  //----Delete space of SiSj_old
			for(int k=0; k<A_Sys_Number_Jn[lsys-1]; k++)
                        	delete [] SiSj_old_A[k];
                	delete [] SiSj_old_A;

   		  //----New A_Si after shift a site to right
			New_A_Si_new(j, para);
			Truncate_A_Si(j);
		}

	    //--Compute the correlation functions between sites in system and ns, ne-----------------------------
	      //1. J1==J1_p--------------------------------------------------------------------------------------
		alpha=1.0;      beta=0.0;

		for(int j_1=0; j_1<sup.sys->Sys_Number_Jn; j_1++) 
		if(sup.sys->Sys_Value_Jn[j_1]!=0) {

			int dim=sup.sys->Sys_SubBlockNumber_Jn[j_1]*sup.sys->Sys_SubBlockNumber_Jn[j_1];

			double *matrix=new double [dim];
			double *matrix_2=new double [dim];
			for(int p=0; p<dim; p++)  {
				matrix[p]=0.0;	matrix_2[p]=0.0;
			}

			dsymm_(&side_R, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &alpha, Si_Dia_old_A[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], tmp_wavefunction_dia_config_1[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[j_1]);

			dsymm_(&side_R, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &alpha, Si_Dia_old_A[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], tmp_wavefunction_dia_config_2[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &beta, matrix_2, &sup.sys->Sys_SubBlockNumber_Jn[j_1]);

			for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[j_1]; p++) {
				correlation_function[i*para.N+lsys]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1])];
				correlation_function[lsys*para.N+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1])];

				correlation_function[i*para.N+lsys+1]+=matrix_2[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1])];
				correlation_function[(lsys+1)*para.N+i]+=matrix_2[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1])];
			}

			delete [] matrix;	delete [] matrix_2;
		}

	      //2. J1==J1_p-1------------------------------------------------------------------------------------
		for(int j_1=0; j_1<sup.sys->Sys_Number_Jn-1; j_1++) 
		if(sup.sys->Sys_Value_Jn[j_1+1]-sup.sys->Sys_Value_Jn[j_1]==2) {

			int dim=sup.sys->Sys_SubBlockNumber_Jn[j_1+1]*sup.sys->Sys_SubBlockNumber_Jn[j_1+1];

                        double *matrix=new double [dim];
			double *matrix_2=new double [dim];
                        for(int p=0; p<dim; p++)  {
				matrix[p]=0.0;	matrix_2[p]=0.0;
			}

			dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[j_1+1], &sup.sys->Sys_SubBlockNumber_Jn[j_1+1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &alpha, tmp_wavefunction_m_config_1[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1+1], Si_M_Dia_old_A[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[j_1+1]);

			dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[j_1+1], &sup.sys->Sys_SubBlockNumber_Jn[j_1+1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &alpha, tmp_wavefunction_m_config_2[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1+1], Si_M_Dia_old_A[j_1], &sup.sys->Sys_SubBlockNumber_Jn[j_1], &beta, matrix_2, &sup.sys->Sys_SubBlockNumber_Jn[j_1+1]);

			for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[j_1+1]; p++) {
                                correlation_function[i*para.N+lsys]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1+1])];
                                correlation_function[lsys*para.N+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1+1])];

				correlation_function[i*para.N+lsys+1]+=matrix_2[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1+1])];
				correlation_function[(lsys+1)*para.N+i]+=matrix_2[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_1+1])];
                        }

                        delete [] matrix;	delete [] matrix_2;
		}

	      //3. J1==J1_p+1------------------------------------------------------------------------------------
		for(int j_p=0; j_p<sup.sys->Sys_Number_Jn-1; j_p++) 
		if(sup.sys->Sys_Value_Jn[j_p+1]-sup.sys->Sys_Value_Jn[j_p]==2) {

			int dim=sup.sys->Sys_SubBlockNumber_Jn[j_p+1]*sup.sys->Sys_SubBlockNumber_Jn[j_p+1];

			double *matrix=new double [dim];
			double *matrix_2=new double [dim];
                        for(int p=0; p<dim; p++)  {
				matrix[p]=0.0;	matrix_2[p]=0.0;
			}

                        dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[j_p+1], &sup.sys->Sys_SubBlockNumber_Jn[j_p+1], &sup.sys->Sys_SubBlockNumber_Jn[j_p], &alpha, tmp_wavefunction_m_config_1[j_p], &sup.sys->Sys_SubBlockNumber_Jn[j_p+1], Si_M_Dia_old_A[j_p], &sup.sys->Sys_SubBlockNumber_Jn[j_p], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[j_p+1]);

			dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[j_p+1], &sup.sys->Sys_SubBlockNumber_Jn[j_p+1], &sup.sys->Sys_SubBlockNumber_Jn[j_p], &alpha, tmp_wavefunction_m_config_2[j_p], &sup.sys->Sys_SubBlockNumber_Jn[j_p+1], Si_M_Dia_old_A[j_p], &sup.sys->Sys_SubBlockNumber_Jn[j_p], &beta, matrix_2, &sup.sys->Sys_SubBlockNumber_Jn[j_p+1]);

                        for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[j_p+1]; p++) {
                                correlation_function[i*para.N+lsys]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_p+1])];
                                correlation_function[lsys*para.N+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_p+1])];

				correlation_function[i*para.N+lsys+1]+=matrix_2[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_p+1])];
				correlation_function[(lsys+1)*para.N+i]+=matrix_2[p*(1+sup.sys->Sys_SubBlockNumber_Jn[j_p+1])];
                        }

                        delete [] matrix;     delete [] matrix_2;
		}

		cout<<"\n"<<i<<"\t"<<lsys<<"\t"<<correlation_function[i*para.N+lsys]<<endl;
                cout<<"\n"<<i<<"\t"<<lsys+1<<"\t"<<correlation_function[i*para.N+lsys+1]<<endl;

	    //--Delete space of Si operators---------------------------------------------------------------------
		for(int i=0; i<A_Sys_Number_Jn[lsys-1]; i++)
                	delete [] Si_Dia_old_A[i];
        	delete [] Si_Dia_old_A;

        	for(int i=0; i<A_Sys_Number_Jn[lsys-1]-1; i++)
                	delete [] Si_M_Dia_old_A[i];
        	delete [] Si_M_Dia_old_A;
	}

//------Delete space---------------------------------------------------------------------------------------------
  //----Delete diagonal part
	for(int i=0; i<sup.sys->Sys_Number_Jn; i++) {
		delete [] tmp_wavefunction[i];      delete [] tmp_wavefunction_dia_config_1[i];      
		delete [] tmp_wavefunction_dia_config_2[i];
	}
	delete [] tmp_wavefunction;      delete [] tmp_wavefunction_dia_config_1;      
	delete [] tmp_wavefunction_dia_config_2;

  //----Delete the minor-diagonal part
        for(int i=0; i<sup.sys->Sys_Number_Jn-1; i++) {
                delete [] tmp_wavefunction_m_config_1[i];      delete [] tmp_wavefunction_m_config_2[i];
        }
        delete [] tmp_wavefunction_m_config_1;		       delete [] tmp_wavefunction_m_config_2;
}

//===============================================================================================================
//			Correlation function of sites in environment and ns, ne
//===============================================================================================================
inline void Sqspin::Correlation_env(const int &lsys, Parameter &para, Super &sup) {
//------Calcualte the inner product of two wavefunctions for the calculation of correlation function-------------
   //---Create space for tmp_wavefunction, tmp_wavefunction_dia_config_1, and tmp_wavefunction_dia_config_2
        double **tmp_wavefunction, **tmp_wavefunction_dia_config_1, **tmp_wavefunction_dia_config_2;
        tmp_wavefunction=new double *[sup.env->Sys_Number_Jn];
        tmp_wavefunction_dia_config_1=new double *[sup.env->Sys_Number_Jn];
        tmp_wavefunction_dia_config_2=new double *[sup.env->Sys_Number_Jn];

        for(int i=0; i<sup.env->Sys_Number_Jn; i++) {
                int dim=sup.env->Sys_SubBlockNumber_Jn[i]*sup.env->Sys_SubBlockNumber_Jn[i];

                tmp_wavefunction[i]=new double [dim];
                tmp_wavefunction_dia_config_1[i]=new double [dim];
                tmp_wavefunction_dia_config_2[i]=new double [dim];

                for(int j=0; j<dim; j++) {
                        tmp_wavefunction[i][j]=0.0;
                        tmp_wavefunction_dia_config_1[i][j]=0.0;
                        tmp_wavefunction_dia_config_2[i][j]=0.0;
                }
        }
   
  //----Initialize tmp_wavefunction
  	alpha=1.0;      beta=1.0;

        for(int i=0; i<sup.env->Sys_Number_Jn; i++)
        for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
        if(sup.J_env[j]==i) {
		dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[i], &sup.env->Sys_SubBlockNumber_Jn[i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &alpha, WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &beta, tmp_wavefunction[i], &sup.env->Sys_SubBlockNumber_Jn[i]);
        }

  //----Initialize tmp_wavefunction_dia_config_1,2
        beta=1.0;

        for(int i=0; i<sup.env->Sys_Number_Jn; i++)
        for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
        if(sup.J_env[j]==i && sup.env->Sys_Value_Jn[i]!=0) {
		alpha=sup.six_j_1_e_env[j*sup.BlockNumber_for_TargetSpin+j];

                dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[i], &sup.env->Sys_SubBlockNumber_Jn[i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &alpha, WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &beta, tmp_wavefunction_dia_config_1[i], &sup.env->Sys_SubBlockNumber_Jn[i]);

                dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[i], &sup.env->Sys_SubBlockNumber_Jn[i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &alpha, WaveFunction_config_2[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], WaveFunction_config_2[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &beta, tmp_wavefunction_dia_config_2[i], &sup.env->Sys_SubBlockNumber_Jn[i]);
        }

  //----Create space for tmp_wavefunction_m_config_1,2
        double **tmp_wavefunction_m_config_1, **tmp_wavefunction_m_config_2;
        tmp_wavefunction_m_config_1=new double *[sup.env->Sys_Number_Jn-1];
        tmp_wavefunction_m_config_2=new double *[sup.env->Sys_Number_Jn-1];

        for(int i=0; i<sup.env->Sys_Number_Jn-1; i++) {
                int dim=sup.env->Sys_SubBlockNumber_Jn[i]*sup.env->Sys_SubBlockNumber_Jn[i+1];

                tmp_wavefunction_m_config_1[i]=new double [dim];
                tmp_wavefunction_m_config_2[i]=new double [dim];

                for(int j=0; j<dim; j++) {
                        tmp_wavefunction_m_config_1[i][j]=0.0;
                        tmp_wavefunction_m_config_2[i][j]=0.0;
                }
        }

  //----Initialize tmp_wavefunction_m_config_1,2
        beta=1.0;

        for(int i=0; i<sup.env->Sys_Number_Jn-1; i++)
        for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
        for(int k=0; k<sup.BlockNumber_for_TargetSpin; k++)
        if(sup.J_env[j]==i && sup.J_env[k]==i+1 && sup.J_sysnew[j]==sup.J_sysnew[k] && sup.J_envnew[j]==sup.J_envnew[k] && sup.J_sys[j]==sup.J_sys[k] && sup.env->Sys_Value_Jn[i+1]-sup.env->Sys_Value_Jn[i]==2) {
                alpha=sup.six_j_1_e_env[j*sup.BlockNumber_for_TargetSpin+k];

                dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[i+1], &sup.env->Sys_SubBlockNumber_Jn[i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &alpha, WaveFunction_block[k], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], WaveFunction_block[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &beta, tmp_wavefunction_m_config_1[i], &sup.env->Sys_SubBlockNumber_Jn[i+1]);

                dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[i+1], &sup.env->Sys_SubBlockNumber_Jn[i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &alpha, WaveFunction_config_2[k], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], WaveFunction_config_2[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys[j]], &beta, tmp_wavefunction_m_config_2[i], &sup.env->Sys_SubBlockNumber_Jn[i+1]);
        }

//------Calculate the spin-spin correlation function-------------------------------------------------------------
        for(int i=0; i<lsys; i++)
	if( i > 49 ) {

          //----Initialize Si operators--------------------------------------------------------------------------
		if(i==0)        New_B_Si_initial(0, para);
                else  {
                        New_B_Si_initial(i, para);
                        Truncate_B_Si(i);
                }

         //-----Transform Si operators---------------------------------------------------------------------------
                for(int j=i+1; j<lsys; j++) {   //for Sj

                  //----Initialize SiSj operator
			Initial_B_SiSj(j, para);
                        Truncate_B_SiSj(j);

                  //----Transform SiSj operator
			for(int k=j+1; k<lsys; k++) {
                                New_B_SiSj(k, para);
                                Truncate_B_SiSj(k);
                        }

                  //------Calculate the expectation value of correlation function
                  	alpha=1.0;      beta=0.0;

                        for(int j_2=0; j_2<sup.env->Sys_Number_Jn; j_2++) {

				int dim=sup.env->Sys_SubBlockNumber_Jn[j_2]*sup.env->Sys_SubBlockNumber_Jn[j_2];

				double *matrix=new double [dim];
                                for(int p=0; p<dim; p++)      matrix[p]=0.0; 

				dsymm_(&side_R, &uplo, &sup.env->Sys_SubBlockNumber_Jn[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], &alpha, SiSj_old_B[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], tmp_wavefunction[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], &beta, matrix, &sup.env->Sys_SubBlockNumber_Jn[j_2]);

                                for(int p=0; p<sup.env->Sys_SubBlockNumber_Jn[j_2]; p++) {
                                        correlation_function[(para.N-1-i)*para.N+para.N-1-j]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2])];
                                        correlation_function[(para.N-1-j)*para.N+para.N-1-i]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2])];
                                }

                                delete [] matrix; 
			}

                        cout<<"\n"<<para.N-1-i<<"\t"<<para.N-1-j<<"\t"<<correlation_function[(para.N-1-i)*para.N+para.N-1-j]<<endl;

                  //----Delete space of SiSj_old
			for(int k=0; k<B_Sys_Number_Jn[lsys-1]; k++)
                                delete [] SiSj_old_B[k];
                        delete [] SiSj_old_B;

                  //----New B_Si after shift a site to right
			New_B_Si_new(j, para);
			Truncate_B_Si(j);

                }

            //--Compute the correlation functions between sites in env and ns, ne--------------------------------
              //1. J2==J2_p--------------------------------------------------------------------------------------
		alpha=1.0;      beta=0.0;

                for(int j_2=0; j_2<sup.env->Sys_Number_Jn; j_2++) 
		if(sup.env->Sys_Value_Jn[j_2]!=0) {
             
                        int dim=sup.env->Sys_SubBlockNumber_Jn[j_2]*sup.env->Sys_SubBlockNumber_Jn[j_2];

			double *matrix=new double [dim];
			double *matrix_2=new double [dim];
                        for(int p=0; p<dim; p++)  {
                                matrix[p]=0.0;	matrix_2[p]=0.0;
                        }

			dsymm_(&side_R, &uplo, &sup.env->Sys_SubBlockNumber_Jn[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], &alpha, Si_Dia_old_B[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], tmp_wavefunction_dia_config_1[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], &beta, matrix, &sup.env->Sys_SubBlockNumber_Jn[j_2]);

			dsymm_(&side_R, &uplo, &sup.env->Sys_SubBlockNumber_Jn[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], &alpha, Si_Dia_old_B[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], tmp_wavefunction_dia_config_2[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], &beta, matrix_2, &sup.env->Sys_SubBlockNumber_Jn[j_2]);

			for(int p=0; p<sup.env->Sys_SubBlockNumber_Jn[j_2]; p++) {
                                correlation_function[(para.N-1-i)*para.N+lsys+1]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2])];
                                correlation_function[(lsys+1)*para.N+para.N-1-i]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2])];

                                correlation_function[(para.N-1-i)*para.N+lsys]+=matrix_2[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2])];
                                correlation_function[lsys*para.N+para.N-1-i]+=matrix_2[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2])];
                        }

                        delete [] matrix;       delete [] matrix_2;
		}

              //2. J2==J2_p-1------------------------------------------------------------------------------------
                for(int j_2=0; j_2<sup.env->Sys_Number_Jn-1; j_2++) 
		if(sup.env->Sys_Value_Jn[j_2+1]-sup.env->Sys_Value_Jn[j_2]==2) {

                        int dim=sup.env->Sys_SubBlockNumber_Jn[j_2+1]*sup.env->Sys_SubBlockNumber_Jn[j_2+1];

                        double *matrix=new double [dim];
                        double *matrix_2=new double [dim];
                        for(int p=0; p<dim; p++)  {
                                matrix[p]=0.0;	matrix_2[p]=0.0;
                        }

                        dgemm_(&trans_N, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[j_2+1], &sup.env->Sys_SubBlockNumber_Jn[j_2+1], &sup.env->Sys_SubBlockNumber_Jn[j_2], &alpha, tmp_wavefunction_m_config_1[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2+1], Si_M_Dia_old_B[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], &beta, matrix, &sup.env->Sys_SubBlockNumber_Jn[j_2+1]);

                        dgemm_(&trans_N, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[j_2+1], &sup.env->Sys_SubBlockNumber_Jn[j_2+1], &sup.env->Sys_SubBlockNumber_Jn[j_2], &alpha, tmp_wavefunction_m_config_2[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2+1], Si_M_Dia_old_B[j_2], &sup.env->Sys_SubBlockNumber_Jn[j_2], &beta, matrix_2, &sup.env->Sys_SubBlockNumber_Jn[j_2+1]);

                        for(int p=0; p<sup.env->Sys_SubBlockNumber_Jn[j_2+1]; p++) {
                                correlation_function[(para.N-1-i)*para.N+lsys+1]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2+1])];
                                correlation_function[(lsys+1)*para.N+para.N-1-i]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2+1])];

                                correlation_function[(para.N-1-i)*para.N+lsys]+=matrix_2[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2+1])];
                                correlation_function[lsys*para.N+para.N-1-i]+=matrix_2[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_2+1])];
                        }

                        delete [] matrix;     delete [] matrix_2;
		}

              //3. J2==J2_p+1------------------------------------------------------------------------------------
                for(int j_p=0; j_p<sup.env->Sys_Number_Jn-1; j_p++) 
		if(sup.env->Sys_Value_Jn[j_p+1]-sup.env->Sys_Value_Jn[j_p]==2) {

                        int dim=sup.env->Sys_SubBlockNumber_Jn[j_p+1]*sup.env->Sys_SubBlockNumber_Jn[j_p+1];

                        double *matrix=new double [dim];
                        double *matrix_2=new double [dim];
                        for(int p=0; p<dim; p++)  {
                                matrix[p]=0.0;	matrix_2[p]=0.0;
                        }

                        dgemm_(&trans_N, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[j_p+1], &sup.env->Sys_SubBlockNumber_Jn[j_p+1], &sup.env->Sys_SubBlockNumber_Jn[j_p], &alpha, tmp_wavefunction_m_config_1[j_p], &sup.env->Sys_SubBlockNumber_Jn[j_p+1], Si_M_Dia_old_B[j_p], &sup.env->Sys_SubBlockNumber_Jn[j_p], &beta, matrix, &sup.env->Sys_SubBlockNumber_Jn[j_p+1]);

                        dgemm_(&trans_N, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[j_p+1], &sup.env->Sys_SubBlockNumber_Jn[j_p+1], &sup.env->Sys_SubBlockNumber_Jn[j_p], &alpha, tmp_wavefunction_m_config_2[j_p], &sup.env->Sys_SubBlockNumber_Jn[j_p+1], Si_M_Dia_old_B[j_p], &sup.env->Sys_SubBlockNumber_Jn[j_p], &beta, matrix_2, &sup.env->Sys_SubBlockNumber_Jn[j_p+1]);

                        for(int p=0; p<sup.env->Sys_SubBlockNumber_Jn[j_p+1]; p++) {
                                correlation_function[(para.N-1-i)*para.N+lsys+1]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_p+1])];
                                correlation_function[(lsys+1)*para.N+para.N-1-i]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_p+1])];

                                correlation_function[(para.N-1-i)*para.N+lsys]+=matrix_2[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_p+1])];
                                correlation_function[lsys*para.N+para.N-1-i]+=matrix_2[p*(1+sup.env->Sys_SubBlockNumber_Jn[j_p+1])];
                        }

                        delete [] matrix;     delete [] matrix_2;
		}

		cout<<"\n"<<para.N-1-i<<"\t"<<lsys+1<<"\t"<<correlation_function[(para.N-1-i)*para.N+lsys+1]<<endl;
		cout<<"\n"<<para.N-1-i<<"\t"<<lsys<<"\t"<<correlation_function[(para.N-1-i)*para.N+lsys]<<endl;

            //--Delete space of Si operators---------------------------------------------------------------------
                for(int i=0; i<B_Sys_Number_Jn[lsys-1]; i++)
                        delete [] Si_Dia_old_B[i];
                delete [] Si_Dia_old_B;

                for(int i=0; i<B_Sys_Number_Jn[lsys-1]-1; i++)
                        delete [] Si_M_Dia_old_B[i];
                delete [] Si_M_Dia_old_B;
	}

//------Delete space---------------------------------------------------------------------------------------------
  //----Delete diagonal part
        for(int i=0; i<sup.env->Sys_Number_Jn; i++) {
                delete [] tmp_wavefunction[i];      delete [] tmp_wavefunction_dia_config_1[i];
                delete [] tmp_wavefunction_dia_config_2[i];
        }
        delete [] tmp_wavefunction;      delete [] tmp_wavefunction_dia_config_1;
        delete [] tmp_wavefunction_dia_config_2;

  //----Delete the minor-diagonal part
        for(int i=0; i<sup.env->Sys_Number_Jn-1; i++) {
                delete [] tmp_wavefunction_m_config_1[i];      delete [] tmp_wavefunction_m_config_2[i];
        }
        delete [] tmp_wavefunction_m_config_1;                 delete [] tmp_wavefunction_m_config_2;
}

//===============================================================================================================
//					Correlation function between ns and ne
//===============================================================================================================
inline void Sqspin::Correlation_ns_ne(const int &lsys, Parameter &para, Super &sup) {
	beta=0.0;

	for(int i=0; i<sup.BlockNumber_for_TargetSpin_config_3; i++) {

		int dim=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]];

		double *matrix=new double [dim];
		for(int j=0; j<dim; j++)	matrix[j]=0.0;	

		dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[i]], &sup.six_j_2_config_3[i], WaveFunction_config_3[i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]], WaveFunction_config_3[i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]]);

		for(int j=0; j<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]]; j++) {
			correlation_function[para.N*lsys+lsys+1]+=matrix[j*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]])];
			correlation_function[para.N*(lsys+1)+lsys]+=matrix[j*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[i]])];
		}
		
		delete [] matrix;
	}

	cout<<"\n"<<lsys<<"\t"<<lsys+1<<"\t"<<correlation_function[para.N*lsys+lsys+1]<<endl;

}

//===============================================================================================================
//				Correlation function between sites in sys and env
//===============================================================================================================
inline void Sqspin::Correlation_sys_env_memory(const int &lsys, Parameter &para, Super &sup) {
	for(int i=0; i<lsys; i++)
	for(int m=0; m<para.N-2-lsys; m++)
//	if(fabs(para.Interaction[i*para.N+para.N-1-m]-para.J_n)<0.0001 || fabs(para.Interaction[i*para.N+para.N-1-m]-para.J_nn)<0.0001 ) {
//	if(fabs(para.Interaction[i*para.N+para.N-1-m]-para.J_n)<0.0001 ) {
	if( i > 49  &&  m > 49 ) {

          //----Initialize Si operators--------------------------------------------------------------------------
                if(i==0)        New_A_Si_initial(0, para);
                else  {
                        New_A_Si_initial(i, para);
                        Truncate_A_Si(i);
                }

	  //----Transform Si operators---------------------------------------------------------------------------
		for(int j=i+1; j<lsys; j++) {
			New_A_Si_new(j, para);
                        Truncate_A_Si(j);
		}

	  //----for Sj operators---------------------------------------------------------------------------------
//	  	for(int m=0; m<para.N-2-lsys; m++) {
	    //--Initialize Sj operators
	    		if(m==0)        New_B_Si_initial(0, para);
 	                else  {
           	        	New_B_Si_initial(m, para);
                	        Truncate_B_Si(m);
			}

	    //--Transform Sj operators
	    		for(int n=m+1; n<para.N-2-lsys; n++) {
				New_B_Si_new(n, para);
				Truncate_B_Si(n);
			}

 	    //--Calculate the spin-spin correlation function
			for(int j_i=0; j_i<sup.BlockNumber_for_TargetSpin_config_3; j_i++) {
				int index=0;
				for(int j_j=0; j_j<sup.BlockNumber_for_TargetSpin_config_3; j_j++)
				if(sup.J_sysnew_config_3[j_j]==sup.J_sysnew_config_3[j_i] && sup.J_envnew_config_3[j_j]==sup.J_envnew_config_3[j_i] && abs(sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]])<=2 && abs(sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]])<=2) {
				//------1
					if(j_i==j_j && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]!=0 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]!=0) {
						int dim_t=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];
						int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

						double *f_t=new double [dim_t];
						for(int l=0; l<dim_t; l++)	f_t[l]=0.0;

						double *f_s=new double [dim_s];
						double *f_s_p=new double [dim_s];
						for(int l=0; l<dim_s; l++) {
							f_s[l]=0.0;	f_s_p[l]=0.0;
						}
			
						alpha=1.0; beta=0.0;
						dsymm_(&side_R, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, Si_Dia_old_B[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], WaveFunction_config_3[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], WaveFunction_config_3[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);
	
						dsymm_(&side_R, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.six_j_1_config_3[j_i][index], Si_Dia_old_A[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_s_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; n++) {
							correlation_function[para.N*i+para.N-m-1]+=f_s_p[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
							correlation_function[para.N*(para.N-m-1)+i]+=f_s_p[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
						}

						delete [] f_t;	delete [] f_s;  delete [] f_s_p;
					}

				//------2
					else if(sup.J_sys_config_3[j_i]==sup.J_sys_config_3[j_j] && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]!=0 && sup.J_env_config_3[j_j]-sup.J_env_config_3[j_i]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]==2) {
                                                int dim_t=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]];
                                                int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

                                                double *f_t=new double [dim_t];
                                                for(int l=0; l<dim_t; l++)      f_t[l]=0.0;

                                                double *f_s=new double [dim_s];
						double *f_s_p=new double [dim_s];
                                                for(int l=0; l<dim_s; l++) {
							f_s[l]=0.0;	f_s_p[l]=0.0;
						}

						alpha=1.0;  beta=0.0;
						dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, WaveFunction_config_3[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], Si_M_Dia_old_B[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &beta, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &alpha, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], WaveFunction_config_3[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						dsymm_(&side_R, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.six_j_1_config_3[j_i][index], Si_Dia_old_A[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_s_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; n++) {
                                                        correlation_function[para.N*i+para.N-m-1]+=f_s_p[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                        correlation_function[para.N*(para.N-m-1)+i]+=f_s_p[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                }

						delete [] f_t;  delete [] f_s;  delete [] f_s_p;
					}

				//------3
					else if(sup.J_sys_config_3[j_i]==sup.J_sys_config_3[j_j] && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]!=0 && sup.J_env_config_3[j_i]-sup.J_env_config_3[j_j]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]==2) {
                                                int dim_t=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];
                                                int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

                                                double *f_t=new double [dim_t];
                                                for(int l=0; l<dim_t; l++)      f_t[l]=0.0;

                                                double *f_s=new double [dim_s];
						double *f_s_p=new double [dim_s];
                                                for(int l=0; l<dim_s; l++) {
							f_s[l]=0.0;	f_s_p[l]=0.0;
						}

						alpha=1.0;  beta=0.0;
                                                dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &alpha, WaveFunction_config_3[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], Si_M_Dia_old_B[sup.J_env_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &beta, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, WaveFunction_config_3[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						alpha=-sup.six_j_1_config_3[j_i][index];
						dsymm_(&side_R, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &alpha, Si_Dia_old_A[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_s_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; n++) {
                                                        correlation_function[para.N*i+para.N-m-1]+=f_s_p[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                        correlation_function[para.N*(para.N-m-1)+i]+=f_s_p[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                }

						delete [] f_t;  delete [] f_s;  delete [] f_s_p;
					}

				//------4
					else if(sup.J_sys_config_3[j_j]-sup.J_sys_config_3[j_i]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]==2 && sup.J_env_config_3[j_i]==sup.J_env_config_3[j_j] && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]!=0) {
						int dim_t=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];
                                                int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

                                                double *f_t=new double [dim_t];
						double *f_t_p=new double [dim_t];
                                                for(int l=0; l<dim_t; l++) {
							f_t[l]=0.0;  f_t_p[l]=0.0;
						}

                                                double *f_s=new double [dim_s];
                                                for(int l=0; l<dim_s; l++)      f_s[l]=0.0;
	
                                                alpha=1.0;  beta=0.0;
                                                dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &alpha, Si_M_Dia_old_A[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], WaveFunction_config_3[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						dsymm_(&side_R, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, Si_Dia_old_B[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_t_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);
			
						dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.six_j_1_config_3[j_i][index], f_t_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], WaveFunction_config_3[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; n++) {
                                                        correlation_function[para.N*i+para.N-m-1]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                        correlation_function[para.N*(para.N-m-1)+i]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                }

						delete [] f_t;  delete [] f_t_p;  delete [] f_s;
					}

				//------5
					else if(sup.J_sys_config_3[j_j]-sup.J_sys_config_3[j_i]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]==2 && sup.J_env_config_3[j_j]-sup.J_env_config_3[j_i]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]==2) {
                                                int dim_t=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]];

						int dim_t_p=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]];

                                                int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

                                                double *f_t=new double [dim_t];
                                                for(int l=0; l<dim_t; l++)      f_t[l]=0.0;

                                                double *f_t_p=new double [dim_t_p];
                                                for(int l=0; l<dim_t_p; l++)    f_t_p[l]=0.0;

                                                double *f_s=new double [dim_s];
                                                for(int l=0; l<dim_s; l++)      f_s[l]=0.0;

						alpha=1.0;  beta=0.0;
                                                dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, WaveFunction_config_3[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], Si_M_Dia_old_B[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &beta, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &alpha, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], WaveFunction_config_3[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, f_t_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.six_j_1_config_3[j_i][index], f_t_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], Si_M_Dia_old_A[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; n++) {
                                                        correlation_function[para.N*i+para.N-m-1]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                        correlation_function[para.N*(para.N-m-1)+i]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                }

						delete [] f_t;  delete [] f_t_p;  delete [] f_s;
					}

				//------6
					else if(sup.J_sys_config_3[j_j]-sup.J_sys_config_3[j_i]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]==2 && sup.J_env_config_3[j_i]-sup.J_env_config_3[j_j]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]==2) {
						int dim_t=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];

                                                int dim_t_p=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];

                                                int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

                                                double *f_t=new double [dim_t];
                                                for(int l=0; l<dim_t; l++)      f_t[l]=0.0;

                                                double *f_t_p=new double [dim_t_p];
                                                for(int l=0; l<dim_t_p; l++)    f_t_p[l]=0.0;

                                                double *f_s=new double [dim_s];
                                                for(int l=0; l<dim_s; l++)      f_s[l]=0.0;

						alpha=1.0;  beta=0.0;
                                                dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &alpha, WaveFunction_config_3[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], Si_M_Dia_old_B[sup.J_env_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &beta, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]);

                                                dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &alpha, Si_M_Dia_old_A[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, f_t_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						alpha=-sup.six_j_1_config_3[j_i][index];
						dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, WaveFunction_config_3[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], f_t_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &beta, f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; n++) {
                                                        correlation_function[para.N*i+para.N-m-1]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                        correlation_function[para.N*(para.N-m-1)+i]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                }

						delete [] f_t;  delete [] f_t_p;  delete [] f_s;
					}

				//------7
					else if(sup.J_sys_config_3[j_i]-sup.J_sys_config_3[j_j]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]==2 && sup.J_env_config_3[j_i]==sup.J_env_config_3[j_j] && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]!=0) {
                                                int dim_t=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];

                                                int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

                                                double *f_t=new double [dim_t];
						double *f_t_p=new double [dim_t];
                                                for(int l=0; l<dim_t; l++) {
							f_t[l]=0.0;  f_t_p[l]=0.0;
						}

                                                double *f_s=new double [dim_s];
                                                for(int l=0; l<dim_s; l++)      f_s[l]=0.0;

						alpha=1.0;  beta=0.0;
						dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &alpha, WaveFunction_config_3[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], Si_M_Dia_old_A[sup.J_sys_config_3[j_j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, f_t, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]);

						dsymm_(&side_L, &uplo, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &alpha, Si_Dia_old_B[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], f_t, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &beta, f_t_p, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]);

						alpha=-sup.six_j_1_config_3[j_i][index];
						dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, WaveFunction_config_3[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], f_t_p, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &beta, f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; n++) {
                                                        correlation_function[para.N*i+para.N-m-1]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                        correlation_function[para.N*(para.N-m-1)+i]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                }

						delete [] f_t;  delete [] f_t_p;  delete [] f_s;
					}
					
				//------8
					else if(sup.J_sys_config_3[j_i]-sup.J_sys_config_3[j_j]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]==2 && sup.J_env_config_3[j_j]-sup.J_env_config_3[j_i]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]==2) {
                                                int dim_t=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]];

                                                int dim_t_p=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];

                                                int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

                                                double *f_t=new double [dim_t];
                                                for(int l=0; l<dim_t; l++)      f_t[l]=0.0;

                                                double *f_t_p=new double [dim_t_p];
                                                for(int l=0; l<dim_t_p; l++)    f_t_p[l]=0.0;

                                                double *f_s=new double [dim_s];
                                                for(int l=0; l<dim_s; l++)      f_s[l]=0.0;

                                                alpha=1.0;  beta=0.0;
						dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &alpha, WaveFunction_config_3[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], Si_M_Dia_old_A[sup.J_sys_config_3[j_j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, f_t, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]]);

                                                dgemm_(&trans_N, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &alpha, Si_M_Dia_old_B[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], f_t, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &beta, f_t_p, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]);

						alpha=-sup.six_j_1_config_3[j_i][index];
                                                dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, WaveFunction_config_3[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], f_t_p, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &beta, f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; n++) {
                                                        correlation_function[para.N*i+para.N-m-1]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                        correlation_function[para.N*(para.N-m-1)+i]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                }

                                                delete [] f_t;  delete [] f_t_p;  delete [] f_s;
					}

				//------9
					else if(sup.J_sys_config_3[j_i]-sup.J_sys_config_3[j_j]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]==2 && sup.J_env_config_3[j_i]-sup.J_env_config_3[j_j]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]==2) {
                                                int dim_t=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];

                                                int dim_t_p=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];

                                                int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

                                                double *f_t=new double [dim_t];
                                                for(int l=0; l<dim_t; l++)      f_t[l]=0.0;

                                                double *f_t_p=new double [dim_t_p];
                                                for(int l=0; l<dim_t_p; l++)    f_t_p[l]=0.0;

                                                double *f_s=new double [dim_s];
                                                for(int l=0; l<dim_s; l++)      f_s[l]=0.0;

                                                alpha=1.0;  beta=0.0;
                                                dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &alpha, WaveFunction_config_3[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], Si_M_Dia_old_B[sup.J_env_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_j]], &beta, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]);

                                                dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &alpha, f_t, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], Si_M_Dia_old_A[sup.J_sys_config_3[j_j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, f_t_p, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]);

                                                dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.six_j_1_config_3[j_i][index], WaveFunction_config_3[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], f_t_p, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &beta, f_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]);

						for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; n++) {
                                                        correlation_function[para.N*i+para.N-m-1]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                        correlation_function[para.N*(para.N-m-1)+i]+=f_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                }

                                                delete [] f_t;  delete [] f_t_p;  delete [] f_s;
					}

					index++;
				}
			}

			cout<<"\n"<<i<<"\t"<<para.N-m-1<<"\t"<<correlation_function[para.N*i+para.N-m-1]<<endl;

	    //--Delete Sj operators
			for(int j=0; j<B_Sys_Number_Jn[para.N-lsys-3]; j++)
				delete [] Si_Dia_old_B[j];
			delete [] Si_Dia_old_B;	    		
			
			for(int j=0; j<B_Sys_Number_Jn[para.N-lsys-3]-1; j++)
				delete [] Si_M_Dia_old_B[j];
			delete [] Si_M_Dia_old_B;
//                }

	  //----Delete Si operators------------------------------------------------------------------------------
		for(int i=0; i<A_Sys_Number_Jn[lsys-1]; i++)
                        delete [] Si_Dia_old_A[i];
                delete [] Si_Dia_old_A;

                for(int i=0; i<A_Sys_Number_Jn[lsys-1]-1; i++)
                        delete [] Si_M_Dia_old_A[i];
                delete [] Si_M_Dia_old_A;
	}
}

//===============================================================================================================
inline void Sqspin::Correlation_sys_env_cpu(const int &lsys, Parameter &para, Super &sup) {
//------Calculate the wavefunction multiply the angular operators of env part------------------------------------
  //----Create space for tmp_wavefunction_env_dia
	double ***tmp_wavefunction_env_dia;
	tmp_wavefunction_env_dia=new double ** [para.N-2-lsys];

	for(int i=0; i<para.N-2-lsys; i++) {
		tmp_wavefunction_env_dia[i]=new double * [sup.BlockNumber_for_TargetSpin_config_3];
		for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++) 
		if(sup.env->Sys_Value_Jn[sup.J_env_config_3[j]]!=0) {
			tmp_wavefunction_env_dia[i][j]=new double [sup.Dim_block_config_3[j]];
			for(int k=0; k<sup.Dim_block_config_3[j]; k++) 
				tmp_wavefunction_env_dia[i][j][k]=0.0;
		}
	}

  //----Create space for tmp_wavefunction_env_up
        double ***tmp_wavefunction_env_up;
        tmp_wavefunction_env_up=new double ** [para.N-2-lsys];

        for(int i=0; i<para.N-2-lsys; i++) {
                tmp_wavefunction_env_up[i]=new double * [sup.BlockNumber_for_TargetSpin_config_3];
                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++) 
		if(sup.J_env_config_3[j]!=0 && (sup.env->Sys_Value_Jn[sup.J_env_config_3[j]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j]-1])==2) {
			int dim=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]-1];
                        tmp_wavefunction_env_up[i][j]=new double [dim];
                        for(int k=0; k<dim; k++) 
                                tmp_wavefunction_env_up[i][j][k]=0.0;
                }
        }

  //----Create space for tmp_wavefunction_env_dw
        double ***tmp_wavefunction_env_dw;
        tmp_wavefunction_env_dw=new double ** [para.N-2-lsys];

        for(int i=0; i<para.N-2-lsys; i++) {
                tmp_wavefunction_env_dw[i]=new double * [sup.BlockNumber_for_TargetSpin_config_3];
                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++)
                if(sup.J_env_config_3[j]!=(sup.env->Sys_Number_Jn-1) && (sup.env->Sys_Value_Jn[sup.J_env_config_3[j]+1]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j]])==2) {
                        int dim=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]+1];
                        tmp_wavefunction_env_dw[i][j]=new double [dim];
                        for(int k=0; k<dim; k++)                      
                                tmp_wavefunction_env_dw[i][j][k]=0.0;
                }
        }

  //----Initialize tmp_wavefunction_env
	alpha=1.0;      beta=0.0;

        for(int i=0; i<para.N-2-lsys; i++) {
                if(i==0)        New_B_Si_initial(0, para);
                else  {
                        New_B_Si_initial(i, para);
                        Truncate_B_Si(i);
                }

                for(int n=i+1; n<para.N-2-lsys; n++) {
                        New_B_Si_new(n, para);
                        Truncate_B_Si(n);
                }

                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++) 
		if(sup.env->Sys_Value_Jn[sup.J_env_config_3[j]]!=0) {
                        dsymm_(&side_R, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]], &alpha, Si_Dia_old_B[sup.J_env_config_3[j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]], WaveFunction_config_3[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &beta, tmp_wavefunction_env_dia[i][j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]]);
                }
 
		for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++)
                if(sup.J_env_config_3[j]!=0 && (sup.env->Sys_Value_Jn[sup.J_env_config_3[j]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j]-1])==2) {
                        dgemm_(&trans_N, &trans_T, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]-1], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]], &alpha, Si_M_Dia_old_B[sup.J_env_config_3[j]-1], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]-1], WaveFunction_config_3[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &beta, tmp_wavefunction_env_up[i][j], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]-1]);
		}

                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++)
                if(sup.J_env_config_3[j]!=(sup.env->Sys_Number_Jn-1) && (sup.env->Sys_Value_Jn[sup.J_env_config_3[j]+1]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j]])==2) {
	                dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]+1], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]], &alpha, WaveFunction_config_3[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], Si_M_Dia_old_B[sup.J_env_config_3[j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]], &beta, tmp_wavefunction_env_dw[i][j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]]);
		}

          //----Delete space
                for(int j=0; j<B_Sys_Number_Jn[para.N-lsys-3]; j++)
                        delete [] Si_Dia_old_B[j];
                delete [] Si_Dia_old_B;

                for(int j=0; j<B_Sys_Number_Jn[para.N-lsys-3]-1; j++)
                        delete [] Si_M_Dia_old_B[j];
                delete [] Si_M_Dia_old_B;
	}

//------Calculate the spin-spin correlation function-------------------------------------------------------------
	for(int i=0; i<lsys; i++) 
	if( i > 49 ) {

          //----Initialize Si operators--------------------------------------------------------------------------
                if(i==0)        New_A_Si_initial(0, para);
                else  {
                        New_A_Si_initial(i, para);
                        Truncate_A_Si(i);
                }
          
          //----Transform Si operators---------------------------------------------------------------------------
                for(int j=i+1; j<lsys; j++) {
                        New_A_Si_new(j, para);
                        Truncate_A_Si(j);
                }
          
	  //----Calculate the tmp_wavefunction_sys---------------------------------------------------------------
	    //--Create space for tmp_wavefunction_sys
		double **tmp_wavefunction_sys_dia;
		tmp_wavefunction_sys_dia=new double * [sup.BlockNumber_for_TargetSpin_config_3];
		for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++) 
		if(sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]]!=0) {
                        tmp_wavefunction_sys_dia[j]=new double [sup.Dim_block_config_3[j]];
                        for(int k=0; k<sup.Dim_block_config_3[j]; k++)
                                tmp_wavefunction_sys_dia[j][k]=0.0;
		}

		double **tmp_wavefunction_sys_up;
		tmp_wavefunction_sys_up=new double * [sup.BlockNumber_for_TargetSpin_config_3];
                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++) 
		if(sup.J_sys_config_3[j]!=(sup.sys->Sys_Number_Jn-1) && (sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]+1]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]])==2) {
			int dim=sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]+1];
			tmp_wavefunction_sys_up[j]=new double [dim];
			for(int k=0; k<dim; k++)
				tmp_wavefunction_sys_up[j][k]=0.0;
		}

                double **tmp_wavefunction_sys_dw;
                tmp_wavefunction_sys_dw=new double * [sup.BlockNumber_for_TargetSpin_config_3];
                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++) 
                if(sup.J_sys_config_3[j]!=0 && (sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]-1])==2) {
                        int dim=sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]-1];
                        tmp_wavefunction_sys_dw[j]=new double [dim];
                        for(int k=0; k<dim; k++)
                                tmp_wavefunction_sys_dw[j][k]=0.0;
                }

	    //--Initialize tmp_wavefunction_sys
		alpha=1.0;      beta=0.0;

		for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++) 
		if(sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]]!=0) {
	                dsymm_(&side_L, &uplo, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]], &alpha, Si_Dia_old_A[sup.J_sys_config_3[j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], WaveFunction_config_3[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &beta, tmp_wavefunction_sys_dia[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]]);
		}

                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++)
                if(sup.J_sys_config_3[j]!=(sup.sys->Sys_Number_Jn-1) && (sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]+1]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]])==2) {
                	dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]+1], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &alpha, WaveFunction_config_3[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], Si_M_Dia_old_A[sup.J_sys_config_3[j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &beta, tmp_wavefunction_sys_up[j], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]]);
		}

                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++)
                if(sup.J_sys_config_3[j]!=0 && (sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]-1])==2) {
                	dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]-1], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &alpha, Si_M_Dia_old_A[sup.J_sys_config_3[j]-1], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]-1], WaveFunction_config_3[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]], &beta, tmp_wavefunction_sys_dw[j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j]-1]);
		}

	    //--Delete space
                for(int j=0; j<A_Sys_Number_Jn[lsys-1]; j++)
                        delete [] Si_Dia_old_A[j];
                delete [] Si_Dia_old_A;

                for(int j=0; j<A_Sys_Number_Jn[lsys-1]-1; j++)
                        delete [] Si_M_Dia_old_A[j];
                delete [] Si_M_Dia_old_A;

	//------Calculate the spin-spin correlation function-----------------------------------------------------
		for(int j=0; j<para.N-lsys-2; j++)
		if( j > 49 ) {

                	for(int j_i=0; j_i<sup.BlockNumber_for_TargetSpin_config_3; j_i++) {
	                	int index=0;
                        	for(int j_j=0; j_j<sup.BlockNumber_for_TargetSpin_config_3; j_j++)
                        	if(sup.J_sysnew_config_3[j_j]==sup.J_sysnew_config_3[j_i] && sup.J_envnew_config_3[j_j]==sup.J_envnew_config_3[j_i] && abs(sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]])<=2 && abs(sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]])<=2) {
                        //------1
	                        	if(j_i==j_j && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]!=0 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]!=0) {
						int dim=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]];

						double *matrix=new double [dim];
						for(int p=0; p<dim; p++)      matrix[p]=0.0;
	
	                                	dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.six_j_1_config_3[j_i][index], tmp_wavefunction_sys_dia[j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], tmp_wavefunction_env_dia[j][j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]);

                                        	for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]]; p++) {
	                                        	correlation_function[para.N*i+para.N-j-1]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                                	correlation_function[para.N*(para.N-j-1)+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]])];
                                        	}

						delete [] matrix;
					}

                        //------2
                                	else if(sup.J_sys_config_3[j_i]==sup.J_sys_config_3[j_j] && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]!=0 && sup.J_env_config_3[j_j]-sup.J_env_config_3[j_i]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]==2) {
                                		int dim=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]];
        
                                        	double *matrix=new double [dim];
                                        	for(int p=0; p<dim; p++)      matrix[p]=0.0;

                                        	dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.six_j_1_config_3[j_i][index], tmp_wavefunction_sys_dia[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_i]], tmp_wavefunction_env_up[j][j_j], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]);

                                        	for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]; p++) {
	                                        	correlation_function[para.N*i+para.N-j-1]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                                	correlation_function[para.N*(para.N-j-1)+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                        	}

						delete [] matrix;
					}

                        //------3
                                	else if(sup.J_sys_config_3[j_i]==sup.J_sys_config_3[j_j] && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]!=0 && sup.J_env_config_3[j_i]-sup.J_env_config_3[j_j]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]==2) {
                                        	int dim=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]];

                                        	double *matrix=new double [dim];
                                        	for(int p=0; p<dim; p++)      matrix[p]=0.0;

                                        	alpha=-sup.six_j_1_config_3[j_i][index];
                                        	dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, tmp_wavefunction_sys_dia[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], tmp_wavefunction_env_dw[j][j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]);

                                        	for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]; p++) {
                                                	correlation_function[para.N*i+para.N-j-1]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                                	correlation_function[para.N*(para.N-j-1)+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                        	}

                                        	delete [] matrix;
					}

                        //------4
                                	else if(sup.J_sys_config_3[j_j]-sup.J_sys_config_3[j_i]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]==2 && sup.J_env_config_3[j_i]==sup.J_env_config_3[j_j] && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]!=0) {
                                        	int dim=sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];

                                        	double *matrix=new double [dim];
                                        	for(int p=0; p<dim; p++)      matrix[p]=0.0;

                                        	dgemm_(&trans_N, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.six_j_1_config_3[j_i][index], tmp_wavefunction_sys_up[j_i], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], tmp_wavefunction_env_dia[j][j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, matrix, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]);
                                
                                        	for(int p=0; p<sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]; p++) {
                                                	correlation_function[para.N*i+para.N-j-1]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]])];
                                                	correlation_function[para.N*(para.N-j-1)+i]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]])];
                                        	}

                                        	delete [] matrix;
					}

                        //------5
                                	else if(sup.J_sys_config_3[j_j]-sup.J_sys_config_3[j_i]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]==2 && sup.J_env_config_3[j_j]-sup.J_env_config_3[j_i]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]==2) {
	                                	int dim=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]];
                                
                                        	double *matrix=new double [dim];
                                        	for(int p=0; p<dim; p++)      matrix[p]=0.0;

                                        	dgemm_(&trans_T, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.six_j_1_config_3[j_i][index], tmp_wavefunction_sys_up[j_i], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], tmp_wavefunction_env_up[j][j_j], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]);

                                        	for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]; p++) {
                                                	correlation_function[para.N*i+para.N-j-1]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                                	correlation_function[para.N*(para.N-j-1)+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                        	}

                                        	delete [] matrix;
					}
	
                        //------6
                                	else if(sup.J_sys_config_3[j_j]-sup.J_sys_config_3[j_i]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]==2 && sup.J_env_config_3[j_i]-sup.J_env_config_3[j_j]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]==2) {
                                        	int dim=sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];

                                        	double *matrix=new double [dim];
                                        	for(int p=0; p<dim; p++)      matrix[p]=0.0;

                                        	alpha=-sup.six_j_1_config_3[j_i][index];
                                        	dgemm_(&trans_N, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &alpha, tmp_wavefunction_sys_up[j_i], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], tmp_wavefunction_env_dw[j][j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, matrix, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]);

                                        	for(int p=0; p<sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]; p++) {
                                                	correlation_function[para.N*i+para.N-j-1]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]])];
                                                	correlation_function[para.N*(para.N-j-1)+i]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]])];
                                        	}

                                        	delete [] matrix;
					}

                        //------7
                                	else if(sup.J_sys_config_3[j_i]-sup.J_sys_config_3[j_j]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]==2 && sup.J_env_config_3[j_i]==sup.J_env_config_3[j_j] && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]!=0) {
                                        	int dim=sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]*sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]];

                                        	double *matrix=new double [dim];
                                        	for(int p=0; p<dim; p++)      matrix[p]=0.0;

                                        	alpha=-sup.six_j_1_config_3[j_i][index];
                                        	dgemm_(&trans_T, &trans_N, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &alpha, tmp_wavefunction_sys_dw[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], tmp_wavefunction_env_dia[j][j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, matrix, &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]);

                                        	for(int p=0; p<sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]]; p++) {
                                                	correlation_function[para.N*i+para.N-j-1]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]])];
                                               		correlation_function[para.N*(para.N-j-1)+i]+=matrix[p*(1+sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]])];
                                        	}

                                        	delete [] matrix;
					}

                        //------8
                                	else if(sup.J_sys_config_3[j_i]-sup.J_sys_config_3[j_j]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]==2 && sup.J_env_config_3[j_j]-sup.J_env_config_3[j_i]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]==2) {
                                        	int dim=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]];

                                        	double *matrix=new double [dim];
                                        	for(int p=0; p<dim; p++)      matrix[p]=0.0;
                               
                                        	alpha=-sup.six_j_1_config_3[j_i][index];
                                        	dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &alpha, tmp_wavefunction_sys_dw[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], tmp_wavefunction_env_up[j][j_j], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]);

                                        	for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]; p++) {
                                                	correlation_function[para.N*i+para.N-j-1]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                                	correlation_function[para.N*(para.N-j-1)+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                        	}

                                        	delete [] matrix;
					}

                        //------9
                                	else if(sup.J_sys_config_3[j_i]-sup.J_sys_config_3[j_j]==1 && sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_i]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j_j]]==2 && sup.J_env_config_3[j_i]-sup.J_env_config_3[j_j]==1 && sup.env->Sys_Value_Jn[sup.J_env_config_3[j_i]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j_j]]==2) {
                                        	int dim=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]];

                                        	double *matrix=new double [dim];
                                        	for(int p=0; p<dim; p++)      matrix[p]=0.0;

                                        	dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[j_i]], &sup.six_j_1_config_3[j_i][index], tmp_wavefunction_sys_dw[j_i], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], tmp_wavefunction_env_dw[j][j_j], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]);

                                        	for(int p=0; p<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]]; p++) {
                                                	correlation_function[para.N*i+para.N-j-1]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                                	correlation_function[para.N*(para.N-j-1)+i]+=matrix[p*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[j_j]])];
                                        	}

                                        	delete [] matrix;
					}

					index++;
				}
			}

                	cout<<"\n"<<i<<"\t"<<para.N-j-1<<"\t"<<correlation_function[para.N*i+para.N-j-1]<<endl;

		}

	  //---Delete tmp_wavefunction_sys-----------------------------------------------------------------------
		for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++)
		if(sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]]!=0)
			delete [] tmp_wavefunction_sys_dia[j];
		delete [] tmp_wavefunction_sys_dia;

                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++)
                if(sup.J_sys_config_3[j]!=(sup.sys->Sys_Number_Jn-1) && (sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]+1]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]])==2) 
			delete [] tmp_wavefunction_sys_up[j];
		delete [] tmp_wavefunction_sys_up;

                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++)
                if(sup.J_sys_config_3[j]!=0 && (sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]]-sup.sys->Sys_Value_Jn[sup.J_sys_config_3[j]-1])==2) 
			delete [] tmp_wavefunction_sys_dw[j];
		delete [] tmp_wavefunction_sys_dw;
	}

//------Delete the tmp_wavefunction_env--------------------------------------------------------------------------
  //----tmp_wavefunction_env_dia
	for(int i=0; i<para.N-2-lsys; i++) {
		for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++) 
		if(sup.env->Sys_Value_Jn[sup.J_env_config_3[j]]!=0) {
			delete [] tmp_wavefunction_env_dia[i][j];
		}
		delete [] tmp_wavefunction_env_dia[i];
	}
	delete [] tmp_wavefunction_env_dia;

  //----tmp_wavefunction_env_up
        for(int i=0; i<para.N-2-lsys; i++) {
                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++) 
		if(sup.J_env_config_3[j]!=0 && (sup.env->Sys_Value_Jn[sup.J_env_config_3[j]]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j]-1])==2){
                        delete [] tmp_wavefunction_env_up[i][j];
                }
                delete [] tmp_wavefunction_env_up[i];
        }
        delete [] tmp_wavefunction_env_up;

  //----tmp_wavefunction_env_dw
        for(int i=0; i<para.N-2-lsys; i++) {
                for(int j=0; j<sup.BlockNumber_for_TargetSpin_config_3; j++)
		if(sup.J_env_config_3[j]!=(sup.env->Sys_Number_Jn-1) && (sup.env->Sys_Value_Jn[sup.J_env_config_3[j]+1]-sup.env->Sys_Value_Jn[sup.J_env_config_3[j]])==2) {
                        delete [] tmp_wavefunction_env_dw[i][j];
                }
                delete [] tmp_wavefunction_env_dw[i];
        }
        delete [] tmp_wavefunction_env_dw;
}

//===============================================================================================================

//===============================================================================================================
//===============================================================================================================
//						     New_A_Si
//===============================================================================================================
inline void Sqspin::New_A_Si_new(const int &num, Parameter &para) {
//------Create space and define the operators of Si--------------------------------------------------------------
	Si_Dia_new_A=new double * [A_N_Sys_Number_Jn[num]];
	Si_M_Dia_new_A=new double * [A_N_Sys_Number_Jn[num]-1];

	for(int i=0; i<A_N_Sys_Number_Jn[num]; i++) {
		int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i];
		Si_Dia_new_A[i]=new double [Dia_Dim];
		for(int j=0; j<Dia_Dim; j++) 
			Si_Dia_new_A[i][j]=0.0;
	}

	for(int i=0; i<A_N_Sys_Number_Jn[num]-1; i++) {
		int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i+1];
		Si_M_Dia_new_A[i]=new double [Dia_Dim];
		for(int j=0; j<Dia_Dim; j++)
			Si_M_Dia_new_A[i][j]=0.0;
	}

//------The new basis transformation-----------------------------------------------------------------------
	int oldJn, oldJm, position, a_new, a_new_t;
	double factor;

    //--New_S_Dia-----------------------------------------------------------
	for(int j=0; j<A_N_Sys_Number_Jn[num]; j++)
        if(A_N_Sys_Value_Jn[num][j]!=0) {
        	for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=A_N_IndexOld[num][n][j])!=-1 && (oldJm=A_N_IndexOld[num][m][j])!=-1) {
               		if(oldJn==oldJm && A_Sys_Value_Jn[num-1][oldJn]!=0) {
                        	position=(A_N_Sys_SubBlockNumber_Jn[num][j]+1)*A_N_Start[num][n][j];
                                factor=pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j]+2+para.S)/2)*(A_N_Sys_Value_Jn[num][j]+1.0)*A_six_j_S_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJn]*A_Sys_SubBlockNumber_Jn[num-1][oldJn]; a_old++) {
                                	a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                        Si_Dia_new_A[j][a_new]+=factor*Si_Dia_old_A[oldJn][a_old];
                                }
                        }

                        else if((oldJm-oldJn)==1 && (A_Sys_Value_Jn[num-1][oldJm]-A_Sys_Value_Jn[num-1][oldJn])==2) {
                        	position=A_N_Sys_SubBlockNumber_Jn[num][j]*A_N_Start[num][m][j]+A_N_Start[num][n][j];
                                factor=pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j]+2+para.S)/2)*(A_N_Sys_Value_Jn[num][j]+1.0)*A_six_j_S_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJn]*A_Sys_SubBlockNumber_Jn[num-1][oldJn+1]; a_old++) {
                                	a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJn];
					a_new_t=A_N_Sys_SubBlockNumber_Jn[num][j]*(a_new%A_N_Sys_SubBlockNumber_Jn[num][j])+a_new/A_N_Sys_SubBlockNumber_Jn[num][j];
                                        Si_Dia_new_A[j][a_new]+=factor*Si_M_Dia_old_A[oldJn][a_old];
                                        Si_Dia_new_A[j][a_new_t]+=factor*Si_M_Dia_old_A[oldJn][a_old]; 
                                }
                        }
                }
        }

    //--New S_M_Dia-----------------------------------------------------------------	
	for(int j=0; j<A_N_Sys_Number_Jn[num]-1; j++)
        if((A_N_Sys_Value_Jn[num][j+1]-A_N_Sys_Value_Jn[num][j])==2) {
		for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=A_N_IndexOld[num][n][j])!=-1 && (oldJm=A_N_IndexOld[num][m][j+1])!=-1) {
	        	if(oldJn==oldJm && A_Sys_Value_Jn[num-1][oldJn]!=0) {
				position=A_N_Sys_SubBlockNumber_Jn[num][j]*A_N_Start[num][m][j+1]+A_N_Start[num][n][j];
                		factor=pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((A_N_Sys_Value_Jn[num][j]+1.0)*(A_N_Sys_Value_Jn[num][j+1]+1.0))*A_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                		for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJn]*A_Sys_SubBlockNumber_Jn[num-1][oldJn]; a_old++) {
                  			a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJn];
                        		Si_M_Dia_new_A[j][a_new]+=factor*Si_Dia_old_A[oldJn][a_old];
                 		}
                	}

                	else if((oldJn-oldJm)==1 && (A_Sys_Value_Jn[num-1][oldJn]-A_Sys_Value_Jn[num-1][oldJm])==2) {     //This condition is actually not satisfied!!!
             			position=A_N_Sys_SubBlockNumber_Jn[num][j]*A_N_Start[num][m][j+1]+A_N_Start[num][n][j];
                        	factor=-pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((A_N_Sys_Value_Jn[num][j]+1.0)*(A_N_Sys_Value_Jn[num][j+1]+1.0))*A_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                        	for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJm]*A_Sys_SubBlockNumber_Jn[num-1][oldJm+1]; a_old++) {
                           		a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJm])+a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJm];
			        	Si_M_Dia_new_A[j][a_new]+=factor*Si_M_Dia_old_A[oldJm][a_old];
                        	}
                	}

                	else if((oldJm-oldJn)==1 && (A_Sys_Value_Jn[num-1][oldJm]-A_Sys_Value_Jn[num-1][oldJn])==2) {
                      		position=A_N_Sys_SubBlockNumber_Jn[num][j]*A_N_Start[num][m][j+1]+A_N_Start[num][n][j];
                        	factor=pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((A_N_Sys_Value_Jn[num][j]+1.0)*(A_N_Sys_Value_Jn[num][j+1]+1.0))*A_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                        	for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJn]*A_Sys_SubBlockNumber_Jn[num-1][oldJn+1]; a_old++) {
                             		a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                	Si_M_Dia_new_A[j][a_new]+=factor*Si_M_Dia_old_A[oldJn][a_old];
                        	}
                	}
        	}
	}

//------Delete Si_old--------------------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[num-1]; i++) 
		delete [] Si_Dia_old_A[i];
	delete [] Si_Dia_old_A;		

	for(int i=0; i<A_Sys_Number_Jn[num-1]-1; i++)
		delete [] Si_M_Dia_old_A[i];
	delete [] Si_M_Dia_old_A;

//------Create new Si_old----------------------------------------------------------------------------------------
        Si_Dia_old_A=new double * [A_N_Sys_Number_Jn[num]];
        Si_M_Dia_old_A=new double * [A_N_Sys_Number_Jn[num]-1];

        for(int i=0; i<A_N_Sys_Number_Jn[num]; i++) {
                int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i];
                Si_Dia_old_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_old_A[i][j]=Si_Dia_new_A[i][j];
        }

        for(int i=0; i<A_N_Sys_Number_Jn[num]-1; i++) {
                int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i+1];
                Si_M_Dia_old_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_old_A[i][j]=Si_M_Dia_new_A[i][j];
        }

//------Delete Si_new--------------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[num]; i++) 
                delete [] Si_Dia_new_A[i]; 
        delete [] Si_Dia_new_A;           

	for(int i=0; i<A_N_Sys_Number_Jn[num]-1; i++)
		delete [] Si_M_Dia_new_A[i];
	delete [] Si_M_Dia_new_A;
}

//===============================================================================================================
//							New B_Si
//===============================================================================================================
inline void Sqspin::New_B_Si_new(const int &num, Parameter &para) {
//------Create space and define the operators of Si--------------------------------------------------------------
        Si_Dia_new_B=new double * [B_N_Sys_Number_Jn[num]];
        Si_M_Dia_new_B=new double * [B_N_Sys_Number_Jn[num]-1];

        for(int i=0; i<B_N_Sys_Number_Jn[num]; i++) {
                int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i];
                Si_Dia_new_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_new_B[i][j]=0.0;
        }

        for(int i=0; i<B_N_Sys_Number_Jn[num]-1; i++) {
                int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i+1];
                Si_M_Dia_new_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_new_B[i][j]=0.0;
        }

//------The new basis transformation-----------------------------------------------------------------------------
	int oldJn, oldJm, position, a_new, a_new_t;
        double factor;

    //--New_S_Dia-----------------------------------------------------------
	for(int j=0; j<B_N_Sys_Number_Jn[num]; j++)
        if(B_N_Sys_Value_Jn[num][j]!=0) {
                for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=B_N_IndexOld[num][n][j])!=-1 && (oldJm=B_N_IndexOld[num][m][j])!=-1) {
                        if(oldJn==oldJm && B_Sys_Value_Jn[num-1][oldJn]!=0) {
                                position=(B_N_Sys_SubBlockNumber_Jn[num][j]+1)*B_N_Start[num][n][j];
                                factor=pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j]+2+para.S)/2)*(B_N_Sys_Value_Jn[num][j]+1.0)*B_six_j_S_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJn]*B_Sys_SubBlockNumber_Jn[num-1][oldJn]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                        Si_Dia_new_B[j][a_new]+=factor*Si_Dia_old_B[oldJn][a_old];
                                }
                        }
                        else if((oldJm-oldJn)==1 && (B_Sys_Value_Jn[num-1][oldJm]-B_Sys_Value_Jn[num-1][oldJn])==2) {
                                position=B_N_Sys_SubBlockNumber_Jn[num][j]*B_N_Start[num][m][j]+B_N_Start[num][n][j];
                                factor=pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j]+2+para.S)/2)*(B_N_Sys_Value_Jn[num][j]+1.0)*B_six_j_S_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJn]*B_Sys_SubBlockNumber_Jn[num-1][oldJn+1]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJn];
				        a_new_t=B_N_Sys_SubBlockNumber_Jn[num][j]*(a_new%B_N_Sys_SubBlockNumber_Jn[num][j])+a_new/B_N_Sys_SubBlockNumber_Jn[num][j];
                                        Si_Dia_new_B[j][a_new]+=factor*Si_M_Dia_old_B[oldJn][a_old];
                                        Si_Dia_new_B[j][a_new_t]+=factor*Si_M_Dia_old_B[oldJn][a_old];
                                }
                        }
                }
        }

    //--New S_M_Dia-----------------------------------------------------------------    
	for(int j=0; j<B_N_Sys_Number_Jn[num]-1; j++)
        if((B_N_Sys_Value_Jn[num][j+1]-B_N_Sys_Value_Jn[num][j])==2) {
                for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=B_N_IndexOld[num][n][j])!=-1 && (oldJm=B_N_IndexOld[num][m][j+1])!=-1) {
                        if(oldJn==oldJm && B_Sys_Value_Jn[num-1][oldJn]!=0) {
                                position=B_N_Sys_SubBlockNumber_Jn[num][j]*B_N_Start[num][m][j+1]+B_N_Start[num][n][j];
                                factor=pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((B_N_Sys_Value_Jn[num][j]+1.0)*(B_N_Sys_Value_Jn[num][j+1]+1.0))*B_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJn]*B_Sys_SubBlockNumber_Jn[num-1][oldJn]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                        Si_M_Dia_new_B[j][a_new]+=factor*Si_Dia_old_B[oldJn][a_old];
                                }
                        }

                        else if((oldJn-oldJm)==1 && (B_Sys_Value_Jn[num-1][oldJn]-B_Sys_Value_Jn[num-1][oldJm])==2) {   
				 position=B_N_Sys_SubBlockNumber_Jn[num][j]*B_N_Start[num][m][j+1]+B_N_Start[num][n][j];
                                factor=-pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((B_N_Sys_Value_Jn[num][j]+1.0)*(B_N_Sys_Value_Jn[num][j+1]+1.0))*B_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJm]*B_Sys_SubBlockNumber_Jn[num-1][oldJm+1]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJm])+a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJm];
                                        Si_M_Dia_new_B[j][a_new]+=factor*Si_M_Dia_old_B[oldJm][a_old];
                                }
                        }

                        else if((oldJm-oldJn)==1 && (B_Sys_Value_Jn[num-1][oldJm]-B_Sys_Value_Jn[num-1][oldJn])==2) {
                                position=B_N_Sys_SubBlockNumber_Jn[num][j]*B_N_Start[num][m][j+1]+B_N_Start[num][n][j];
                                factor=pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((B_N_Sys_Value_Jn[num][j]+1.0)*(B_N_Sys_Value_Jn[num][j+1]+1.0))*B_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJn]*B_Sys_SubBlockNumber_Jn[num-1][oldJn+1]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                        Si_M_Dia_new_B[j][a_new]+=factor*Si_M_Dia_old_B[oldJn][a_old];
                                }
                        }
                }
        }

//------Delete Si_old--------------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[num-1]; i++)
                delete [] Si_Dia_old_B[i];
        delete [] Si_Dia_old_B;

        for(int i=0; i<B_Sys_Number_Jn[num-1]-1; i++)
                delete [] Si_M_Dia_old_B[i];
        delete [] Si_M_Dia_old_B;

//------Create new Si_old----------------------------------------------------------------------------------------
        Si_Dia_old_B=new double * [B_N_Sys_Number_Jn[num]];
        Si_M_Dia_old_B=new double * [B_N_Sys_Number_Jn[num]-1];

        for(int i=0; i<B_N_Sys_Number_Jn[num]; i++) {
                int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i];
                Si_Dia_old_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_old_B[i][j]=Si_Dia_new_B[i][j];
        }

        for(int i=0; i<B_N_Sys_Number_Jn[num]-1; i++) {
                int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i+1];
                Si_M_Dia_old_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_old_B[i][j]=Si_M_Dia_new_B[i][j];
        }

//------Delete Si_new--------------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[num]; i++)
                delete [] Si_Dia_new_B[i];
        delete [] Si_Dia_new_B;

        for(int i=0; i<B_N_Sys_Number_Jn[num]-1; i++)
                delete [] Si_M_Dia_new_B[i];
        delete [] Si_M_Dia_new_B;
}

//===============================================================================================================
//						New_A_Si_initial
//===============================================================================================================
inline void Sqspin::New_A_Si_initial(const int &n_num, Parameter &para) {

	if(n_num==0) {
           //------Create space----------------------------------------------------------------------------------
	        Si_Dia_old_A=new double * [1];
		for(int i=0; i<1; i++) {
			Si_Dia_old_A[i]=new double [1];
			Si_Dia_old_A[i][0]=constant;
		}

		Si_M_Dia_old_A=new double * [0];
		for(int i=0; i<0; i++) {
			Si_M_Dia_old_A[i]=new double [0];
			for(int j=0; j<0; j++)
				Si_M_Dia_old_A[i][j]=0.0;
		}
	}

	else if(n_num>0) {
           //------Create space----------------------------------------------------------------------------------
        	Si_Dia_old_A=new double * [A_N_Sys_Number_Jn[n_num]];
        	Si_M_Dia_old_A=new double * [A_N_Sys_Number_Jn[n_num]-1];

        	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++) {
                	int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i];
                	Si_Dia_old_A[i]=new double [Dia_Dim];
                	for(int j=0; j<Dia_Dim; j++) 
                        	Si_Dia_old_A[i][j]=0.0;
        	}

        	for(int i=0; i<A_N_Sys_Number_Jn[n_num]-1; i++) {
                	int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i+1];
                	Si_M_Dia_old_A[i]=new double [Dia_Dim];
                	for(int j=0; j<Dia_Dim; j++)
                        	Si_M_Dia_old_A[i][j]=0.0;
        	}

           //------The new basis transformation------------------------------------------------------------------
		int oldJn, oldJm, position, a_new, a_new_t;
        	double factor;

		//--New S_Dia---------------------------------------------------
		for(int j=0; j<A_N_Sys_Number_Jn[n_num]; j++)
		if(A_N_Sys_Value_Jn[n_num][j]!=0) {
			for(int n=0; n<para.S+1; n++)
        	        if((oldJn=A_N_IndexOld[n_num][n][j])!=-1) {
                		position=A_N_Sys_SubBlockNumber_Jn[n_num][j]+1;
                        	factor=pow(-1.0, (A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJn]+2+para.S)/2)*(A_N_Sys_Value_Jn[n_num][j]+1.0)*A_six_j_S_Dia_n[n_num-1][j][oldJn]*constant;
                        	for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]; a_old++) {
                        		a_new=position*(A_N_Start[n_num][n][j]+a_old);
                                	Si_Dia_old_A[j][a_new]+=factor;
                        	}
                	}
		}

    		//--New S_M_Dia-------------------------------------------------
		for(int j=0; j<A_N_Sys_Number_Jn[n_num]-1; j++)
        	if((A_N_Sys_Value_Jn[n_num][j+1]-A_N_Sys_Value_Jn[n_num][j])==2) {
        		for(int n=0; n<para.S+1; n++)
                	for(int m=0; m<para.S+1; m++) {
                		if((oldJn=A_N_IndexOld[n_num][n][j])!=-1 && (oldJm=A_N_IndexOld[n_num][m][j+1])!=-1)
                        	if(oldJn==oldJm) {
                        		position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][m][j+1]+A_N_Start[n_num][n][j];
                                	factor=pow(-1.0, (A_Sys_Value_Jn[n_num-1][oldJn]+A_N_Sys_Value_Jn[n_num][j]+2+para.S)/2)*sqrt((A_N_Sys_Value_Jn[n_num][j]+1.0)*(A_N_Sys_Value_Jn[n_num][j+1]+1.0))*A_six_j_S_M_Dia_n[n_num-1][j][oldJn]*constant;
                                	for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]; a_old++) {
                                		a_new=position+(A_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*a_old;
                                        	Si_M_Dia_old_A[j][a_new]+=factor;
                                	}
                        	}
                	}
        	}
	}
}

//===============================================================================================================
//						New B_Si initial
//===============================================================================================================
inline void Sqspin::New_B_Si_initial(const int &n_num, Parameter &para) {

        if(n_num==0) {
                Si_Dia_old_B=new double * [1];
                for(int i=0; i<1; i++) {
                        Si_Dia_old_B[i]=new double [1];
                        Si_Dia_old_B[i][0]=constant;
                }

                Si_M_Dia_old_B=new double * [0];
                for(int i=0; i<0; i++) {
                        Si_M_Dia_old_B[i]=new double [0];
                        for(int j=0; j<0; j++)
                                Si_M_Dia_old_B[i][j]=0.0;
                }
        }

        else if(n_num>0) {
           //------Create space----------------------------------------------------------------------------------
                Si_Dia_old_B=new double * [B_N_Sys_Number_Jn[n_num]];
                Si_M_Dia_old_B=new double * [B_N_Sys_Number_Jn[n_num]-1];

                for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++) {
                        int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i];
                        Si_Dia_old_B[i]=new double [Dia_Dim];
                        for(int j=0; j<Dia_Dim; j++)
                                Si_Dia_old_B[i][j]=0.0;
                }

                for(int i=0; i<B_N_Sys_Number_Jn[n_num]-1; i++) {
                        int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i+1];
                        Si_M_Dia_old_B[i]=new double [Dia_Dim];
                        for(int j=0; j<Dia_Dim; j++)
                                Si_M_Dia_old_B[i][j]=0.0;
                }
		
           //------The new basis transformation------------------------------------------------------------------
 	   	int oldJn, oldJm, position, a_new, a_new_t;
                double factor;

                //--New S_Dia---------------------------------------------------
                for(int j=0; j<B_N_Sys_Number_Jn[n_num]; j++)
                if(B_N_Sys_Value_Jn[n_num][j]!=0) {
                        for(int n=0; n<para.S+1; n++)
                        if((oldJn=B_N_IndexOld[n_num][n][j])!=-1) {
                                position=B_N_Sys_SubBlockNumber_Jn[n_num][j]+1;
                                factor=pow(-1.0, (B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJn]+2+para.S)/2)*(B_N_Sys_Value_Jn[n_num][j]+1.0)*B_six_j_S_Dia_n[n_num-1][j][oldJn]*constant;
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]; a_old++) {
                                        a_new=position*(B_N_Start[n_num][n][j]+a_old);
                                        Si_Dia_old_B[j][a_new]+=factor;
                                }
                        }
                }

                //--New S_M_Dia-------------------------------------------------
                for(int j=0; j<B_N_Sys_Number_Jn[n_num]-1; j++)
                if((B_N_Sys_Value_Jn[n_num][j+1]-B_N_Sys_Value_Jn[n_num][j])==2) {
                        for(int n=0; n<para.S+1; n++)
                        for(int m=0; m<para.S+1; m++) {
                                if((oldJn=B_N_IndexOld[n_num][n][j])!=-1 && (oldJm=B_N_IndexOld[n_num][m][j+1])!=-1)
                                if(oldJn==oldJm) {
                                        position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][m][j+1]+B_N_Start[n_num][n][j];
                                        factor=pow(-1.0, (B_Sys_Value_Jn[n_num-1][oldJn]+B_N_Sys_Value_Jn[n_num][j]+2+para.S)/2)*sqrt((B_N_Sys_Value_Jn[n_num][j]+1.0)*(B_N_Sys_Value_Jn[n_num][j+1]+1.0))*B_six_j_S_M_Dia_n[n_num-1][j][oldJn]*constant;
                                        for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]; a_old++) {
                                                a_new=position+(B_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*a_old;
                                                Si_M_Dia_old_B[j][a_new]+=factor;
                                        }
                                }
                        }
                }
	}
}

//===============================================================================================================
//						    Initial_A_SiSj
//===============================================================================================================
inline void Sqspin::Initial_A_SiSj(const int &n_num, Parameter &para) {
	int oldJn, oldJm, SubDim, a_sysnew, a_sysnew_t;
	double position, factor;

//------Create space for SiSj_old--------------------------------------------------------------------------------
	SiSj_old_A=new double * [A_N_Sys_Number_Jn[n_num]];
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++) {
		SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i];
		SiSj_old_A[i]=new double [SubDim];
		for(int j=0; j<SubDim; j++)
			SiSj_old_A[i][j]=0.0;
	}

//------Initialize SiSj------------------------------------------------------------------------------------------
	for(int j=0; j<A_N_Sys_Number_Jn[n_num]; j++)
	for(int n=0; n<para.S+1; n++)
	for(int m=0; m<para.S+1; m++)
	if((oldJn=A_N_IndexOld[n_num][n][j])!=-1)
	if((oldJm=A_N_IndexOld[n_num][m][j])!=-1) {
		if(oldJn==oldJm && A_Sys_Value_Jn[n_num-1][oldJn]!=0) {
                	position=(A_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*A_N_Start[n_num][n][j];
                        factor=pow(-1.0,(A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJn]+para.S)/2)*constant*A_six_j_H[n_num-1][oldJn][oldJn][j];
			SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                        	a_sysnew=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                SiSj_old_A[j][a_sysnew]+=factor*Si_Dia_old_A[oldJn][a_sys];
                        }
                }

		else if((oldJn+1)==oldJm && (A_Sys_Value_Jn[n_num-1][oldJm]-A_Sys_Value_Jn[n_num-1][oldJn])==2) {
                	position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][m][j]+A_N_Start[n_num][n][j];
                        factor=pow(-1.0,(A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJm]+para.S)/2)*constant*A_six_j_H[n_num-1][oldJn][oldJm][j];
			SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn+1];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
				a_sysnew=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                a_sysnew_t=A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sysnew%A_N_Sys_SubBlockNumber_Jn[n_num][j])+a_sysnew/A_N_Sys_SubBlockNumber_Jn[n_num][j];
                                SiSj_old_A[j][a_sysnew]+=factor*Si_M_Dia_old_A[oldJn][a_sys];
                                SiSj_old_A[j][a_sysnew_t]+=factor*Si_M_Dia_old_A[oldJn][a_sys];
			}
		}
	}
}

//===============================================================================================================
//						Initialize B_SiSj operator
//===============================================================================================================
inline void Sqspin::Initial_B_SiSj(const int &n_num, Parameter &para) {
	int oldJn, oldJm, SubDim, a_sysnew, a_sysnew_t;
        double position, factor;

//------Create space for SiSj_old--------------------------------------------------------------------------------
        SiSj_old_B=new double * [B_N_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_B[i][j]=0.0;
        }

//------Initialize SiSj------------------------------------------------------------------------------------------
	for(int j=0; j<B_N_Sys_Number_Jn[n_num]; j++)
        for(int n=0; n<para.S+1; n++)
        for(int m=0; m<para.S+1; m++)
        if((oldJn=B_N_IndexOld[n_num][n][j])!=-1)
        if((oldJm=B_N_IndexOld[n_num][m][j])!=-1) {
                if(oldJn==oldJm && B_Sys_Value_Jn[n_num-1][oldJn]!=0) {
                        position=(B_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*B_N_Start[n_num][n][j];
                        factor=pow(-1.0,(B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJn]+para.S)/2)*constant*B_six_j_H[n_num-1][oldJn][oldJn][j];
                        SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                a_sysnew=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                SiSj_old_B[j][a_sysnew]+=factor*Si_Dia_old_B[oldJn][a_sys];
                        }
                }

                else if((oldJn+1)==oldJm && (B_Sys_Value_Jn[n_num-1][oldJm]-B_Sys_Value_Jn[n_num-1][oldJn])==2) {
                        position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][m][j]+B_N_Start[n_num][n][j];
                        factor=pow(-1.0,(B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJm]+para.S)/2)*constant*B_six_j_H[n_num-1][oldJn][oldJm][j];
                        SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn+1];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                a_sysnew=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
				a_sysnew_t=B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sysnew%B_N_Sys_SubBlockNumber_Jn[n_num][j])+a_sysnew/B_N_Sys_SubBlockNumber_Jn[n_num][j];
                                SiSj_old_B[j][a_sysnew]+=factor*Si_M_Dia_old_B[oldJn][a_sys];
                                SiSj_old_B[j][a_sysnew_t]+=factor*Si_M_Dia_old_B[oldJn][a_sys];
                        }
                }
        }
}

//===============================================================================================================
//						New A_SiSj
//===============================================================================================================
inline void Sqspin::New_A_SiSj(const int &n_num, Parameter &para) {
	int oldJn, position, SubDim, a_sysnew;

//------Create space for new SiSj--------------------------------------------------------------------------------
	SiSj_new_A=new double * [A_N_Sys_Number_Jn[n_num]];
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++) {
		SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_new_A[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_new_A[i][j]=0.0;
        }

//------New A_SiSj-----------------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++)
        for(int n=0; n<para.S+1; n++)
        if((oldJn=A_N_IndexOld[n_num][n][i])!=-1) {
                position=(A_N_Sys_SubBlockNumber_Jn[n_num][i]+1)*A_N_Start[n_num][n][i];
		SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                for(int a_sys=0; a_sys<SubDim; a_sys++) {
                        a_sysnew=position+A_N_Sys_SubBlockNumber_Jn[n_num][i]*(a_sys/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        SiSj_new_A[i][a_sysnew]+=SiSj_old_A[oldJn][a_sys];
                }
        }

//------Delete SiSj_old------------------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num-1]; i++)
		delete [] SiSj_old_A[i];
	delete [] SiSj_old_A;

//------Create new SiSj_old--------------------------------------------------------------------------------------
	SiSj_old_A=new double * [A_N_Sys_Number_Jn[n_num]];
        for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++) {
                SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_A[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_A[i][j]=SiSj_new_A[i][j];
        }

//------Delete SiSj_new------------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++)
		delete [] SiSj_new_A[i];
	delete [] SiSj_new_A;
}

//===============================================================================================================
//						New B_SiSj
//===============================================================================================================
inline void Sqspin::New_B_SiSj(const int &n_num, Parameter &para) {
        int oldJn, position, SubDim, a_sysnew;

//------Create space for new SiSj--------------------------------------------------------------------------------
        SiSj_new_B=new double * [B_N_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_new_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_new_B[i][j]=0.0;
        }

//------New B_SiSj-----------------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++)
        for(int n=0; n<para.S+1; n++)
        if((oldJn=B_N_IndexOld[n_num][n][i])!=-1) {
                position=(B_N_Sys_SubBlockNumber_Jn[n_num][i]+1)*B_N_Start[n_num][n][i];
                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                for(int a_sys=0; a_sys<SubDim; a_sys++) {
                        a_sysnew=position+B_N_Sys_SubBlockNumber_Jn[n_num][i]*(a_sys/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        SiSj_new_B[i][a_sysnew]+=SiSj_old_B[oldJn][a_sys];
                }
        }

//------Delete SiSj_old------------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num-1]; i++)
                delete [] SiSj_old_B[i];
        delete [] SiSj_old_B;

//------Create new SiSj_old--------------------------------------------------------------------------------------
        SiSj_old_B=new double * [B_N_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_B[i][j]=SiSj_new_B[i][j];
        }

//------Delete SiSj_new------------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++)
                delete [] SiSj_new_B[i];
        delete [] SiSj_new_B;
}

//===============================================================================================================
//						Truncate A_Si operators 
//===============================================================================================================
inline void Sqspin::Truncate_A_Si(const int &n_num) {

	char trans_N='N', trans_T='T';
	double alpha=1.0, beta=0.0;

//------Create space and define the operators of Si--------------------------------------------------------------
        Si_Dia_new_A=new double * [A_Sys_Number_Jn[n_num]];
        Si_M_Dia_new_A=new double * [A_Sys_Number_Jn[n_num]-1];

        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                int Dia_Dim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i];
                Si_Dia_new_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_new_A[i][j]=0.0;
        }

        for(int i=0; i<A_Sys_Number_Jn[n_num]-1; i++) {
                int Dia_Dim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i+1];
                Si_M_Dia_new_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_new_A[i][j]=0.0;
        }

//------Truncate S_Dia operator----------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {

		int SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]*A_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, Si_Dia_old_A[A_OldSub[n_num][i]], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &A_Sys_SubBlockNumber_Jn[n_num][i], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, Si_Dia_new_A[i], &A_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Truncate S_M_Dia operator--------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num]-1; i++)
	if((A_Sys_Value_Jn[n_num][i+1]-A_Sys_Value_Jn[n_num][i])==2 && (A_N_Sys_Value_Jn[n_num][A_OldSub[n_num][i+1]]-A_N_Sys_Value_Jn[n_num][A_OldSub[n_num][i]])==2) {
		int SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]*A_Sys_SubBlockNumber_Jn[n_num][i+1];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &A_Sys_SubBlockNumber_Jn[n_num][i+1], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i+1]], &alpha, Si_M_Dia_old_A[A_OldSub[n_num][i]], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], A[n_num][i+1], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i+1]], &beta, f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &A_Sys_SubBlockNumber_Jn[n_num][i], &A_Sys_SubBlockNumber_Jn[n_num][i+1], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, Si_M_Dia_new_A[i], &A_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Delete Si_old--------------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++)
                delete [] Si_Dia_old_A[i];
        delete [] Si_Dia_old_A;           
	
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]-1; i++)
		delete [] Si_M_Dia_old_A[i];
	delete [] Si_M_Dia_old_A;

//------Create new Si_old----------------------------------------------------------------------------------------
        Si_Dia_old_A=new double * [A_Sys_Number_Jn[n_num]];
        Si_M_Dia_old_A=new double * [A_Sys_Number_Jn[n_num]-1];

        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                int Dia_Dim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i];
                Si_Dia_old_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_old_A[i][j]=Si_Dia_new_A[i][j];
        }

        for(int i=0; i<A_Sys_Number_Jn[n_num]-1; i++) {
                int Dia_Dim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i+1];
                Si_M_Dia_old_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_old_A[i][j]=Si_M_Dia_new_A[i][j];
        }

//------Delete Si_new--------------------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) 
                delete [] Si_Dia_new_A[i]; 
        delete [] Si_Dia_new_A;           

	for(int i=0; i<A_Sys_Number_Jn[n_num]-1; i++)
		delete [] Si_M_Dia_new_A[i];
	delete [] Si_M_Dia_new_A;
}

//===============================================================================================================
//						Truncate B_Si operators
//===============================================================================================================
inline void Sqspin::Truncate_B_Si(const int &n_num) {
        char trans_N='N', trans_T='T';
        double alpha=1.0, beta=0.0;

//------Create space and define the operators of Si--------------------------------------------------------------
        Si_Dia_new_B=new double * [B_Sys_Number_Jn[n_num]];
        Si_M_Dia_new_B=new double * [B_Sys_Number_Jn[n_num]-1];

        for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                int Dia_Dim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i];
                Si_Dia_new_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_new_B[i][j]=0.0;
        }

        for(int i=0; i<B_Sys_Number_Jn[n_num]-1; i++) {
                int Dia_Dim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i+1];
                Si_M_Dia_new_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_new_B[i][j]=0.0;
        }

//------Truncate S_Dia operator----------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {

                int SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]*B_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, Si_Dia_old_B[B_OldSub[n_num][i]], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &B_Sys_SubBlockNumber_Jn[n_num][i], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, Si_Dia_new_B[i], &B_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Truncate S_M_Dia operator--------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]-1; i++)
        if((B_Sys_Value_Jn[n_num][i+1]-B_Sys_Value_Jn[n_num][i])==2 && (B_N_Sys_Value_Jn[n_num][B_OldSub[n_num][i+1]]-B_N_Sys_Value_Jn[n_num][B_OldSub[n_num][i]])==2) {
                int SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]*B_Sys_SubBlockNumber_Jn[n_num][i+1];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &B_Sys_SubBlockNumber_Jn[n_num][i+1], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i+1]], &alpha, Si_M_Dia_old_B[B_OldSub[n_num][i]], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], B[n_num][i+1], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i+1]], &beta, f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &B_Sys_SubBlockNumber_Jn[n_num][i], &B_Sys_SubBlockNumber_Jn[n_num][i+1], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, Si_M_Dia_new_B[i], &B_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Delete Si_old--------------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++)
                delete [] Si_Dia_old_B[i];
        delete [] Si_Dia_old_B;

        for(int i=0; i<B_N_Sys_Number_Jn[n_num]-1; i++)
                delete [] Si_M_Dia_old_B[i];
        delete [] Si_M_Dia_old_B;

//------Create new Si_old----------------------------------------------------------------------------------------
        Si_Dia_old_B=new double * [B_Sys_Number_Jn[n_num]];
        Si_M_Dia_old_B=new double * [B_Sys_Number_Jn[n_num]-1];

        for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                int Dia_Dim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i];
                Si_Dia_old_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_old_B[i][j]=Si_Dia_new_B[i][j];
        }

        for(int i=0; i<B_Sys_Number_Jn[n_num]-1; i++) {
                int Dia_Dim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i+1];
                Si_M_Dia_old_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_old_B[i][j]=Si_M_Dia_new_B[i][j];
        }

//------Delete Si_new--------------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]; i++)
                delete [] Si_Dia_new_B[i];
        delete [] Si_Dia_new_B;

        for(int i=0; i<B_Sys_Number_Jn[n_num]-1; i++)
                delete [] Si_M_Dia_new_B[i];
        delete [] Si_M_Dia_new_B;
}

//===============================================================================================================
//						Truncate A_SiSj operator
//===============================================================================================================
inline void Sqspin::Truncate_A_SiSj(const int &n_num) {
	int SubDim;
	char trans_N='N', trans_T='T';
	double alpha=1.0, beta=0.0;

//------Create space for A_SiSj_new------------------------------------------------------------------------------
	SiSj_new_A=new double * [A_Sys_Number_Jn[n_num]];
        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                SubDim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_new_A[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_new_A[i][j]=0.0;
        }

//------Truncate SiSj_old----------------------------------------------------------------------------------------
        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]*A_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, SiSj_old_A[A_OldSub[n_num][i]], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &A_Sys_SubBlockNumber_Jn[n_num][i], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, SiSj_new_A[i], &A_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Delete old SiSj_old--------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++)
		delete [] SiSj_old_A[i];
	delete [] SiSj_old_A;

//------Create new SiSj_old--------------------------------------------------------------------------------------
	SiSj_old_A=new double * [A_Sys_Number_Jn[n_num]];
        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                SubDim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_A[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_A[i][j]=SiSj_new_A[i][j];
        }

//------Delete SiSj_new------------------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num]; i++)
                delete [] SiSj_new_A[i];
        delete [] SiSj_new_A;
}

//===============================================================================================================
//						Truncate B_SiSj operator
//===============================================================================================================
inline void Sqspin::Truncate_B_SiSj(const int &n_num) {
        int SubDim;
        char trans_N='N', trans_T='T';
        double alpha=1.0, beta=0.0;

//------Create space for B_SiSj_new------------------------------------------------------------------------------
        SiSj_new_B=new double * [B_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_new_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_new_B[i][j]=0.0;
        }

//------Truncate SiSj_old----------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]*B_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, SiSj_old_B[B_OldSub[n_num][i]], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &B_Sys_SubBlockNumber_Jn[n_num][i], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, SiSj_new_B[i], &B_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Delete old SiSj_old--------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++)
                delete [] SiSj_old_B[i];
        delete [] SiSj_old_B;

//------Create new SiSj_old--------------------------------------------------------------------------------------
        SiSj_old_B=new double * [B_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_B[i][j]=SiSj_new_B[i][j];
        }

//------Delete SiSj_new------------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]; i++)
                delete [] SiSj_new_B[i];
        delete [] SiSj_new_B;
}

//===============================================================================================================
//					Print Correlation function
//===============================================================================================================
inline void Sqspin::Print(Parameter &para) {
        FILE *f=fopen(Combine("spin_correlation/", 1), "a+");
        for(int j=0; j<para.N*para.N; j++) {
                fprintf(f, "%d\t", j);
                fprintf(f, "%f\n", correlation_function[j]);
        }
        fclose(f);

        FILE *g=fopen(Combine("spin_correlation/", 2), "a+");
        for(int i=0; i<para.N; i++)
        for(int j=0; j<para.N; j++) {
                fprintf(g, "%d\t", i);
                fprintf(g, "%d\t", j);
                fprintf(g, "%f\n", correlation_function[i*para.N+j]);
        }
        fclose(g);
}

//===============================================================================================================
//						Delete WaveFunctions
//===============================================================================================================
inline void Sqspin::DeleteFunction(Super &sup) {
        for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++)
                delete [] WaveFunction_block[i];
        delete [] WaveFunction_block;

	for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++)
		delete [] WaveFunction_config_2[i];
	delete [] WaveFunction_config_2;

	for(int i=0; i<sup.BlockNumber_for_TargetSpin_config_3; i++)
		delete [] WaveFunction_config_3[i];
	delete [] WaveFunction_config_3;
}

//===============================================================================================================
//					Delete the created space
//===============================================================================================================
inline void Sqspin::DeleteSpace(const int &lsys, Parameter &para) {
	int A_site=lsys;
	int B_site=para.N-lsys-2;

//------Delete A_6j coefficients---------------------------------------------------------------------------------
   //---A_six_j_S_Dia_old----------------------------------------------------------------------------------------
	for(int i=0; i<A_site-1; i++) {
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			for(int k=0; k<A_Sys_Number_Jn[i]; k++) {
				delete [] A_six_j_S_Dia_old[i][j][k];
			}
			delete [] A_six_j_S_Dia_old[i][j];
		}
		delete [] A_six_j_S_Dia_old[i];
	}
	delete [] A_six_j_S_Dia_old;

   //---A_six_j_S_Dia_n------------------------------------------------------------------------------------------
	for(int i=0; i<A_site-1; i++) {
		for(int j=0; j<A_N_Sys_Number_Jn[i+1]; j++) {
			delete [] A_six_j_S_Dia_n[i][j];
		}
		delete [] A_six_j_S_Dia_n[i];
	}
	delete [] A_six_j_S_Dia_n;

   //---A_six_j_S_M_Dia_old--------------------------------------------------------------------------------------
   	for(int i=0; i<A_site-1; i++) {
                for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
                        for(int k=0; k<A_Sys_Number_Jn[i]; k++) {
                                delete [] A_six_j_S_M_Dia_old[i][j][k];
                        }
                        delete [] A_six_j_S_M_Dia_old[i][j];
                }
                delete [] A_six_j_S_M_Dia_old[i];
        }
        delete [] A_six_j_S_M_Dia_old;
  
   //---A_six_j_S_M_Dia_n----------------------------------------------------------------------------------------
	for(int i=0; i<A_site-1; i++) {
                for(int j=0; j<A_N_Sys_Number_Jn[i+1]-1; j++) {
                        delete [] A_six_j_S_M_Dia_n[i][j];
                }
                delete [] A_six_j_S_M_Dia_n[i];
        }
        delete [] A_six_j_S_M_Dia_n;

   //---A_six_j_H------------------------------------------------------------------------------------------------
   	for(int i=0; i<A_site-1; i++) {
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			for(int k=0; k<A_Sys_Number_Jn[i]; k++) {
				delete [] A_six_j_H[i][j][k];
			}
			delete [] A_six_j_H[i][j];
		}
		delete [] A_six_j_H[i];
	}
	delete [] A_six_j_H;

//------Delete B_6j coefficients---------------------------------------------------------------------------------
   //---B_six_j_S_Dia_old----------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
        	for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                	for(int k=0; k<B_Sys_Number_Jn[i]; k++) {
                        	delete [] B_six_j_S_Dia_old[i][j][k];
                        }
                        delete [] B_six_j_S_Dia_old[i][j];
                }
                delete [] B_six_j_S_Dia_old[i];
        }
        delete [] B_six_j_S_Dia_old;

   //---B_six_j_S_Dia_n------------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]; j++) {
                        delete [] B_six_j_S_Dia_n[i][j];
                }
                delete [] B_six_j_S_Dia_n[i];
        }
        delete [] B_six_j_S_Dia_n;

   //---B_six_j_S_M_Dia_old--------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++) {
                                delete [] B_six_j_S_M_Dia_old[i][j][k];
                        }
                        delete [] B_six_j_S_M_Dia_old[i][j];
                }
                delete [] B_six_j_S_M_Dia_old[i];
        }
        delete [] B_six_j_S_M_Dia_old;

   //---B_six_j_S_M_Dia_n----------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]-1; j++) {
                        delete [] B_six_j_S_M_Dia_n[i][j];
                }
                delete [] B_six_j_S_M_Dia_n[i];
        }
        delete [] B_six_j_S_M_Dia_n;

   //---B_six_j_H------------------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++) {
                                delete [] B_six_j_H[i][j][k];
                        }
                        delete [] B_six_j_H[i][j];
                }
                delete [] B_six_j_H[i];
        }
        delete [] B_six_j_H;

//------Delete A_N-matrices--------------------------------------------------------------------------------------
	for(int i=0; i<A_site; i++) {
		for(int j=0; j<para.S+1; j++) {
			delete [] A_N_IndexOld[i][j];	delete [] A_N_Start[i][j];
		}
		delete [] A_N_IndexOld[i];	delete [] A_N_Start[i];
	}
	delete [] A_N_IndexOld;			delete [] A_N_Start;

	for(int i=0; i<A_site; i++) {
		delete [] A_N_Sys_Value_Jn[i];		delete [] A_N_Sys_SubBlockNumber_Jn[i];
	}
	delete [] A_N_Sys_Value_Jn;			delete [] A_N_Sys_SubBlockNumber_Jn;

	delete [] A_N_Sys_Number_Jn;

//------Delete B_N-matrices--------------------------------------------------------------------------------------
        for(int i=0; i<B_site; i++) {
                for(int j=0; j<para.S+1; j++) {
                        delete [] B_N_IndexOld[i][j];   delete [] B_N_Start[i][j];
                }
                delete [] B_N_IndexOld[i];      delete [] B_N_Start[i];
        }
        delete [] B_N_IndexOld;                 delete [] B_N_Start;

        for(int i=0; i<B_site; i++) {
                delete [] B_N_Sys_Value_Jn[i];          delete [] B_N_Sys_SubBlockNumber_Jn[i];
        }
        delete [] B_N_Sys_Value_Jn;                     delete [] B_N_Sys_SubBlockNumber_Jn;

        delete [] B_N_Sys_Number_Jn;

//------Delete A-matrices----------------------------------------------------------------------------------------
	for(int i=0; i<A_site; i++) {
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			delete [] A[i][j];
		}
		delete [] A[i];
	}
	delete [] A;
	
	for(int i=0; i<A_site; i++) {
		delete [] A_Sys_Value_Jn[i];		delete [] A_Sys_SubBlockNumber_Jn[i];
		delete [] A_density_dim[i];		delete [] A_OldSub[i];
	}
	delete [] A_Sys_Value_Jn;			delete [] A_Sys_SubBlockNumber_Jn;	
	delete [] A_density_dim;			delete [] A_OldSub;

	delete [] A_Sys_Number_Jn;
//---------------------------------------------------------------------------------------------------------------

//------Delete B-matrices----------------------------------------------------------------------------------------
	for(int i=0; i<B_site; i++) {
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        delete [] B[i][j];
                }
                delete [] B[i];
        }
        delete [] B;

        for(int i=0; i<B_site; i++) {
                delete [] B_Sys_Value_Jn[i];		delete [] B_Sys_SubBlockNumber_Jn[i];
                delete [] B_density_dim[i];		delete [] B_OldSub[i];
        }
        delete [] B_Sys_Value_Jn;       		delete [] B_Sys_SubBlockNumber_Jn;      
	delete [] B_density_dim;			delete [] B_OldSub;

        delete [] B_Sys_Number_Jn;
}

//===============================================================================================================
Sqspin::~Sqspin() {}

//==================================================END==========================================================
