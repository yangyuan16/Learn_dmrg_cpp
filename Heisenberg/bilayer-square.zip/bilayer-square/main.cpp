//================================================================================================================
#include"omp.h"
#include"mkl.h"
#include<iostream>
#include<time.h>
#include<stdio.h>
#include<sys/stat.h>
using namespace std;

#include"parameter.h"
#include"sweep.h"
//---------------------------------------------------------------------------------------------------------------
int main() {
//-------------------------------------Program start and set the clock-------------------------------------------
  //1. Start the program
	FILE *LOG_start=fopen("LOG", "a+");
        fprintf(LOG_start, "Begin the DMRG program for spin-1/2 Kagome lattice with SU(2) symmetry.");
        fprintf(LOG_start, "\n\n");
        fclose(LOG_start);
  //2. Start the time clock
	time_t start, end;
	time (&start);

	int thread=10;
	omp_set_num_threads(thread);
        int Max_Num=100; //Sweep number
	char Sign='N';

//-----------------------------Initialize the model and DMRG parameters------------------------------------------
  //1. Model Parameters
      //1.1	Spin magnitude 
	int S=1;                //S=2*spin_magnitude, S=1 for spin-1/2, S=2 for spin-1
      //1.2	DMRG Parameters 
	int Total_j=0;		//Target the quantum number of J operator for diagonalization, multiply 2	
	int StateNoKept=1000;	//The number of the kept optimal states

      //1.3  Lattice geometry and size
	int N_u=2;              //The number of spin sites in a unit cell.
	int N_x=8;		//The number of unit cell along the x-direction	
	int N_y=3;		//The number of unit cell along the y-directio
	int N=N_u*N_x*N_y;	//The total number of spin sites N=(N_x*N_y*n_u)
	char Geometry='S';	//Define the geometry of the 2D spin lattices

      //1.4 Spin Interaction
	double J_n=1.0;
	double J_nn=0.0;
	double J_nnn=0.0;

	mkdir("./e", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./entanglement", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./entanglement/spectrum", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./entanglement/entropy", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./spin_correlation", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./wavefunction", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	mkdir("./mid", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	mkdir("./mid/space", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	mkdir("./mid/operator", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./6j_factor", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./6j_factor/S_Dia_old", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./6j_factor/S_Dia_n", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./6j_factor/S_M_Dia_old", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./6j_factor/S_M_Dia_n", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        mkdir("./6j_factor/H", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	mkdir("./new_block", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	mkdir("./truncated_wave_function", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	mkdir("./truncated_density_eigenvector", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);

//------------------------------------Transmit the parameters to class Parameter---------------------------------
	Parameter para(Sign, Max_Num, S, Total_j, StateNoKept, N_u, N_x, N_y, N, Geometry, J_n, J_nn, J_nnn);
	Sweep sweep(para);

//------------------------------------------------Program End----------------------------------------------------
	time (&end);
	FILE *LOG_end=fopen("LOG", "a+");
        fprintf(LOG_end, "Total time of the Program is %f\n", difftime(end, start));
        fclose(LOG_end);
	cout<<"\n Time="<<difftime(end, start);
}
//===================================================END=========================================================
