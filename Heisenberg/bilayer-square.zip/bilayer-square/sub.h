#include"parameter.h"
#include"subcommon.h"
//=======================================Class Sub, including Class SubCommon=====================================
//	This class performs the calculations of the Hamiltonian operators in the process of initialization,
//	size-increase and truncation.
//================================================================================================================
class Sub:public SubCommon {
public:
	Sub(Parameter &para);		//Initialize blocks
	Sub(char *space, const int &i, const int &lsys);//Read in angular space from hard disk
	Sub(const int &i, const int &lsys);		//Read in operators from hard disk

	Sub(const int &i, Parameter &para, Sub &old);	//New space for both sys and env

	Sub(Sub &new_space);	//Create Space 3 

	Sub(char &sign, Parameter &para, Sub &sys, Sub &sysnew_space);//Sys increase for Infinite and Finite sweep 
	Sub(char &sign, Sub &envnew_space, Sub &env, Parameter &para);//Environment increase for Infinite sweep

	Sub(char &sign, char &f, Parameter &para, Sub &env, Sub &envnew_space);//Environment increase for Finite sweep (right to left)! In this case, the "Start Site (==the last site of lattice)" of the environment block is invariant for all the steps.

	Sub(Parameter &para, char *nooperator, Sub &old);//For the shrinking blocks in the finite sweep with only creating the new Hilbert space for diagonalization, but not to create the new operators.

	Sub(Parameter &para, Sub &density);	//Create space for truncation space in infinite sweep
	Sub(Parameter &para, char &sign, Sub &density, Sub &trun_space, Sub &old); //truncate operators

	Sub(Parameter &para, Sub &density, const int &optimalstate);//space,truncation, finite sweep

	~Sub();				//Delete the sub functions

private:
	int StartSite, mmin, SubDim;
	char trans_N, trans_T;
	double alpha, beta;

        inline void GetSysNumberJn(Parameter &para, Sub &old);
	inline void FindDim(Parameter &para, Sub &old);
	inline void Find_Stored_Site(Parameter &para, Sub &env);

	double ***six_j_H;
	inline void Create_6j_H(Parameter &para, Sub &sys);
	inline void Delete_6j_H(Sub &sys);

	inline void NewH_Sys(Parameter &para, Sub &sysnew_space, Sub &sys);
	inline void NewH_Env(Parameter &para, Sub &envnew_space, Sub &env);
	inline void NewS_Dia(const int &block, Parameter &para, Sub &space, Sub &old, int *table_old, int *table_new);
	inline void NewS_M_Dia(const int &block, Parameter &para, Sub &space, Sub &old, int *table_old, int *table_new);
	
	inline void Truncate(Parameter &para, Sub &old, const int &optimalstate);
	inline void NewH(Sub &density, Sub &old);
        inline void NewS_Dia(Sub &density, Sub &old);
        inline void NewS_M_Dia(Sub &density, Sub &old);
};
