#include<iostream>
using namespace std;
#include<math.h>
#include<time.h>
#include<assert.h>
#include<stdlib.h>
#include<stdio.h>
#include<gsl/gsl_sf_coupling.h>

#include"common.h"
#include"sub.h"
#include"super.h"
#include"chiralcorrelation.h"

#define constant sqrt(6.0)*0.5		//spin-1/2
//#define constant sqrt(6.0)              //spin-1
//===============================================================================================================
//						BLAS ROUTINES
//===============================================================================================================
extern "C" {
void daxpy_(const int *n, const double *alpha, double *x, const int *incx, double *y, const int *incy);

void dsymm_(char *side, char *uplo, const int *m, const int *n, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);

void dgemm_(char *transa, char *transb, const int *m, const int *n, const int *k, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);
}
//===============================================================================================================

//===============================================================================================================
//				Calculating the spin-spin correlation functions
//===============================================================================================================
ChiralCorrelation::ChiralCorrelation(const int &lsys, Parameter &para, Super &sup) {
//------Define variables-----------------------------------------------------------------------------------------
	trans_N='N';	trans_T='T';
	side_R='R';	side_L='L';
	uplo='U';

//------Create space for transformation matrices A and B, as well as other variables-----------------------------
	CreateSpace(lsys, para);	//matrices A, B and angular coupling coefficients
	CreateFunction(sup);		//The function in which the physical quantities averages are calculated

//------Calculate the chiral-chiral correlation functions------------------------------------------------------------
	Correlation_sys_env_memory(lsys, para, sup);	//for the case to save memory

//------Delete matrices A and B----------------------------------------------------------------------------------
	DeleteFunction(sup);
	DeleteSpace(lsys, para);
}

//===============================================================================================================
//===============================================================================================================
//===============================================================================================================
//					     Create Space for variables
//===============================================================================================================
inline void ChiralCorrelation::CreateSpace(const int &lsys, Parameter &para) {

	int A_site=lsys;
	int B_site=para.N-lsys-2;

//------Create space for A_N-matrices----------------------------------------------------------------------------
	A_N_Sys_Number_Jn=new int [A_site];
	A_N_Sys_Value_Jn=new int * [A_site];
	A_N_Sys_SubBlockNumber_Jn=new int * [A_site];
	A_N_IndexOld=new int ** [A_site];
	A_N_Start=new int ** [A_site];

  //----The first site-----------------------------------------------
	A_N_Sys_Number_Jn[0]=1;

	A_N_Sys_Value_Jn[0]=new int [1];
	A_N_Sys_Value_Jn[0][0]=para.S;	//para.S

	A_N_Sys_SubBlockNumber_Jn[0]=new int [1];
	A_N_Sys_SubBlockNumber_Jn[0][0]=1;

	A_N_IndexOld[0]=new int * [para.S+1];	//
	A_N_Start[0]=new int * [para.S+1];	//
	for(int i=0; i<para.S+1; i++) {		//
		A_N_IndexOld[0][i]=new int [1];
		A_N_Start[0][i]=new int [1];
		for(int j=0; j<1; j++) {
			A_N_IndexOld[0][i][j]=0;
			A_N_Start[0][i][j]=0;
		}
	}

  //----Read other sites from disk------------------------------------
	for(int i=1; i<A_site; i++) {

		FILE *fr=fopen(Combine(Combine("new_block/", 1), i+1), "rb");	//"i"=1 stand for sys

		fread(&A_N_Sys_Number_Jn[i], sizeof(int), 1, fr);

		A_N_Sys_Value_Jn[i]=new int [A_N_Sys_Number_Jn[i]];
		A_N_Sys_SubBlockNumber_Jn[i]=new int [A_N_Sys_Number_Jn[i]];

		fread(A_N_Sys_Value_Jn[i], sizeof(int), A_N_Sys_Number_Jn[i], fr);
		fread(A_N_Sys_SubBlockNumber_Jn[i], sizeof(int), A_N_Sys_Number_Jn[i], fr);

		A_N_IndexOld[i]=new int * [para.S+1];
		A_N_Start[i]=new int * [para.S+1];
		for(int j=0; j<para.S+1; j++) {
			A_N_IndexOld[i][j]=new int [A_N_Sys_Number_Jn[i]];
			A_N_Start[i][j]=new int [A_N_Sys_Number_Jn[i]];
		}

		for(int j=0; j<para.S+1; j++) {
			fread(A_N_IndexOld[i][j], sizeof(int), A_N_Sys_Number_Jn[i], fr);
			fread(A_N_Start[i][j], sizeof(int), A_N_Sys_Number_Jn[i], fr);
		}

		fclose(fr);

	}

//------Create space for B_N-matrices----------------------------------------------------------------------------
	B_N_Sys_Number_Jn=new int [B_site];
	B_N_Sys_Value_Jn=new int * [B_site];
	B_N_Sys_SubBlockNumber_Jn=new int * [B_site];
	B_N_IndexOld=new int ** [B_site];
	B_N_Start=new int ** [B_site];

  //----The first site--------------------------------------------
	B_N_Sys_Number_Jn[0]=1;

        B_N_Sys_Value_Jn[0]=new int [1];
        B_N_Sys_Value_Jn[0][0]=para.S;	//

        B_N_Sys_SubBlockNumber_Jn[0]=new int [1];
        B_N_Sys_SubBlockNumber_Jn[0][0]=1;

        B_N_IndexOld[0]=new int * [para.S+1];	//
        B_N_Start[0]=new int * [para.S+1];	//
        for(int i=0; i<para.S+1; i++) {		//
                B_N_IndexOld[0][i]=new int [1];
                B_N_Start[0][i]=new int [1];
                for(int j=0; j<1; j++) {
                        B_N_IndexOld[0][i][j]=0;
                        B_N_Start[0][i][j]=0;
                }
        }

  //----Read other sites from disk---------------------------------
        for(int i=1; i<B_site; i++) {
                FILE *fr=fopen(Combine(Combine("new_block/", 2), i+1), "rb");//"i"=2 stand for env

                fread(&B_N_Sys_Number_Jn[i], sizeof(int), 1, fr);

                B_N_Sys_Value_Jn[i]=new int [B_N_Sys_Number_Jn[i]];
                B_N_Sys_SubBlockNumber_Jn[i]=new int [B_N_Sys_Number_Jn[i]];

                fread(B_N_Sys_Value_Jn[i], sizeof(int), B_N_Sys_Number_Jn[i], fr);
                fread(B_N_Sys_SubBlockNumber_Jn[i], sizeof(int), B_N_Sys_Number_Jn[i], fr);

                B_N_IndexOld[i]=new int * [para.S+1];	//
                B_N_Start[i]=new int * [para.S+1];	//
                for(int j=0; j<para.S+1; j++) {		//
                        B_N_IndexOld[i][j]=new int [B_N_Sys_Number_Jn[i]];
                        B_N_Start[i][j]=new int [B_N_Sys_Number_Jn[i]];
                }

		for(int j=0; j<para.S+1; j++) {
                        fread(B_N_IndexOld[i][j], sizeof(int), B_N_Sys_Number_Jn[i], fr);
                        fread(B_N_Start[i][j], sizeof(int), B_N_Sys_Number_Jn[i], fr);
                }

                fclose(fr);
        }

//------Create space for A-matrices------------------------------------------------------------------------------
	A_Sys_Number_Jn=new int [A_site];
	A_Sys_Value_Jn=new int * [A_site];
	A_Sys_SubBlockNumber_Jn=new int * [A_site];
	A_density_dim=new int * [A_site];
	A_OldSub=new int * [A_site];

	A=new double ** [A_site];

  //----The first site----------------------------------------------
  	A_Sys_Number_Jn[0]=1;

	A_Sys_Value_Jn[0]=new int [1];
	A_Sys_Value_Jn[0][0]=para.S;

	A_Sys_SubBlockNumber_Jn[0]=new int [1];
	A_Sys_SubBlockNumber_Jn[0][0]=1;
	
	A_density_dim[0]=new int [1];
	A_density_dim[0][0]=1;

	A_OldSub[0]=new int [1];
	A_OldSub[0][0]=0;
	
	A[0]=new double * [1];
	A[0][0]=new double [1];
	A[0][0][0]=1.0;

  //----Read other sites from disk----------------------------------
	for(int i=1; i<A_site; i++) {

		FILE *fp=fopen(Combine(Combine("truncated_density_eigenvector/", 1), i+1), "rb");

		fread(&A_Sys_Number_Jn[i], sizeof(int), 1, fp);
	
		A_Sys_Value_Jn[i]=new int [A_Sys_Number_Jn[i]];
		A_Sys_SubBlockNumber_Jn[i]=new int [A_Sys_Number_Jn[i]];
		A_density_dim[i]=new int [A_Sys_Number_Jn[i]];
		A_OldSub[i]=new int [A_Sys_Number_Jn[i]];

		fread(A_Sys_Value_Jn[i], sizeof(int), A_Sys_Number_Jn[i], fp);
		fread(A_Sys_SubBlockNumber_Jn[i], sizeof(int), A_Sys_Number_Jn[i], fp);
		fread(A_density_dim[i], sizeof(int), A_Sys_Number_Jn[i], fp);

		A[i]=new double * [A_Sys_Number_Jn[i]];
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) 
			A[i][j]=new double [A_density_dim[i][j]];

		for(int j=0; j<A_Sys_Number_Jn[i]; j++)
			fread(A[i][j], sizeof(double), A_density_dim[i][j], fp);

		fread(A_OldSub[i], sizeof(int), A_Sys_Number_Jn[i], fp);

		fclose(fp);
	}

//------Create space for B-matrices------------------------------------------------------------------------------
	B_Sys_Number_Jn=new int [B_site];
	B_Sys_Value_Jn=new int * [B_site];
	B_Sys_SubBlockNumber_Jn=new int * [B_site];
	B_density_dim=new int * [B_site];
	B_OldSub=new int * [B_site];

	B=new double ** [B_site];

  //----The first site------------------------------------------------
	B_Sys_Number_Jn[0]=1;

        B_Sys_Value_Jn[0]=new int [1];
        B_Sys_Value_Jn[0][0]=para.S;

        B_Sys_SubBlockNumber_Jn[0]=new int [1];
        B_Sys_SubBlockNumber_Jn[0][0]=1;

        B_density_dim[0]=new int [1];
        B_density_dim[0][0]=1;

	B_OldSub[0]=new int [1];
	B_OldSub[0][0]=0;

        B[0]=new double * [1];
        B[0][0]=new double [1];
	B[0][0][0]=1.0;

  //----Read other sites from disk-------------------------------------
	for(int i=1; i<B_site; i++) {

		FILE *fp=fopen(Combine(Combine("truncated_density_eigenvector/", 2), i+1), "rb");

		fread(&B_Sys_Number_Jn[i], sizeof(int), 1, fp);

		B_Sys_Value_Jn[i]=new int [B_Sys_Number_Jn[i]];
		B_Sys_SubBlockNumber_Jn[i]=new int [B_Sys_Number_Jn[i]];
		B_density_dim[i]=new int [B_Sys_Number_Jn[i]];
		B_OldSub[i]=new int [B_Sys_Number_Jn[i]];

		fread(B_Sys_Value_Jn[i], sizeof(int), B_Sys_Number_Jn[i], fp);
		fread(B_Sys_SubBlockNumber_Jn[i], sizeof(int), B_Sys_Number_Jn[i], fp);
		fread(B_density_dim[i], sizeof(int), B_Sys_Number_Jn[i], fp);

                B[i]=new double * [B_Sys_Number_Jn[i]];
                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                        B[i][j]=new double [B_density_dim[i][j]];

                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                        fread(B[i][j], sizeof(double), B_density_dim[i][j], fp);


		fread(B_OldSub[i], sizeof(int), B_Sys_Number_Jn[i], fp);

                fclose(fp);
        }

//------6j coefficients for A-blocks----------------------------------------------------------------------------- 
   //---A_six_j_S_Dia_old----------------------------------------------------------------------------------------
	A_six_j_S_Dia_old=new double *** [lsys-1];
        for(int i=0; i<lsys-1; i++) {
                A_six_j_S_Dia_old[i]=new double ** [A_Sys_Number_Jn[i]];
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			A_six_j_S_Dia_old[i][j]=new double * [A_Sys_Number_Jn[i]];
			for(int k=0; k<A_Sys_Number_Jn[i]; k++) 
				A_six_j_S_Dia_old[i][j][k]=new double [A_N_Sys_Number_Jn[i+1]];
		}

		FILE *fp=fopen(Combine(Combine("6j_factor/S_Dia_old/", 1), i+2), "rb");
		for(int j=0; j<A_Sys_Number_Jn[i]; j++)
		for(int k=0; k<A_Sys_Number_Jn[i]; k++)
			fread(A_six_j_S_Dia_old[i][j][k], sizeof(double), A_N_Sys_Number_Jn[i+1], fp);
               	fclose(fp);
        }


   //---A_six_j_S_Dia_n------------------------------------------------------------------------------------------
	A_six_j_S_Dia_n=new double ** [lsys-1];
	for(int i=0; i<lsys-1; i++) {
		A_six_j_S_Dia_n[i]=new double * [A_N_Sys_Number_Jn[i+1]];
		for(int j=0; j<A_N_Sys_Number_Jn[i+1]; j++) {
			A_six_j_S_Dia_n[i][j]=new double [A_Sys_Number_Jn[i]];
		}

		FILE *fa=fopen(Combine(Combine("6j_factor/S_Dia_n/", 1), i+2), "rb");
                for(int j=0; j<A_N_Sys_Number_Jn[i+1]; j++)
                        fread(A_six_j_S_Dia_n[i][j], sizeof(double), A_Sys_Number_Jn[i], fa);
                fclose(fa);
	}

   //---A_six_j_S_M_Dia_old--------------------------------------------------------------------------------------
	A_six_j_S_M_Dia_old=new double *** [lsys-1];
        for(int i=0; i<lsys-1; i++) {
                A_six_j_S_M_Dia_old[i]=new double ** [A_Sys_Number_Jn[i]];
                for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
                        A_six_j_S_M_Dia_old[i][j]=new double * [A_Sys_Number_Jn[i]];
                        for(int k=0; k<A_Sys_Number_Jn[i]; k++)
                                A_six_j_S_M_Dia_old[i][j][k]=new double [A_N_Sys_Number_Jn[i+1]-1];
                }

                FILE *fp=fopen(Combine(Combine("6j_factor/S_M_Dia_old/", 1), i+2), "rb");
                for(int j=0; j<A_Sys_Number_Jn[i]; j++)
                for(int k=0; k<A_Sys_Number_Jn[i]; k++)
                        fread(A_six_j_S_M_Dia_old[i][j][k], sizeof(double), A_N_Sys_Number_Jn[i+1]-1, fp);
                fclose(fp);
        }

   //---A_six_j_S_M_Dia_n----------------------------------------------------------------------------------------
	A_six_j_S_M_Dia_n=new double ** [lsys-1];
        for(int i=0; i<lsys-1; i++) {
                A_six_j_S_M_Dia_n[i]=new double * [A_N_Sys_Number_Jn[i+1]-1];
                for(int j=0; j<A_N_Sys_Number_Jn[i+1]-1; j++) {
                        A_six_j_S_M_Dia_n[i][j]=new double [A_Sys_Number_Jn[i]];
                }

                FILE *fa=fopen(Combine(Combine("6j_factor/S_M_Dia_n/", 1), i+2), "rb");
                for(int j=0; j<A_N_Sys_Number_Jn[i+1]-1; j++)
                        fread(A_six_j_S_M_Dia_n[i][j], sizeof(double), A_Sys_Number_Jn[i], fa);
                fclose(fa);
        }

   //---A_six_j_H------------------------------------------------------------------------------------------------
   	A_six_j_H=new double *** [lsys-1];
	for(int i=0; i<lsys-1; i++) {
		A_six_j_H[i]=new double ** [A_Sys_Number_Jn[i]];
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			A_six_j_H[i][j]=new double * [A_Sys_Number_Jn[i]];
			for(int k=0; k<A_Sys_Number_Jn[i]; k++)
				A_six_j_H[i][j][k]=new double [A_N_Sys_Number_Jn[i+1]];
		}

		FILE *fi=fopen(Combine(Combine("6j_factor/H/", 1), i+2), "rb");
		for(int j=0; j<A_Sys_Number_Jn[i]; j++)
		for(int k=0; k<A_Sys_Number_Jn[i]; k++)
			fread(A_six_j_H[i][j][k], sizeof(double), A_N_Sys_Number_Jn[i+1], fi);
		fclose(fi);
	}

//------6j coefficients for B-block------------------------------------------------------------------------------
   //---B_six_j_S_Dia_old----------------------------------------------------------------------------------------
	B_six_j_S_Dia_old=new double *** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_S_Dia_old[i]=new double ** [B_Sys_Number_Jn[i]];
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        B_six_j_S_Dia_old[i][j]=new double * [B_Sys_Number_Jn[i]];
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                                B_six_j_S_Dia_old[i][j][k]=new double [B_N_Sys_Number_Jn[i+1]];
                }

                FILE *fp=fopen(Combine(Combine("6j_factor/S_Dia_old/", 2), i+2), "rb");
                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                        fread(B_six_j_S_Dia_old[i][j][k], sizeof(double), B_N_Sys_Number_Jn[i+1], fp);
                fclose(fp);
        }

   //---B_six_j_S_Dia_n------------------------------------------------------------------------------------------
	B_six_j_S_Dia_n=new double ** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_S_Dia_n[i]=new double * [B_N_Sys_Number_Jn[i+1]];
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]; j++) {
                        B_six_j_S_Dia_n[i][j]=new double [B_Sys_Number_Jn[i]];
                }

                FILE *fa=fopen(Combine(Combine("6j_factor/S_Dia_n/", 2), i+2), "rb");
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]; j++)
                        fread(B_six_j_S_Dia_n[i][j], sizeof(double), B_Sys_Number_Jn[i], fa);
                fclose(fa);
        }

   //---B_six_j_S_M_Dia_old--------------------------------------------------------------------------------------
	B_six_j_S_M_Dia_old=new double *** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_S_M_Dia_old[i]=new double ** [B_Sys_Number_Jn[i]];
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        B_six_j_S_M_Dia_old[i][j]=new double * [B_Sys_Number_Jn[i]];
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                                B_six_j_S_M_Dia_old[i][j][k]=new double [B_N_Sys_Number_Jn[i+1]-1];
                }

                FILE *fp=fopen(Combine(Combine("6j_factor/S_M_Dia_old/", 2), i+2), "rb");
                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                        fread(B_six_j_S_M_Dia_old[i][j][k], sizeof(double), B_N_Sys_Number_Jn[i+1]-1, fp);
                fclose(fp);
        }

   //---B_six_j_S_M_Dia_n----------------------------------------------------------------------------------------
	B_six_j_S_M_Dia_n=new double ** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_S_M_Dia_n[i]=new double * [B_N_Sys_Number_Jn[i+1]-1];
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]-1; j++) {
                        B_six_j_S_M_Dia_n[i][j]=new double [B_Sys_Number_Jn[i]];
                }

                FILE *fa=fopen(Combine(Combine("6j_factor/S_M_Dia_n/", 2), i+2), "rb");
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]-1; j++)
                        fread(B_six_j_S_M_Dia_n[i][j], sizeof(double), B_Sys_Number_Jn[i], fa);
                fclose(fa);
        }

   //---B_six_j_H------------------------------------------------------------------------------------------------
	B_six_j_H=new double *** [B_site-1];
        for(int i=0; i<B_site-1; i++) {
                B_six_j_H[i]=new double ** [B_Sys_Number_Jn[i]];
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        B_six_j_H[i][j]=new double * [B_Sys_Number_Jn[i]];
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                                B_six_j_H[i][j][k]=new double [B_N_Sys_Number_Jn[i+1]];
                }

                FILE *fi=fopen(Combine(Combine("6j_factor/H/", 2), i+2), "rb");
                for(int j=0; j<B_Sys_Number_Jn[i]; j++)
                for(int k=0; k<B_Sys_Number_Jn[i]; k++)
                        fread(B_six_j_H[i][j][k], sizeof(double), B_N_Sys_Number_Jn[i+1], fi);
                fclose(fi);
        }

}

//===============================================================================================================
//			Create space for wavefunctions of configurations 2 and 3
//===============================================================================================================
inline void ChiralCorrelation::CreateFunction(Super &sup) {

	int inc=1;

  //----WaveFunction_config_1------------------------------------------------------------------------------------
        WaveFunction_block=new double * [sup.BlockNumber_for_TargetSpin];
        for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++) {
                WaveFunction_block[i]=new double [sup.Dim_block[i]];
                for(int j=0; j<sup.Dim_block[i]; j++)
                        WaveFunction_block[i][j]=0.0;
        }

        FILE *f=fopen("wavefunction/wavefunction_ground", "a+");
        for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++)
        for(int j=0; j<sup.Dim_block[i]; j++)
                fscanf(f, "%lf\n", &WaveFunction_block[i][j]);
        fclose(f);

  //----WaveFunction_config_2------------------------------------------------------------------------------------
	WaveFunction_config_2=new double * [sup.BlockNumber_for_TargetSpin];
	for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++) {
		WaveFunction_config_2[i]=new double [sup.Dim_block[i]];
		for(int j=0; j<sup.Dim_block[i]; j++) 
			WaveFunction_config_2[i][j]=0.0;
	}

	for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++) {
                int index=0;
                for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
                if(sup.J_sys[j]==sup.J_sys[i] && sup.J_env[j]==sup.J_env[i]) {
                        daxpy_(&sup.Dim_block[i], &sup.nine_j_config_2[i][index++], WaveFunction_block[j], &inc, WaveFunction_config_2[i], &inc);
                }
        }

  //----WaveFunction_config_3------------------------------------------------------------------------------------
	WaveFunction_config_3=new double * [sup.BlockNumber_for_TargetSpin_config_3];
        for(int i=0; i<sup.BlockNumber_for_TargetSpin_config_3; i++) {
                WaveFunction_config_3[i]=new double [sup.Dim_block_config_3[i]];
                for(int j=0; j<sup.Dim_block_config_3[i]; j++)
                        WaveFunction_config_3[i][j]=0.0;
        }

	for(int i=0; i<sup.BlockNumber_for_TargetSpin_config_3; i++) {
                int index=0;
                for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
                if(sup.J_sys[j]==sup.J_sys_config_3[i] && sup.J_env[j]==sup.J_env_config_3[i]) {
                        daxpy_(&sup.Dim_block_config_3[i], &sup.nine_j_config_3[i][index++], WaveFunction_block[j], &inc, WaveFunction_config_3[i], &inc);
                }
        }
}
//===============================================================================================================


//===============================================================================================================
//===============================================================================================================
//===============================================================================================================
//	Spin-Spin Correlation Functions:	Correlation function of sites in system and ns, ne
//===============================================================================================================
inline void ChiralCorrelation::Correlation_sys(const int &lsys, Parameter &para, Super &sup) {
}

//===============================================================================================================
//			Correlation function of sites in environment and ns, ne
//===============================================================================================================
inline void ChiralCorrelation::Correlation_env(const int &lsys, Parameter &para, Super &sup) {
}

//===============================================================================================================
//				Correlation function between sites in sys and env
//===============================================================================================================
inline void ChiralCorrelation::Correlation_sys_env_memory(const int &lsys, Parameter &para, Super &sup) {

	for(int block_a=para.N_x/2-1; block_a>=0; block_a--)
	for(int block_b=para.N_x/2-2; block_b>=0; block_b--) {

//		int i=2+3*para.N_y*block_a, j=i+5, k=j+1;	//system block
//		int p=2+3+3*para.N_y*block_b, q=p+1, l=q+5;	//environment block

		int i=3*para.N_y*block_a, j=i+1, k=j+6;	//system block
		int p=2+4+3*para.N_y*block_b, q=p+6, l=q+1;	//environment block



	//----Initialize Si operators--------------------------------------------------------------------------
                if(i==0)        New_A_Si_initial(0, para);//S_Dia is symmetric, S_M_Dia is (i,j)=(-1)*(j,i)
                else  {
                        New_A_Si_initial(i, para);  Truncate_A_Si(i);
                }

	//----Transform Si operators---------------------------------------------------------------------------
//		for(int m=i+1; m<j; m++) {
//			New_A_Si_new(m, para);  Truncate_A_Si(m);
//		}	

		//delta_J=0
       		CreateSpace_delta_J_zero_new_A(j, &Sij_Dia_new_A);//y
		Initial_rank_one_delta_J_zero_A(para, j, -1.0, &Sij_Dia_new_A, &Si_Dia_old_A, &Si_M_Dia_old_A);//phase=-1.0,anti-symmmetric. y
	        CreateSpace_delta_J_zero_old_A(j, &Sij_Dia_old_A);//y
		Truncate_delta_J_zero_A(j, &Sij_Dia_old_A, &Sij_Dia_new_A);//y
                FreeSpace_delta_J_zero_new_A(j, &Sij_Dia_new_A);//y

		//delta_J=1
		CreateSpace_delta_J_one_new_A(j, &Sij_M_Dia_new_A);//y
	        Initial_rank_one_delta_J_one_A(para, j, &Sij_M_Dia_new_A, &Si_Dia_old_A, &Si_M_Dia_old_A);//y,Block(i,j)=Block(j,i)
        	CreateSpace_delta_J_one_old_A(j, &Sij_M_Dia_old_A);//y
	        Truncate_delta_J_one_A(j, &Sij_M_Dia_old_A, &Sij_M_Dia_new_A);//y
        	FreeSpace_delta_J_one_new_A(j, &Sij_M_Dia_new_A);//y

		//delete Si
	        for(int m=0; m<A_Sys_Number_Jn[j-1]; m++)
        	        delete [] Si_Dia_old_A[m];
        	delete [] Si_Dia_old_A;

	        for(int m=0; m<A_Sys_Number_Jn[j-1]-1; m++)
        	        delete [] Si_M_Dia_old_A[m];
        	delete [] Si_M_Dia_old_A;

/*		for(int m=j+1; m<k; m++) {
	                CreateSpace_delta_J_zero_new_A(m, &Sij_Dia_new_A);
	                New_rank_one_delta_J_zero_A(para, m, 1.0, &Sij_Dia_new_A, &Sij_Dia_old_A, &Sij_M_Dia_old_A);//phase=1.0!

	                CreateSpace_delta_J_one_new_A(m, &Sij_M_Dia_new_A);
	                New_rank_one_delta_J_one_A(para, m, &Sij_M_Dia_new_A, &Sij_Dia_old_A, &Sij_M_Dia_old_A);

	                FreeSpace_delta_J_zero_old_A(m-1, &Sij_Dia_old_A);
        	        FreeSpace_delta_J_one_old_A(m-1, &Sij_M_Dia_old_A);

	                CreateSpace_delta_J_zero_old_A(m, &Sij_Dia_old_A);
        	        Truncate_delta_J_zero_A(m, &Sij_Dia_old_A, &Sij_Dia_new_A);
                	FreeSpace_delta_J_zero_new_A(m, &Sij_Dia_new_A);

	                CreateSpace_delta_J_one_old_A(m, &Sij_M_Dia_old_A);
        	        Truncate_delta_J_one_A(m, &Sij_M_Dia_old_A, &Sij_M_Dia_new_A);
                	FreeSpace_delta_J_one_new_A(m, &Sij_M_Dia_new_A);
		}
*/
                CreateSpace_delta_J_zero_new_A(k, &Sijk_new_A);
		Initial_rank_zero_A(para, k, &Sijk_new_A, &Sij_Dia_old_A, &Sij_M_Dia_old_A);
                CreateSpace_delta_J_zero_old_A(k, &Sijk_old_A);
		Truncate_delta_J_zero_A(k, &Sijk_old_A, &Sijk_new_A);
		FreeSpace_delta_J_zero_new_A(k, &Sijk_new_A);

		//delete Sij
		for(int m=0; m<A_Sys_Number_Jn[k-1]; m++)
        	        delete [] Sij_Dia_old_A[m];
        	delete [] Sij_Dia_old_A;

	        for(int m=0; m<A_Sys_Number_Jn[k-1]-1; m++)
        	        delete [] Sij_M_Dia_old_A[m];
        	delete [] Sij_M_Dia_old_A;

		for(int m=k+1; m<lsys; m++) {
	                CreateSpace_delta_J_zero_new_A(m, &Sijk_new_A);
	                New_rank_zero_A(para, m, &Sijk_new_A, &Sijk_old_A);
	                FreeSpace_delta_J_zero_old_A(m-1, &Sijk_old_A);

	                CreateSpace_delta_J_zero_old_A(m, &Sijk_old_A);
	                Truncate_delta_J_zero_A(m, &Sijk_old_A, &Sijk_new_A);

	                FreeSpace_delta_J_zero_new_A(m, &Sijk_new_A);
		}

	//----Initialize Sp operators--------------------------------------------------------------------------
                if(p==0)        New_B_Si_initial(0, para);
                else  {
                       New_B_Si_initial(p, para);  Truncate_B_Si(p);
                }

	//----Transform Sp operators---------------------------------------------------------------------------
//		for(int m=p+1; m<q; m++) {
//			New_B_Si_new(m, para);  Truncate_B_Si(m);
//		}	

		//delta_J=0
       		CreateSpace_delta_J_zero_new_B(q, &Sij_Dia_new_B);
		Initial_rank_one_delta_J_zero_B(para, q, -1.0, &Sij_Dia_new_B, &Si_Dia_old_B, &Si_M_Dia_old_B);//phase=-1.0!!!
	        CreateSpace_delta_J_zero_old_B(q, &Sij_Dia_old_B);
		Truncate_delta_J_zero_B(q, &Sij_Dia_old_B, &Sij_Dia_new_B);
                FreeSpace_delta_J_zero_new_B(q, &Sij_Dia_new_B);

		//delta_J=1
		CreateSpace_delta_J_one_new_B(q, &Sij_M_Dia_new_B);
	        Initial_rank_one_delta_J_one_B(para, q, &Sij_M_Dia_new_B, &Si_Dia_old_B, &Si_M_Dia_old_B);
        	CreateSpace_delta_J_one_old_B(q, &Sij_M_Dia_old_B);
	        Truncate_delta_J_one_B(q, &Sij_M_Dia_old_B, &Sij_M_Dia_new_B);
        	FreeSpace_delta_J_one_new_B(q, &Sij_M_Dia_new_B);

		//delete Sp 
	        for(int m=0; m<B_Sys_Number_Jn[q-1]; m++)
        	        delete [] Si_Dia_old_B[m];
	        delete [] Si_Dia_old_B;

        	for(int m=0; m<B_Sys_Number_Jn[q-1]-1; m++)
                	delete [] Si_M_Dia_old_B[m];
        	delete [] Si_M_Dia_old_B;

/*		for(int m=q+1; m<l; m++) {
	                CreateSpace_delta_J_zero_new_B(m, &Sij_Dia_new_B);
	                New_rank_one_delta_J_zero_B(para, m, 1.0, &Sij_Dia_new_B, &Sij_Dia_old_B, &Sij_M_Dia_old_B);

	                CreateSpace_delta_J_one_new_B(m, &Sij_M_Dia_new_B);
	                New_rank_one_delta_J_one_B(para, m, &Sij_M_Dia_new_B, &Sij_Dia_old_B, &Sij_M_Dia_old_B);

	                FreeSpace_delta_J_zero_old_B(m-1, &Sij_Dia_old_B);
        	        FreeSpace_delta_J_one_old_B(m-1, &Sij_M_Dia_old_B);

	                CreateSpace_delta_J_zero_old_B(m, &Sij_Dia_old_B);
        	        Truncate_delta_J_zero_B(m, &Sij_Dia_old_B, &Sij_Dia_new_B);
                	FreeSpace_delta_J_zero_new_B(m, &Sij_Dia_new_B);

	                CreateSpace_delta_J_one_old_B(m, &Sij_M_Dia_old_B);
        	        Truncate_delta_J_one_B(m, &Sij_M_Dia_old_B, &Sij_M_Dia_new_B);
                	FreeSpace_delta_J_one_new_B(m, &Sij_M_Dia_new_B);
		}
*/
                CreateSpace_delta_J_zero_new_B(l, &Sijk_new_B);
                Initial_rank_zero_B(para, l, &Sijk_new_B, &Sij_Dia_old_B, &Sij_M_Dia_old_B);
                CreateSpace_delta_J_zero_old_B(l, &Sijk_old_B);
                Truncate_delta_J_zero_B(l, &Sijk_old_B, &Sijk_new_B);
		FreeSpace_delta_J_zero_new_B(l, &Sijk_new_B);

		//delete Sij
	        for(int m=0; m<B_Sys_Number_Jn[l-1]; m++)
        	        delete [] Sij_Dia_old_B[m];
	        delete [] Sij_Dia_old_B;

        	for(int m=0; m<B_Sys_Number_Jn[l-1]-1; m++)
                	delete [] Sij_M_Dia_old_B[m];
        	delete [] Sij_M_Dia_old_B;

		for(int m=l+1; m<lsys; m++) {
	                CreateSpace_delta_J_zero_new_B(m, &Sijk_new_B);
	                New_rank_zero_B(para, m, &Sijk_new_B, &Sijk_old_B);
	                FreeSpace_delta_J_zero_old_B(m-1, &Sijk_old_B);

	                CreateSpace_delta_J_zero_old_B(m, &Sijk_old_B);
	                Truncate_delta_J_zero_B(m, &Sijk_old_B, &Sijk_new_B);

	                FreeSpace_delta_J_zero_new_B(m, &Sijk_new_B);
		}

/*		for(int i=0; i<B_Sys_Number_Jn[lsys-1]; i++) {
			for(int j=0; j<B_Sys_SubBlockNumber_Jn[lsys-1][i]*B_Sys_SubBlockNumber_Jn[lsys-1][i]; j++) {
				int x=j/B_Sys_SubBlockNumber_Jn[lsys-1][i];
				int y=j%B_Sys_SubBlockNumber_Jn[lsys-1][i];
				if(x>y) {
					int new_i=B_Sys_SubBlockNumber_Jn[lsys-1][i]*y+x;
					if( fabs(Sijk_old_B[i][j]+Sijk_old_B[i][new_i])>1.e-14  )
						cout<<"\n A"<<endl;
				}
			}
		}
*/

//------Calcualte the chiral correlation function--------------------------------------------------------------
	        double correlation=0.0;
        	alpha=1.0;  beta=0.0;
        	for(int m=0; m<sup.BlockNumber_for_TargetSpin_config_3; m++) {

                	int dim=sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[m]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]];
                	int dim_s=sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]]*sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]];

                	double *matrix=new double [dim];      double *matrix_p=new double [dim];
                	for(int n=0; n<dim; n++)  {
                        	matrix[n]=0.0;      matrix_p[n]=0.0;
                	}

                	double *matrix_s=new double [dim_s];
                	for(int n=0; n<dim_s; n++)      matrix_s[n]=0.0;

                	dgemm_(&trans_N, &trans_N, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[m]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], &alpha, Sijk_old_A[sup.J_sys_config_3[m]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], WaveFunction_config_3[m], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], &beta, matrix, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]]);//the second trans_N change to conjugate for complex
                	dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[m]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[m]], &alpha, matrix, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], Sijk_old_B[sup.J_env_config_3[m]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[m]], &beta, matrix_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]]);
                	dgemm_(&trans_N, &trans_T, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], &sup.env->Sys_SubBlockNumber_Jn[sup.J_env_config_3[m]], &alpha, matrix_p, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], WaveFunction_config_3[m], &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]], &beta, matrix_s, &sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]]);

                	for(int n=0; n<sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]]; n++)
                        	correlation+=matrix_s[n*(1+sup.sys->Sys_SubBlockNumber_Jn[sup.J_sys_config_3[m]])];

                	delete [] matrix;      delete [] matrix_p;      delete [] matrix_s;
		}

       		cout<<"\n"<<i<<"\t"<<j<<"\t"<<k<<"\t"<<para.N-1-l<<"\t"<<para.N-1-q<<"\t"<<para.N-1-p<<"\t"<<2.0*correlation<<endl;

//------Delete space
       	for(int m=0; m<A_Sys_Number_Jn[lsys-1]; m++)
                	delete [] Sijk_old_A[m];
        	delete [] Sijk_old_A;

        	for(int m=0; m<B_Sys_Number_Jn[para.N-lsys-3]; m++)
                	delete [] Sijk_old_B[m];
        	delete [] Sijk_old_B;

	}

}

//===============================================================================================================

//===============================================================================================================
//===============================================================================================================
//						     New_A_Si
//===============================================================================================================
inline void ChiralCorrelation::New_A_Si_new(const int &num, Parameter &para) {
//------Create space and define the operators of Si--------------------------------------------------------------
	Si_Dia_new_A=new double * [A_N_Sys_Number_Jn[num]];
	Si_M_Dia_new_A=new double * [A_N_Sys_Number_Jn[num]-1];

	for(int i=0; i<A_N_Sys_Number_Jn[num]; i++) {
		int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i];
		Si_Dia_new_A[i]=new double [Dia_Dim];
		for(int j=0; j<Dia_Dim; j++) 
			Si_Dia_new_A[i][j]=0.0;
	}

	for(int i=0; i<A_N_Sys_Number_Jn[num]-1; i++) {
		int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i+1];
		Si_M_Dia_new_A[i]=new double [Dia_Dim];
		for(int j=0; j<Dia_Dim; j++)
			Si_M_Dia_new_A[i][j]=0.0;
	}

//------The new basis transformation-----------------------------------------------------------------------
	int oldJn, oldJm, position, a_new, a_new_t;
	double factor;

    //--New_S_Dia-----------------------------------------------------------
	for(int j=0; j<A_N_Sys_Number_Jn[num]; j++)
        if(A_N_Sys_Value_Jn[num][j]!=0) {
        	for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=A_N_IndexOld[num][n][j])!=-1 && (oldJm=A_N_IndexOld[num][m][j])!=-1) {
               		if(oldJn==oldJm && A_Sys_Value_Jn[num-1][oldJn]!=0) {
                        	position=(A_N_Sys_SubBlockNumber_Jn[num][j]+1)*A_N_Start[num][n][j];
                                factor=pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j]+2+para.S)/2)*(A_N_Sys_Value_Jn[num][j]+1.0)*A_six_j_S_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJn]*A_Sys_SubBlockNumber_Jn[num-1][oldJn]; a_old++) {
                                	a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                        Si_Dia_new_A[j][a_new]+=factor*Si_Dia_old_A[oldJn][a_old];
                                }
                        }

                        else if((oldJm-oldJn)==1 && (A_Sys_Value_Jn[num-1][oldJm]-A_Sys_Value_Jn[num-1][oldJn])==2) {
                        	position=A_N_Sys_SubBlockNumber_Jn[num][j]*A_N_Start[num][m][j]+A_N_Start[num][n][j];
                                factor=pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j]+2+para.S)/2)*(A_N_Sys_Value_Jn[num][j]+1.0)*A_six_j_S_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJn]*A_Sys_SubBlockNumber_Jn[num-1][oldJn+1]; a_old++) {
                                	a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJn];
					a_new_t=A_N_Sys_SubBlockNumber_Jn[num][j]*(a_new%A_N_Sys_SubBlockNumber_Jn[num][j])+a_new/A_N_Sys_SubBlockNumber_Jn[num][j];
                                        Si_Dia_new_A[j][a_new]+=factor*Si_M_Dia_old_A[oldJn][a_old];
                                        Si_Dia_new_A[j][a_new_t]+=factor*Si_M_Dia_old_A[oldJn][a_old]; 
                                }
                        }
                }
        }

    //--New S_M_Dia-----------------------------------------------------------------	
	for(int j=0; j<A_N_Sys_Number_Jn[num]-1; j++)
        if((A_N_Sys_Value_Jn[num][j+1]-A_N_Sys_Value_Jn[num][j])==2) {
		for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=A_N_IndexOld[num][n][j])!=-1 && (oldJm=A_N_IndexOld[num][m][j+1])!=-1) {
	        	if(oldJn==oldJm && A_Sys_Value_Jn[num-1][oldJn]!=0) {
				position=A_N_Sys_SubBlockNumber_Jn[num][j]*A_N_Start[num][m][j+1]+A_N_Start[num][n][j];
                		factor=pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((A_N_Sys_Value_Jn[num][j]+1.0)*(A_N_Sys_Value_Jn[num][j+1]+1.0))*A_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                		for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJn]*A_Sys_SubBlockNumber_Jn[num-1][oldJn]; a_old++) {
                  			a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJn];
                        		Si_M_Dia_new_A[j][a_new]+=factor*Si_Dia_old_A[oldJn][a_old];
                 		}
                	}

                	else if((oldJn-oldJm)==1 && (A_Sys_Value_Jn[num-1][oldJn]-A_Sys_Value_Jn[num-1][oldJm])==2) {
             			position=A_N_Sys_SubBlockNumber_Jn[num][j]*A_N_Start[num][m][j+1]+A_N_Start[num][n][j];
                        	factor=-pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((A_N_Sys_Value_Jn[num][j]+1.0)*(A_N_Sys_Value_Jn[num][j+1]+1.0))*A_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];//A minus sign "-" here for S_M_Dia
                        	for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJm]*A_Sys_SubBlockNumber_Jn[num-1][oldJm+1]; a_old++) {
                           		a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJm])+a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJm];
			        	Si_M_Dia_new_A[j][a_new]+=factor*Si_M_Dia_old_A[oldJm][a_old];
                        	}
                	}

                	else if((oldJm-oldJn)==1 && (A_Sys_Value_Jn[num-1][oldJm]-A_Sys_Value_Jn[num-1][oldJn])==2) {
                      		position=A_N_Sys_SubBlockNumber_Jn[num][j]*A_N_Start[num][m][j+1]+A_N_Start[num][n][j];
                        	factor=pow(-1.0, (A_Sys_Value_Jn[num-1][oldJn]+A_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((A_N_Sys_Value_Jn[num][j]+1.0)*(A_N_Sys_Value_Jn[num][j+1]+1.0))*A_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                        	for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[num-1][oldJn]*A_Sys_SubBlockNumber_Jn[num-1][oldJn+1]; a_old++) {
                             		a_new=position+A_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/A_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%A_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                	Si_M_Dia_new_A[j][a_new]+=factor*Si_M_Dia_old_A[oldJn][a_old];
                        	}
                	}
        	}
	}

//------Delete Si_old--------------------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[num-1]; i++) 
		delete [] Si_Dia_old_A[i];
	delete [] Si_Dia_old_A;		

	for(int i=0; i<A_Sys_Number_Jn[num-1]-1; i++)
		delete [] Si_M_Dia_old_A[i];
	delete [] Si_M_Dia_old_A;

//------Create new Si_old----------------------------------------------------------------------------------------
        Si_Dia_old_A=new double * [A_N_Sys_Number_Jn[num]];
        Si_M_Dia_old_A=new double * [A_N_Sys_Number_Jn[num]-1];

        for(int i=0; i<A_N_Sys_Number_Jn[num]; i++) {
                int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i];
                Si_Dia_old_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_old_A[i][j]=Si_Dia_new_A[i][j];
        }

        for(int i=0; i<A_N_Sys_Number_Jn[num]-1; i++) {
                int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i+1];
                Si_M_Dia_old_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_old_A[i][j]=Si_M_Dia_new_A[i][j];
        }

//------Delete Si_new--------------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[num]; i++) 
                delete [] Si_Dia_new_A[i]; 
        delete [] Si_Dia_new_A;           

	for(int i=0; i<A_N_Sys_Number_Jn[num]-1; i++)
		delete [] Si_M_Dia_new_A[i];
	delete [] Si_M_Dia_new_A;
}

//===============================================================================================================
//							New B_Si
//===============================================================================================================
inline void ChiralCorrelation::New_B_Si_new(const int &num, Parameter &para) {
//------Create space and define the operators of Si--------------------------------------------------------------
        Si_Dia_new_B=new double * [B_N_Sys_Number_Jn[num]];
        Si_M_Dia_new_B=new double * [B_N_Sys_Number_Jn[num]-1];

        for(int i=0; i<B_N_Sys_Number_Jn[num]; i++) {
                int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i];
                Si_Dia_new_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_new_B[i][j]=0.0;
        }

        for(int i=0; i<B_N_Sys_Number_Jn[num]-1; i++) {
                int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i+1];
                Si_M_Dia_new_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_new_B[i][j]=0.0;
        }

//------The new basis transformation-----------------------------------------------------------------------------
	int oldJn, oldJm, position, a_new, a_new_t;
        double factor;

    //--New_S_Dia-----------------------------------------------------------
	for(int j=0; j<B_N_Sys_Number_Jn[num]; j++)
        if(B_N_Sys_Value_Jn[num][j]!=0) {
                for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=B_N_IndexOld[num][n][j])!=-1 && (oldJm=B_N_IndexOld[num][m][j])!=-1) {
                        if(oldJn==oldJm && B_Sys_Value_Jn[num-1][oldJn]!=0) {
                                position=(B_N_Sys_SubBlockNumber_Jn[num][j]+1)*B_N_Start[num][n][j];
                                factor=pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j]+2+para.S)/2)*(B_N_Sys_Value_Jn[num][j]+1.0)*B_six_j_S_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJn]*B_Sys_SubBlockNumber_Jn[num-1][oldJn]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                        Si_Dia_new_B[j][a_new]+=factor*Si_Dia_old_B[oldJn][a_old];
                                }
                        }
                        else if((oldJm-oldJn)==1 && (B_Sys_Value_Jn[num-1][oldJm]-B_Sys_Value_Jn[num-1][oldJn])==2) {
                                position=B_N_Sys_SubBlockNumber_Jn[num][j]*B_N_Start[num][m][j]+B_N_Start[num][n][j];
                                factor=pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j]+2+para.S)/2)*(B_N_Sys_Value_Jn[num][j]+1.0)*B_six_j_S_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJn]*B_Sys_SubBlockNumber_Jn[num-1][oldJn+1]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJn];
				        a_new_t=B_N_Sys_SubBlockNumber_Jn[num][j]*(a_new%B_N_Sys_SubBlockNumber_Jn[num][j])+a_new/B_N_Sys_SubBlockNumber_Jn[num][j];
                                        Si_Dia_new_B[j][a_new]+=factor*Si_M_Dia_old_B[oldJn][a_old];
                                        Si_Dia_new_B[j][a_new_t]+=factor*Si_M_Dia_old_B[oldJn][a_old];
                                }
                        }
                }
        }

    //--New S_M_Dia-----------------------------------------------------------------    
	for(int j=0; j<B_N_Sys_Number_Jn[num]-1; j++)
        if((B_N_Sys_Value_Jn[num][j+1]-B_N_Sys_Value_Jn[num][j])==2) {
                for(int n=0; n<para.S+1; n++)
                for(int m=0; m<para.S+1; m++)
                if((oldJn=B_N_IndexOld[num][n][j])!=-1 && (oldJm=B_N_IndexOld[num][m][j+1])!=-1) {
                        if(oldJn==oldJm && B_Sys_Value_Jn[num-1][oldJn]!=0) {
                                position=B_N_Sys_SubBlockNumber_Jn[num][j]*B_N_Start[num][m][j+1]+B_N_Start[num][n][j];
                                factor=pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((B_N_Sys_Value_Jn[num][j]+1.0)*(B_N_Sys_Value_Jn[num][j+1]+1.0))*B_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJn]*B_Sys_SubBlockNumber_Jn[num-1][oldJn]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                        Si_M_Dia_new_B[j][a_new]+=factor*Si_Dia_old_B[oldJn][a_old];
                                }
                        }

                        else if((oldJn-oldJm)==1 && (B_Sys_Value_Jn[num-1][oldJn]-B_Sys_Value_Jn[num-1][oldJm])==2) {   
				 position=B_N_Sys_SubBlockNumber_Jn[num][j]*B_N_Start[num][m][j+1]+B_N_Start[num][n][j];
                                factor=-pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((B_N_Sys_Value_Jn[num][j]+1.0)*(B_N_Sys_Value_Jn[num][j+1]+1.0))*B_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJm]*B_Sys_SubBlockNumber_Jn[num-1][oldJm+1]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJm])+a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJm];
                                        Si_M_Dia_new_B[j][a_new]+=factor*Si_M_Dia_old_B[oldJm][a_old];
                                }
                        }

                        else if((oldJm-oldJn)==1 && (B_Sys_Value_Jn[num-1][oldJm]-B_Sys_Value_Jn[num-1][oldJn])==2) {
                                position=B_N_Sys_SubBlockNumber_Jn[num][j]*B_N_Start[num][m][j+1]+B_N_Start[num][n][j];
                                factor=pow(-1.0, (B_Sys_Value_Jn[num-1][oldJn]+B_N_Sys_Value_Jn[num][j+1]+2+para.S)/2)*sqrt((B_N_Sys_Value_Jn[num][j]+1.0)*(B_N_Sys_Value_Jn[num][j+1]+1.0))*B_six_j_S_M_Dia_old[num-1][oldJn][oldJm][j];
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[num-1][oldJn]*B_Sys_SubBlockNumber_Jn[num-1][oldJn+1]; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[num][j]*(a_old/B_Sys_SubBlockNumber_Jn[num-1][oldJn])+a_old%B_Sys_SubBlockNumber_Jn[num-1][oldJn];
                                        Si_M_Dia_new_B[j][a_new]+=factor*Si_M_Dia_old_B[oldJn][a_old];
                                }
                        }
                }
        }

//------Delete Si_old--------------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[num-1]; i++)
                delete [] Si_Dia_old_B[i];
        delete [] Si_Dia_old_B;

        for(int i=0; i<B_Sys_Number_Jn[num-1]-1; i++)
                delete [] Si_M_Dia_old_B[i];
        delete [] Si_M_Dia_old_B;

//------Create new Si_old----------------------------------------------------------------------------------------
        Si_Dia_old_B=new double * [B_N_Sys_Number_Jn[num]];
        Si_M_Dia_old_B=new double * [B_N_Sys_Number_Jn[num]-1];

        for(int i=0; i<B_N_Sys_Number_Jn[num]; i++) {
                int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i];
                Si_Dia_old_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_old_B[i][j]=Si_Dia_new_B[i][j];
        }

        for(int i=0; i<B_N_Sys_Number_Jn[num]-1; i++) {
                int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i+1];
                Si_M_Dia_old_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_old_B[i][j]=Si_M_Dia_new_B[i][j];
        }

//------Delete Si_new--------------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[num]; i++)
                delete [] Si_Dia_new_B[i];
        delete [] Si_Dia_new_B;

        for(int i=0; i<B_N_Sys_Number_Jn[num]-1; i++)
                delete [] Si_M_Dia_new_B[i];
        delete [] Si_M_Dia_new_B;
}

//===============================================================================================================
//						New_A_Si_initial
//===============================================================================================================
inline void ChiralCorrelation::New_A_Si_initial(const int &n_num, Parameter &para) {

	if(n_num==0) {
           //------Create space----------------------------------------------------------------------------------
	        Si_Dia_old_A=new double * [1];
		for(int i=0; i<1; i++) {
			Si_Dia_old_A[i]=new double [1];
			Si_Dia_old_A[i][0]=constant;
		}

		Si_M_Dia_old_A=new double * [0];
		for(int i=0; i<0; i++) {
			Si_M_Dia_old_A[i]=new double [0];
			for(int j=0; j<0; j++)
				Si_M_Dia_old_A[i][j]=0.0;
		}
	}

	else if(n_num>0) {
           //------Create space----------------------------------------------------------------------------------
        	Si_Dia_old_A=new double * [A_N_Sys_Number_Jn[n_num]];
        	Si_M_Dia_old_A=new double * [A_N_Sys_Number_Jn[n_num]-1];

        	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++) {
                	int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i];
                	Si_Dia_old_A[i]=new double [Dia_Dim];
                	for(int j=0; j<Dia_Dim; j++) 
                        	Si_Dia_old_A[i][j]=0.0;
        	}

        	for(int i=0; i<A_N_Sys_Number_Jn[n_num]-1; i++) {
                	int Dia_Dim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i+1];
                	Si_M_Dia_old_A[i]=new double [Dia_Dim];
                	for(int j=0; j<Dia_Dim; j++)
                        	Si_M_Dia_old_A[i][j]=0.0;
        	}

           //------The new basis transformation------------------------------------------------------------------
		int oldJn, oldJm, position, a_new, a_new_t;
        	double factor;

		//--New S_Dia---------------------------------------------------
		for(int j=0; j<A_N_Sys_Number_Jn[n_num]; j++)
		if(A_N_Sys_Value_Jn[n_num][j]!=0) {
			for(int n=0; n<para.S+1; n++)
        	        if((oldJn=A_N_IndexOld[n_num][n][j])!=-1) {
                		position=A_N_Sys_SubBlockNumber_Jn[n_num][j]+1;
                        	factor=pow(-1.0, (A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJn]+2+para.S)/2)*(A_N_Sys_Value_Jn[n_num][j]+1.0)*A_six_j_S_Dia_n[n_num-1][j][oldJn]*constant;
                        	for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]; a_old++) {
                        		a_new=position*(A_N_Start[n_num][n][j]+a_old);
                                	Si_Dia_old_A[j][a_new]+=factor;
                        	}
                	}
		}

    		//--New S_M_Dia-------------------------------------------------
		for(int j=0; j<A_N_Sys_Number_Jn[n_num]-1; j++)
        	if((A_N_Sys_Value_Jn[n_num][j+1]-A_N_Sys_Value_Jn[n_num][j])==2) {
        		for(int n=0; n<para.S+1; n++)
                	for(int m=0; m<para.S+1; m++) {
                		if((oldJn=A_N_IndexOld[n_num][n][j])!=-1 && (oldJm=A_N_IndexOld[n_num][m][j+1])!=-1)
                        	if(oldJn==oldJm) {
                        		position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][m][j+1]+A_N_Start[n_num][n][j];
                                	factor=pow(-1.0, (A_Sys_Value_Jn[n_num-1][oldJn]+A_N_Sys_Value_Jn[n_num][j]+2+para.S)/2)*sqrt((A_N_Sys_Value_Jn[n_num][j]+1.0)*(A_N_Sys_Value_Jn[n_num][j+1]+1.0))*A_six_j_S_M_Dia_n[n_num-1][j][oldJn]*constant;
                                	for(int a_old=0; a_old<A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]; a_old++) {
                                		a_new=position+(A_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*a_old;
                                        	Si_M_Dia_old_A[j][a_new]+=factor;
                                	}
                        	}
                	}
        	}
	}
}

//===============================================================================================================
//						New B_Si initial
//===============================================================================================================
inline void ChiralCorrelation::New_B_Si_initial(const int &n_num, Parameter &para) {

        if(n_num==0) {
                Si_Dia_old_B=new double * [1];
                for(int i=0; i<1; i++) {
                        Si_Dia_old_B[i]=new double [1];
                        Si_Dia_old_B[i][0]=constant;
                }

                Si_M_Dia_old_B=new double * [0];
                for(int i=0; i<0; i++) {
                        Si_M_Dia_old_B[i]=new double [0];
                        for(int j=0; j<0; j++)
                                Si_M_Dia_old_B[i][j]=0.0;
                }
        }

        else if(n_num>0) {
           //------Create space----------------------------------------------------------------------------------
                Si_Dia_old_B=new double * [B_N_Sys_Number_Jn[n_num]];
                Si_M_Dia_old_B=new double * [B_N_Sys_Number_Jn[n_num]-1];

                for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++) {
                        int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i];
                        Si_Dia_old_B[i]=new double [Dia_Dim];
                        for(int j=0; j<Dia_Dim; j++)
                                Si_Dia_old_B[i][j]=0.0;
                }

                for(int i=0; i<B_N_Sys_Number_Jn[n_num]-1; i++) {
                        int Dia_Dim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i+1];
                        Si_M_Dia_old_B[i]=new double [Dia_Dim];
                        for(int j=0; j<Dia_Dim; j++)
                                Si_M_Dia_old_B[i][j]=0.0;
                }
		
           //------The new basis transformation------------------------------------------------------------------
 	   	int oldJn, oldJm, position, a_new, a_new_t;
                double factor;

                //--New S_Dia---------------------------------------------------
                for(int j=0; j<B_N_Sys_Number_Jn[n_num]; j++)
                if(B_N_Sys_Value_Jn[n_num][j]!=0) {
                        for(int n=0; n<para.S+1; n++)
                        if((oldJn=B_N_IndexOld[n_num][n][j])!=-1) {
                                position=B_N_Sys_SubBlockNumber_Jn[n_num][j]+1;
                                factor=pow(-1.0, (B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJn]+2+para.S)/2)*(B_N_Sys_Value_Jn[n_num][j]+1.0)*B_six_j_S_Dia_n[n_num-1][j][oldJn]*constant;
                                for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]; a_old++) {
                                        a_new=position*(B_N_Start[n_num][n][j]+a_old);
                                        Si_Dia_old_B[j][a_new]+=factor;
                                }
                        }
                }

                //--New S_M_Dia-------------------------------------------------
                for(int j=0; j<B_N_Sys_Number_Jn[n_num]-1; j++)
                if((B_N_Sys_Value_Jn[n_num][j+1]-B_N_Sys_Value_Jn[n_num][j])==2) {
                        for(int n=0; n<para.S+1; n++)
                        for(int m=0; m<para.S+1; m++) {
                                if((oldJn=B_N_IndexOld[n_num][n][j])!=-1 && (oldJm=B_N_IndexOld[n_num][m][j+1])!=-1)
                                if(oldJn==oldJm) {
                                        position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][m][j+1]+B_N_Start[n_num][n][j];
                                        factor=pow(-1.0, (B_Sys_Value_Jn[n_num-1][oldJn]+B_N_Sys_Value_Jn[n_num][j]+2+para.S)/2)*sqrt((B_N_Sys_Value_Jn[n_num][j]+1.0)*(B_N_Sys_Value_Jn[n_num][j+1]+1.0))*B_six_j_S_M_Dia_n[n_num-1][j][oldJn]*constant;
                                        for(int a_old=0; a_old<B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]; a_old++) {
                                                a_new=position+(B_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*a_old;
                                                Si_M_Dia_old_B[j][a_new]+=factor;
                                        }
                                }
                        }
                }
	}
}

//===============================================================================================================
//						    Initial_A_SiSj
//===============================================================================================================
inline void ChiralCorrelation::Initial_A_SiSj(const int &n_num, Parameter &para) {
	int oldJn, oldJm, SubDim, a_sysnew, a_sysnew_t;
	double position, factor;

//------Create space for SiSj_old--------------------------------------------------------------------------------
	SiSj_old_A=new double * [A_N_Sys_Number_Jn[n_num]];
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++) {
		SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i];
		SiSj_old_A[i]=new double [SubDim];
		for(int j=0; j<SubDim; j++)
			SiSj_old_A[i][j]=0.0;
	}

//------Initialize SiSj------------------------------------------------------------------------------------------
	for(int j=0; j<A_N_Sys_Number_Jn[n_num]; j++)
	for(int n=0; n<para.S+1; n++)
	for(int m=0; m<para.S+1; m++)
	if((oldJn=A_N_IndexOld[n_num][n][j])!=-1)
	if((oldJm=A_N_IndexOld[n_num][m][j])!=-1) {
		if(oldJn==oldJm && A_Sys_Value_Jn[n_num-1][oldJn]!=0) {
                	position=(A_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*A_N_Start[n_num][n][j];
                        factor=pow(-1.0,(A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJn]+para.S)/2)*constant*A_six_j_H[n_num-1][oldJn][oldJn][j];
			SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                        	a_sysnew=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                SiSj_old_A[j][a_sysnew]+=factor*Si_Dia_old_A[oldJn][a_sys];
                        }
                }

		else if((oldJn+1)==oldJm && (A_Sys_Value_Jn[n_num-1][oldJm]-A_Sys_Value_Jn[n_num-1][oldJn])==2) {
                	position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][m][j]+A_N_Start[n_num][n][j];
                        factor=pow(-1.0,(A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJm]+para.S)/2)*constant*A_six_j_H[n_num-1][oldJn][oldJm][j];
			SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn+1];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
				a_sysnew=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                a_sysnew_t=A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sysnew%A_N_Sys_SubBlockNumber_Jn[n_num][j])+a_sysnew/A_N_Sys_SubBlockNumber_Jn[n_num][j];
                                SiSj_old_A[j][a_sysnew]+=factor*Si_M_Dia_old_A[oldJn][a_sys];
                                SiSj_old_A[j][a_sysnew_t]+=factor*Si_M_Dia_old_A[oldJn][a_sys];
			}
		}
	}
}

//===============================================================================================================
//						Initialize B_SiSj operator
//===============================================================================================================
inline void ChiralCorrelation::Initial_B_SiSj(const int &n_num, Parameter &para) {
	int oldJn, oldJm, SubDim, a_sysnew, a_sysnew_t;
        double position, factor;

//------Create space for SiSj_old--------------------------------------------------------------------------------
        SiSj_old_B=new double * [B_N_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_B[i][j]=0.0;
        }

//------Initialize SiSj------------------------------------------------------------------------------------------
	for(int j=0; j<B_N_Sys_Number_Jn[n_num]; j++)
        for(int n=0; n<para.S+1; n++)
        for(int m=0; m<para.S+1; m++)
        if((oldJn=B_N_IndexOld[n_num][n][j])!=-1)
        if((oldJm=B_N_IndexOld[n_num][m][j])!=-1) {
                if(oldJn==oldJm && B_Sys_Value_Jn[n_num-1][oldJn]!=0) {
                        position=(B_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*B_N_Start[n_num][n][j];
                        factor=pow(-1.0,(B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJn]+para.S)/2)*constant*B_six_j_H[n_num-1][oldJn][oldJn][j];
                        SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                a_sysnew=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                SiSj_old_B[j][a_sysnew]+=factor*Si_Dia_old_B[oldJn][a_sys];
                        }
                }

                else if((oldJn+1)==oldJm && (B_Sys_Value_Jn[n_num-1][oldJm]-B_Sys_Value_Jn[n_num-1][oldJn])==2) {
                        position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][m][j]+B_N_Start[n_num][n][j];
                        factor=pow(-1.0,(B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJm]+para.S)/2)*constant*B_six_j_H[n_num-1][oldJn][oldJm][j];
                        SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn+1];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                a_sysnew=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
				a_sysnew_t=B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sysnew%B_N_Sys_SubBlockNumber_Jn[n_num][j])+a_sysnew/B_N_Sys_SubBlockNumber_Jn[n_num][j];
                                SiSj_old_B[j][a_sysnew]+=factor*Si_M_Dia_old_B[oldJn][a_sys];
                                SiSj_old_B[j][a_sysnew_t]+=factor*Si_M_Dia_old_B[oldJn][a_sys];
                        }
                }
        }
}

//===============================================================================================================
//						New A_SiSj
//===============================================================================================================
inline void ChiralCorrelation::New_A_SiSj(const int &n_num, Parameter &para) {
	int oldJn, position, SubDim, a_sysnew;

//------Create space for new SiSj--------------------------------------------------------------------------------
	SiSj_new_A=new double * [A_N_Sys_Number_Jn[n_num]];
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++) {
		SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_new_A[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_new_A[i][j]=0.0;
        }

//------New A_SiSj-----------------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++)
        for(int n=0; n<para.S+1; n++)
        if((oldJn=A_N_IndexOld[n_num][n][i])!=-1) {
                position=(A_N_Sys_SubBlockNumber_Jn[n_num][i]+1)*A_N_Start[n_num][n][i];
		SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                for(int a_sys=0; a_sys<SubDim; a_sys++) {
                        a_sysnew=position+A_N_Sys_SubBlockNumber_Jn[n_num][i]*(a_sys/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        SiSj_new_A[i][a_sysnew]+=SiSj_old_A[oldJn][a_sys];
                }
        }

//------Delete SiSj_old------------------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num-1]; i++)
		delete [] SiSj_old_A[i];
	delete [] SiSj_old_A;

//------Create new SiSj_old--------------------------------------------------------------------------------------
	SiSj_old_A=new double * [A_N_Sys_Number_Jn[n_num]];
        for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++) {
                SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][i]*A_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_A[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_A[i][j]=SiSj_new_A[i][j];
        }

//------Delete SiSj_new------------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++)
		delete [] SiSj_new_A[i];
	delete [] SiSj_new_A;
}

//===============================================================================================================
//						New B_SiSj
//===============================================================================================================
inline void ChiralCorrelation::New_B_SiSj(const int &n_num, Parameter &para) {
        int oldJn, position, SubDim, a_sysnew;

//------Create space for new SiSj--------------------------------------------------------------------------------
        SiSj_new_B=new double * [B_N_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_new_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_new_B[i][j]=0.0;
        }

//------New B_SiSj-----------------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++)
        for(int n=0; n<para.S+1; n++)
        if((oldJn=B_N_IndexOld[n_num][n][i])!=-1) {
                position=(B_N_Sys_SubBlockNumber_Jn[n_num][i]+1)*B_N_Start[n_num][n][i];
                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                for(int a_sys=0; a_sys<SubDim; a_sys++) {
                        a_sysnew=position+B_N_Sys_SubBlockNumber_Jn[n_num][i]*(a_sys/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        SiSj_new_B[i][a_sysnew]+=SiSj_old_B[oldJn][a_sys];
                }
        }

//------Delete SiSj_old------------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num-1]; i++)
                delete [] SiSj_old_B[i];
        delete [] SiSj_old_B;

//------Create new SiSj_old--------------------------------------------------------------------------------------
        SiSj_old_B=new double * [B_N_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][i]*B_N_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_B[i][j]=SiSj_new_B[i][j];
        }

//------Delete SiSj_new------------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++)
                delete [] SiSj_new_B[i];
        delete [] SiSj_new_B;
}

//===============================================================================================================
//						Truncate A_Si operators 
//===============================================================================================================
inline void ChiralCorrelation::Truncate_A_Si(const int &n_num) {

	char trans_N='N', trans_T='T';
	double alpha=1.0, beta=0.0;

//------Create space and define the operators of Si--------------------------------------------------------------
        Si_Dia_new_A=new double * [A_Sys_Number_Jn[n_num]];
        Si_M_Dia_new_A=new double * [A_Sys_Number_Jn[n_num]-1];

        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                int Dia_Dim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i];
                Si_Dia_new_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_new_A[i][j]=0.0;
        }

        for(int i=0; i<A_Sys_Number_Jn[n_num]-1; i++) {
                int Dia_Dim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i+1];
                Si_M_Dia_new_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_new_A[i][j]=0.0;
        }

//------Truncate S_Dia operator----------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {

		int SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]*A_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, Si_Dia_old_A[A_OldSub[n_num][i]], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &A_Sys_SubBlockNumber_Jn[n_num][i], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, Si_Dia_new_A[i], &A_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Truncate S_M_Dia operator--------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num]-1; i++)
	if((A_Sys_Value_Jn[n_num][i+1]-A_Sys_Value_Jn[n_num][i])==2 && (A_N_Sys_Value_Jn[n_num][A_OldSub[n_num][i+1]]-A_N_Sys_Value_Jn[n_num][A_OldSub[n_num][i]])==2) {
		int SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]*A_Sys_SubBlockNumber_Jn[n_num][i+1];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &A_Sys_SubBlockNumber_Jn[n_num][i+1], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i+1]], &alpha, Si_M_Dia_old_A[A_OldSub[n_num][i]], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], A[n_num][i+1], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i+1]], &beta, f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &A_Sys_SubBlockNumber_Jn[n_num][i], &A_Sys_SubBlockNumber_Jn[n_num][i+1], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, Si_M_Dia_new_A[i], &A_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Delete Si_old--------------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++)
                delete [] Si_Dia_old_A[i];
        delete [] Si_Dia_old_A;           
	
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]-1; i++)
		delete [] Si_M_Dia_old_A[i];
	delete [] Si_M_Dia_old_A;

//------Create new Si_old----------------------------------------------------------------------------------------
        Si_Dia_old_A=new double * [A_Sys_Number_Jn[n_num]];
        Si_M_Dia_old_A=new double * [A_Sys_Number_Jn[n_num]-1];

        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                int Dia_Dim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i];
                Si_Dia_old_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_old_A[i][j]=Si_Dia_new_A[i][j];
        }

        for(int i=0; i<A_Sys_Number_Jn[n_num]-1; i++) {
                int Dia_Dim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i+1];
                Si_M_Dia_old_A[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_old_A[i][j]=Si_M_Dia_new_A[i][j];
        }

//------Delete Si_new--------------------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) 
                delete [] Si_Dia_new_A[i]; 
        delete [] Si_Dia_new_A;           

	for(int i=0; i<A_Sys_Number_Jn[n_num]-1; i++)
		delete [] Si_M_Dia_new_A[i];
	delete [] Si_M_Dia_new_A;
}

//===============================================================================================================
//						Truncate B_Si operators
//===============================================================================================================
inline void ChiralCorrelation::Truncate_B_Si(const int &n_num) {
        char trans_N='N', trans_T='T';
        double alpha=1.0, beta=0.0;

//------Create space and define the operators of Si--------------------------------------------------------------
        Si_Dia_new_B=new double * [B_Sys_Number_Jn[n_num]];
        Si_M_Dia_new_B=new double * [B_Sys_Number_Jn[n_num]-1];

        for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                int Dia_Dim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i];
                Si_Dia_new_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_new_B[i][j]=0.0;
        }

        for(int i=0; i<B_Sys_Number_Jn[n_num]-1; i++) {
                int Dia_Dim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i+1];
                Si_M_Dia_new_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_new_B[i][j]=0.0;
        }

//------Truncate S_Dia operator----------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {

                int SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]*B_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, Si_Dia_old_B[B_OldSub[n_num][i]], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &B_Sys_SubBlockNumber_Jn[n_num][i], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, Si_Dia_new_B[i], &B_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Truncate S_M_Dia operator--------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]-1; i++)
        if((B_Sys_Value_Jn[n_num][i+1]-B_Sys_Value_Jn[n_num][i])==2 && (B_N_Sys_Value_Jn[n_num][B_OldSub[n_num][i+1]]-B_N_Sys_Value_Jn[n_num][B_OldSub[n_num][i]])==2) {
                int SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]*B_Sys_SubBlockNumber_Jn[n_num][i+1];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &B_Sys_SubBlockNumber_Jn[n_num][i+1], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i+1]], &alpha, Si_M_Dia_old_B[B_OldSub[n_num][i]], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], B[n_num][i+1], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i+1]], &beta, f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &B_Sys_SubBlockNumber_Jn[n_num][i], &B_Sys_SubBlockNumber_Jn[n_num][i+1], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, Si_M_Dia_new_B[i], &B_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Delete Si_old--------------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++)
                delete [] Si_Dia_old_B[i];
        delete [] Si_Dia_old_B;

        for(int i=0; i<B_N_Sys_Number_Jn[n_num]-1; i++)
                delete [] Si_M_Dia_old_B[i];
        delete [] Si_M_Dia_old_B;

//------Create new Si_old----------------------------------------------------------------------------------------
        Si_Dia_old_B=new double * [B_Sys_Number_Jn[n_num]];
        Si_M_Dia_old_B=new double * [B_Sys_Number_Jn[n_num]-1];

        for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                int Dia_Dim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i];
                Si_Dia_old_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_Dia_old_B[i][j]=Si_Dia_new_B[i][j];
        }

        for(int i=0; i<B_Sys_Number_Jn[n_num]-1; i++) {
                int Dia_Dim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i+1];
                Si_M_Dia_old_B[i]=new double [Dia_Dim];
                for(int j=0; j<Dia_Dim; j++)
                        Si_M_Dia_old_B[i][j]=Si_M_Dia_new_B[i][j];
        }

//------Delete Si_new--------------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]; i++)
                delete [] Si_Dia_new_B[i];
        delete [] Si_Dia_new_B;

        for(int i=0; i<B_Sys_Number_Jn[n_num]-1; i++)
                delete [] Si_M_Dia_new_B[i];
        delete [] Si_M_Dia_new_B;
}

//===============================================================================================================
//						Truncate A_SiSj operator
//===============================================================================================================
inline void ChiralCorrelation::Truncate_A_SiSj(const int &n_num) {
	int SubDim;
	char trans_N='N', trans_T='T';
	double alpha=1.0, beta=0.0;

//------Create space for A_SiSj_new------------------------------------------------------------------------------
	SiSj_new_A=new double * [A_Sys_Number_Jn[n_num]];
        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                SubDim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_new_A[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_new_A[i][j]=0.0;
        }

//------Truncate SiSj_old----------------------------------------------------------------------------------------
        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]*A_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, SiSj_old_A[A_OldSub[n_num][i]], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &A_Sys_SubBlockNumber_Jn[n_num][i], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, SiSj_new_A[i], &A_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Delete old SiSj_old--------------------------------------------------------------------------------------
	for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++)
		delete [] SiSj_old_A[i];
	delete [] SiSj_old_A;

//------Create new SiSj_old--------------------------------------------------------------------------------------
	SiSj_old_A=new double * [A_Sys_Number_Jn[n_num]];
        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {
                SubDim=A_Sys_SubBlockNumber_Jn[n_num][i]*A_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_A[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_A[i][j]=SiSj_new_A[i][j];
        }

//------Delete SiSj_new------------------------------------------------------------------------------------------
	for(int i=0; i<A_Sys_Number_Jn[n_num]; i++)
                delete [] SiSj_new_A[i];
        delete [] SiSj_new_A;
}

//===============================================================================================================
//						Truncate B_SiSj operator
//===============================================================================================================
inline void ChiralCorrelation::Truncate_B_SiSj(const int &n_num) {
        int SubDim;
        char trans_N='N', trans_T='T';
        double alpha=1.0, beta=0.0;

//------Create space for B_SiSj_new------------------------------------------------------------------------------
        SiSj_new_B=new double * [B_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_new_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_new_B[i][j]=0.0;
        }

//------Truncate SiSj_old----------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]*B_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, SiSj_old_B[B_OldSub[n_num][i]], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &B_Sys_SubBlockNumber_Jn[n_num][i], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, SiSj_new_B[i], &B_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }

//------Delete old SiSj_old--------------------------------------------------------------------------------------
	for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++)
                delete [] SiSj_old_B[i];
        delete [] SiSj_old_B;

//------Create new SiSj_old--------------------------------------------------------------------------------------
        SiSj_old_B=new double * [B_Sys_Number_Jn[n_num]];
        for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {
                SubDim=B_Sys_SubBlockNumber_Jn[n_num][i]*B_Sys_SubBlockNumber_Jn[n_num][i];
                SiSj_old_B[i]=new double [SubDim];
                for(int j=0; j<SubDim; j++)
                        SiSj_old_B[i][j]=SiSj_new_B[i][j];
        }

//------Delete SiSj_new------------------------------------------------------------------------------------------
	for(int i=0; i<B_Sys_Number_Jn[n_num]; i++)
                delete [] SiSj_new_B[i];
        delete [] SiSj_new_B;
}

//======delta_J=0, new A=========================================================================================
inline void ChiralCorrelation::CreateSpace_delta_J_zero_new_A(const int &num, double ***matrix) {

        int SubDim;
        (*matrix)=new double * [A_N_Sys_Number_Jn[num]];

        for(int i=0; i<A_N_Sys_Number_Jn[num]; i++) {

                SubDim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i];
                (*matrix)[i]=new double [SubDim];

                for(int j=0; j<SubDim; j++)
                        (*matrix)[i][j]=0.0;

        }

}

inline void ChiralCorrelation::FreeSpace_delta_J_zero_new_A(const int &num, double ***matrix) {
        for(int i=0; i<A_N_Sys_Number_Jn[num]; i++)
                delete [] (*matrix)[i];
        delete [] (*matrix);
}

//======delta_J=0, new B=========================================================================================
inline void ChiralCorrelation::CreateSpace_delta_J_zero_new_B(const int &num, double ***matrix) {
        int SubDim;
        (*matrix)=new double * [B_N_Sys_Number_Jn[num]];

        for(int i=0; i<B_N_Sys_Number_Jn[num]; i++) {

                SubDim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i];
                (*matrix)[i]=new double [SubDim];

                for(int j=0; j<SubDim; j++)
                        (*matrix)[i][j]=0.0;

        }
}

inline void ChiralCorrelation::FreeSpace_delta_J_zero_new_B(const int &num, double ***matrix) {
        for(int i=0; i<B_N_Sys_Number_Jn[num]; i++)
                delete [] (*matrix)[i];
        delete [] (*matrix);
}

//======delta_J=0, old B=========================================================================================
inline void ChiralCorrelation::CreateSpace_delta_J_zero_old_B(const int &num, double ***matrix) {
        int SubDim;
        (*matrix)=new double * [B_Sys_Number_Jn[num]];

        for(int i=0; i<B_Sys_Number_Jn[num]; i++) {

                SubDim=B_Sys_SubBlockNumber_Jn[num][i]*B_Sys_SubBlockNumber_Jn[num][i];
                (*matrix)[i]=new double [SubDim];

                for(int j=0; j<SubDim; j++)
                        (*matrix)[i][j]=0.0;

        }
}

inline void ChiralCorrelation::FreeSpace_delta_J_zero_old_B(const int &num, double ***matrix) {
        for(int i=0; i<B_Sys_Number_Jn[num]; i++)
                delete [] (*matrix)[i];
        delete [] (*matrix);
}

//=============================================New rank-1 with delta_J=0
inline void ChiralCorrelation::Initial_rank_one_delta_J_zero_A(Parameter &para, const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {

        int oldJn, oldJm, SubDim, position, a_new, a_new_t;
        double factor;

        for(int j=0; j<A_N_Sys_Number_Jn[n_num]; j++)
        if(A_N_Sys_Value_Jn[n_num][j]!=0) {

		double const_number=sqrt(3.0)*(A_N_Sys_Value_Jn[n_num][j]+1.0)*constant;

                for(int m=0; m<para.S+1; m++)
                for(int n=0; n<para.S+1; n++)
                if((oldJm=A_N_IndexOld[n_num][m][j])!=-1 && (oldJn=A_N_IndexOld[n_num][n][j])!=-1) {

                	if(oldJn-oldJm==1 && A_Sys_Value_Jn[n_num-1][oldJn]-A_Sys_Value_Jn[n_num-1][oldJm]==2) {

                        	position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][n][j]+A_N_Start[n_num][m][j];
                                factor=const_number*gsl_sf_coupling_9j(A_Sys_Value_Jn[n_num-1][oldJm], A_Sys_Value_Jn[n_num-1][oldJn], 2, para.S, para.S, 2, A_N_Sys_Value_Jn[n_num][j], A_N_Sys_Value_Jn[n_num][j], 2);
                                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                	a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        a_new_t=A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_new%A_N_Sys_SubBlockNumber_Jn[n_num][j])+a_new/A_N_Sys_SubBlockNumber_Jn[n_num][j];
                                        (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJm][a_old];
                                        (*new_op)[j][a_new_t]+=phase*factor*(*old_M_Dia_op)[oldJm][a_old];
                                }

                        }

                }

        }

}

//==================================================================================================================
inline void ChiralCorrelation::CreateSpace_delta_J_zero_old_A(const int &num, double ***matrix) {
        int SubDim;
        (*matrix)=new double * [A_Sys_Number_Jn[num]];

        for(int i=0; i<A_Sys_Number_Jn[num]; i++) {

                SubDim=A_Sys_SubBlockNumber_Jn[num][i]*A_Sys_SubBlockNumber_Jn[num][i];
                (*matrix)[i]=new double [SubDim];

                for(int j=0; j<SubDim; j++)
                        (*matrix)[i][j]=0.0;

        }
}

inline void ChiralCorrelation::FreeSpace_delta_J_zero_old_A(const int &num, double ***matrix) {
        for(int i=0; i<A_Sys_Number_Jn[num]; i++)
                delete [] (*matrix)[i];
        delete [] (*matrix);
}

//===================================================================================================================
inline void ChiralCorrelation::Truncate_delta_J_zero_A(const int &n_num, double ***new_op, double ***old_op) {
        char trans_N='N', trans_T='T';
        double alpha=1.0, beta=0.0;

//------Truncate rank_zero_new_A----------------------------------------------------------------------------------
        for(int i=0; i<A_Sys_Number_Jn[n_num]; i++) {

                int SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]*A_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, (*old_op)[A_OldSub[n_num][i]], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &A_Sys_SubBlockNumber_Jn[n_num][i], &A_Sys_SubBlockNumber_Jn[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, (*new_op)[i], &A_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }
}

//===============================================================================================================
//                                            Truncate_delta_J_zero_B
//===============================================================================================================
inline void ChiralCorrelation::Truncate_delta_J_zero_B(const int &n_num, double ***new_op, double ***old_op) {
        char trans_N='N', trans_T='T';
        double alpha=1.0, beta=0.0;

//------Truncate rank_zero_new_B----------------------------------------------------------------------------------
        for(int i=0; i<B_Sys_Number_Jn[n_num]; i++) {

                int SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]*B_Sys_SubBlockNumber_Jn[n_num][i];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, (*old_op)[B_OldSub[n_num][i]], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &B_Sys_SubBlockNumber_Jn[n_num][i], &B_Sys_SubBlockNumber_Jn[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, (*new_op)[i], &B_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
	}
}

//====================================================================================================================
inline void ChiralCorrelation::Initial_rank_one_delta_J_one_A(Parameter &para, const int &n_num, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {

        int oldJn, oldJm, position, SubDim, a_new;
        double factor;

        for(int j=0; j<A_N_Sys_Number_Jn[n_num]-1; j++)
        if(A_N_Sys_Value_Jn[n_num][j+1]-A_N_Sys_Value_Jn[n_num][j]==2) {

	        double const_number=sqrt(3.0*(A_N_Sys_Value_Jn[n_num][j]+1.0)*(A_N_Sys_Value_Jn[n_num][j+1]+1.0))*constant;

                for(int m=0; m<para.S+1; m++)
                for(int n=0; n<para.S+1; n++)
                if((oldJm=A_N_IndexOld[n_num][m][j])!=-1 && (oldJn=A_N_IndexOld[n_num][n][j+1])!=-1) {

                	if(oldJn==oldJm && A_Sys_Value_Jn[n_num-1][oldJm]!=0) {

                        	position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][n][j+1]+A_N_Start[n_num][m][j];
                                factor=const_number*gsl_sf_coupling_9j(A_Sys_Value_Jn[n_num-1][oldJm], A_Sys_Value_Jn[n_num-1][oldJn], 2, para.S, para.S, 2, A_N_Sys_Value_Jn[n_num][j], A_N_Sys_Value_Jn[n_num][j+1], 2);
                                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                	a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_Dia_op)[oldJm][a_old];
                                 }
                        }

                        else if(oldJn-oldJm==1 && A_Sys_Value_Jn[n_num-1][oldJn]-A_Sys_Value_Jn[n_num-1][oldJm]==2) {

                        	position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][n][j+1]+A_N_Start[n_num][m][j];
                                factor=const_number*gsl_sf_coupling_9j(A_Sys_Value_Jn[n_num-1][oldJm], A_Sys_Value_Jn[n_num-1][oldJn], 2, para.S, para.S, 2, A_N_Sys_Value_Jn[n_num][j], A_N_Sys_Value_Jn[n_num][j+1], 2);
                                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                	a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJm][a_old];
                                }
                        }

                        else if(oldJm-oldJn==1 && A_Sys_Value_Jn[n_num-1][oldJm]-A_Sys_Value_Jn[n_num-1][oldJn]==2) {

	                        position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][n][j+1]+A_N_Start[n_num][m][j];
                                factor=const_number*gsl_sf_coupling_9j(A_Sys_Value_Jn[n_num-1][oldJm], A_Sys_Value_Jn[n_num-1][oldJn], 2, para.S, para.S, 2, A_N_Sys_Value_Jn[n_num][j], A_N_Sys_Value_Jn[n_num][j+1], 2);
                                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];

                                for(int a_old=0; a_old<SubDim; a_old++) {
	                                a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                        (*new_op)[j][a_new]+=-factor*(*old_M_Dia_op)[oldJn][a_old];
                                }
                        }

        	}

	} 

}

//===============================================================================================================
//                                     Initialize rank_one_delta_J_one_B
//===============================================================================================================
inline void ChiralCorrelation::Initial_rank_one_delta_J_one_B(Parameter &para, const int &n_num, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {

        int oldJn, oldJm, position, SubDim, a_new;
        double factor;

       	for(int j=0; j<B_N_Sys_Number_Jn[n_num]-1; j++)
       	if(B_N_Sys_Value_Jn[n_num][j+1]-B_N_Sys_Value_Jn[n_num][j]==2) {

       		double const_number=sqrt(3.0*(B_N_Sys_Value_Jn[n_num][j]+1.0)*(B_N_Sys_Value_Jn[n_num][j+1]+1.0))*constant;

       		for(int m=0; m<para.S+1; m++)
       		for(int n=0; n<para.S+1; n++)
        	if((oldJm=B_N_IndexOld[n_num][m][j])!=-1 && (oldJn=B_N_IndexOld[n_num][n][j+1])!=-1) {

	                if(oldJn==oldJm && B_Sys_Value_Jn[n_num-1][oldJm]!=0) {

       	                	position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][n][j+1]+B_N_Start[n_num][m][j];
                                factor=const_number*gsl_sf_coupling_9j(B_Sys_Value_Jn[n_num-1][oldJm], B_Sys_Value_Jn[n_num-1][oldJn], 2, para.S, para.S, 2, B_N_Sys_Value_Jn[n_num][j], B_N_Sys_Value_Jn[n_num][j+1], 2);
                                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                	a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_Dia_op)[oldJm][a_old];
                                }

			}

                        else if(oldJn-oldJm==1 && B_Sys_Value_Jn[n_num-1][oldJn]-B_Sys_Value_Jn[n_num-1][oldJm]==2) {

                        	position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][n][j+1]+B_N_Start[n_num][m][j];
                                factor=const_number*gsl_sf_coupling_9j(B_Sys_Value_Jn[n_num-1][oldJm], B_Sys_Value_Jn[n_num-1][oldJn], 2, para.S, para.S, 2, B_N_Sys_Value_Jn[n_num][j], B_N_Sys_Value_Jn[n_num][j+1], 2);
                                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                	a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJm][a_old];
                                }

			}

                        else if(oldJm-oldJn==1 && B_Sys_Value_Jn[n_num-1][oldJm]-B_Sys_Value_Jn[n_num-1][oldJn]==2) {

                        	position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][n][j+1]+B_N_Start[n_num][m][j];
                                factor=const_number*gsl_sf_coupling_9j(B_Sys_Value_Jn[n_num-1][oldJm], B_Sys_Value_Jn[n_num-1][oldJn], 2, para.S, para.S, 2, B_N_Sys_Value_Jn[n_num][j], B_N_Sys_Value_Jn[n_num][j+1], 2);
                                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                	a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                        (*new_op)[j][a_new]+=-factor*(*old_M_Dia_op)[oldJn][a_old];
                                }

                	}

                }

	}

}

//===============================================================================================================
//                                     Initialize rank_one_delta_J_zero_B
//===============================================================================================================
inline void ChiralCorrelation::Initial_rank_one_delta_J_zero_B(Parameter &para, const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {

        int oldJn, oldJm, position, SubDim, a_new, a_new_t;
        double factor;

        for(int j=0; j<B_N_Sys_Number_Jn[n_num]; j++)
        if(B_N_Sys_Value_Jn[n_num][j]!=0) {     //constraint of 9j coefficient

	        double const_number=sqrt(3.0)*(B_N_Sys_Value_Jn[n_num][j]+1.0)*constant;

       	        for(int m=0; m<para.S+1; m++)
               	for(int n=0; n<para.S+1; n++)
               	if((oldJm=B_N_IndexOld[n_num][m][j])!=-1 && (oldJn=B_N_IndexOld[n_num][n][j])!=-1) {

                	if(oldJn-oldJm==1 && B_Sys_Value_Jn[n_num-1][oldJn]-B_Sys_Value_Jn[n_num-1][oldJm]==2) {

                        	position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][n][j]+B_N_Start[n_num][m][j];
                               	factor=const_number*gsl_sf_coupling_9j(B_Sys_Value_Jn[n_num-1][oldJm], B_Sys_Value_Jn[n_num-1][oldJn], 2, para.S, para.S, 2, B_N_Sys_Value_Jn[n_num][j], B_N_Sys_Value_Jn[n_num][j], 2);
                               	SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                               	for(int a_old=0; a_old<SubDim; a_old++) {
       	                        	a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
        	                        a_new_t=B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_new%B_N_Sys_SubBlockNumber_Jn[n_num][j])+a_new/B_N_Sys_SubBlockNumber_Jn[n_num][j];
               	                       	(*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJm][a_old];
                       	               	(*new_op)[j][a_new_t]+=phase*factor*(*old_M_Dia_op)[oldJm][a_old];
                                }

                       	}

               	}

       	}
}

//===============================================================================================================
inline void ChiralCorrelation::CreateSpace_delta_J_one_old_A(const int &num, double ***matrix) {
        int SubDim;
        (*matrix)=new double * [A_Sys_Number_Jn[num]-1];

        for(int i=0; i<A_Sys_Number_Jn[num]-1; i++) {

                SubDim=A_Sys_SubBlockNumber_Jn[num][i]*A_Sys_SubBlockNumber_Jn[num][i+1];
                (*matrix)[i]=new double [SubDim];

                for(int j=0; j<SubDim; j++)
                        (*matrix)[i][j]=0.0;
        }
}

inline void ChiralCorrelation::FreeSpace_delta_J_one_old_A(const int &num, double ***matrix) {
        for(int i=0; i<A_Sys_Number_Jn[num]-1; i++)
                delete [] (*matrix)[i];
        delete [] (*matrix);
}

//==============================================================================================
inline void ChiralCorrelation::CreateSpace_delta_J_one_new_A(const int &num, double ***matrix) {
        int SubDim;
        (*matrix)=new double * [A_N_Sys_Number_Jn[num]-1];

        for(int i=0; i<A_N_Sys_Number_Jn[num]-1; i++) {

                SubDim=A_N_Sys_SubBlockNumber_Jn[num][i]*A_N_Sys_SubBlockNumber_Jn[num][i+1];
                (*matrix)[i]=new double [SubDim];

                for(int j=0; j<SubDim; j++)
                        (*matrix)[i][j]=0.0;
        }
}

inline void ChiralCorrelation::FreeSpace_delta_J_one_new_A(const int &num, double ***matrix) {
        for(int i=0; i<A_N_Sys_Number_Jn[num]-1; i++)
                delete [] (*matrix)[i];
        delete [] (*matrix);
}

//======delta_J=1, new B=========================================================================================
inline void ChiralCorrelation::CreateSpace_delta_J_one_new_B(const int &num, double ***matrix) {
        int SubDim;
        (*matrix)=new double * [B_N_Sys_Number_Jn[num]-1];

        for(int i=0; i<B_N_Sys_Number_Jn[num]-1; i++) {

                SubDim=B_N_Sys_SubBlockNumber_Jn[num][i]*B_N_Sys_SubBlockNumber_Jn[num][i+1];
                (*matrix)[i]=new double [SubDim];

                for(int j=0; j<SubDim; j++)
                        (*matrix)[i][j]=0.0;
        }
}

inline void ChiralCorrelation::FreeSpace_delta_J_one_new_B(const int &num, double ***matrix) {
        for(int i=0; i<B_N_Sys_Number_Jn[num]-1; i++)
                delete [] (*matrix)[i];
        delete [] (*matrix);
}

//======delta_J=1, old B=========================================================================================
inline void ChiralCorrelation::CreateSpace_delta_J_one_old_B(const int &num, double ***matrix) {
        int SubDim;
        (*matrix)=new double * [B_Sys_Number_Jn[num]-1];

        for(int i=0; i<B_Sys_Number_Jn[num]-1; i++) {

                SubDim=B_Sys_SubBlockNumber_Jn[num][i]*B_Sys_SubBlockNumber_Jn[num][i+1];
                (*matrix)[i]=new double [SubDim];

                for(int j=0; j<SubDim; j++)
                        (*matrix)[i][j]=0.0;
        }
}

inline void ChiralCorrelation::FreeSpace_delta_J_one_old_B(const int &num, double ***matrix) {
        for(int i=0; i<B_Sys_Number_Jn[num]-1; i++)
                delete [] (*matrix)[i];
        delete [] (*matrix);
}

//=================================================================================================================
inline void ChiralCorrelation::Truncate_delta_J_one_A(const int &n_num, double ***new_op, double ***old_op) {
        char trans_N='N', trans_T='T';
        double alpha=1.0, beta=0.0;

        for(int i=0; i<A_Sys_Number_Jn[n_num]-1; i++)
        if((A_Sys_Value_Jn[n_num][i+1]-A_Sys_Value_Jn[n_num][i])==2 && (A_N_Sys_Value_Jn[n_num][A_OldSub[n_num][i+1]]-A_N_Sys_Value_Jn[n_num][A_OldSub[n_num][i]])==2) {
                int SubDim=A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]*A_Sys_SubBlockNumber_Jn[n_num][i+1];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &A_Sys_SubBlockNumber_Jn[n_num][i+1], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i+1]], &alpha, (*old_op)[A_OldSub[n_num][i]], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], A[n_num][i+1], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i+1]], &beta, f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &A_Sys_SubBlockNumber_Jn[n_num][i], &A_Sys_SubBlockNumber_Jn[n_num][i+1], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &alpha, A[n_num][i], &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], f_sub, &A_N_Sys_SubBlockNumber_Jn[n_num][A_OldSub[n_num][i]], &beta, (*new_op)[i], &A_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }
}

//===============================================================================================================
//                                             Truncate delta_J_one_B
//===============================================================================================================
inline void ChiralCorrelation::Truncate_delta_J_one_B(const int &n_num, double ***new_op, double ***old_op) {
        char trans_N='N', trans_T='T';
        double alpha=1.0, beta=0.0;

        for(int i=0; i<B_Sys_Number_Jn[n_num]-1; i++)
        if((B_Sys_Value_Jn[n_num][i+1]-B_Sys_Value_Jn[n_num][i])==2 && (B_N_Sys_Value_Jn[n_num][B_OldSub[n_num][i+1]]-B_N_Sys_Value_Jn[n_num][B_OldSub[n_num][i]])==2) {
                int SubDim=B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]*B_Sys_SubBlockNumber_Jn[n_num][i+1];

                double * f_sub=new double [SubDim];
                for(int j=0; j<SubDim; j++)     f_sub[j]=(double) 0;

                dgemm_(&trans_N, &trans_N, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &B_Sys_SubBlockNumber_Jn[n_num][i+1], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i+1]], &alpha, (*old_op)[B_OldSub[n_num][i]], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], B[n_num][i+1], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i+1]], &beta, f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]]);

                dgemm_(&trans_T, &trans_N, &B_Sys_SubBlockNumber_Jn[n_num][i], &B_Sys_SubBlockNumber_Jn[n_num][i+1], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &alpha, B[n_num][i], &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], f_sub, &B_N_Sys_SubBlockNumber_Jn[n_num][B_OldSub[n_num][i]], &beta, (*new_op)[i], &B_Sys_SubBlockNumber_Jn[n_num][i]);

                delete [] f_sub;
        }
}

//===============================================================================================================
//                                      New_rank_one_delta_J_zero_A
//===============================================================================================================
inline void ChiralCorrelation::New_rank_one_delta_J_zero_A(Parameter &para, const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {
        int oldJn, oldJm, position, SubDim, a_new, a_new_t;
        double factor;


        for(int j=0; j<A_N_Sys_Number_Jn[n_num]; j++)
        if(A_N_Sys_Value_Jn[n_num][j]!=0) {

                for(int m=0; m<para.S+1; m++)
                for(int n=0; n<para.S+1; n++)
                if((oldJm=A_N_IndexOld[n_num][m][j])!=-1 && (oldJn=A_N_IndexOld[n_num][n][j])!=-1) {

                        if(oldJm==oldJn && A_Sys_Value_Jn[n_num-1][oldJm]!=0) {

                                position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][n][j]+A_N_Start[n_num][m][j];
                                factor=(A_N_Sys_Value_Jn[n_num][j]+1.0)*A_six_j_S_Dia_old[n_num-1][oldJm][oldJm][j];
                                int sign=(A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJm]+2+para.S)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_Dia_op)[oldJm][a_old];
                                }

                        }

                        else if(oldJn-oldJm==1 && A_Sys_Value_Jn[n_num-1][oldJn]-A_Sys_Value_Jn[n_num-1][oldJm]==2) {

                                position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][n][j]+A_N_Start[n_num][m][j];
                                factor=(A_N_Sys_Value_Jn[n_num][j]+1.0)*A_six_j_S_Dia_old[n_num-1][oldJn][oldJm][j];
                                int sign=(A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJm]+2+para.S)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        a_new_t=A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_new%A_N_Sys_SubBlockNumber_Jn[n_num][j])+a_new/A_N_Sys_SubBlockNumber_Jn[n_num][j];
                                        (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJm][a_old];
                                        (*new_op)[j][a_new_t]+=-phase*factor*(*old_M_Dia_op)[oldJm][a_old];
                                }
                        }

                }

        }
}

//===============================================================================================================
//                                      New_rank_one_delta_J_zero_B
//===============================================================================================================
inline void ChiralCorrelation::New_rank_one_delta_J_zero_B(Parameter &para, const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {
        int oldJn, oldJm, position, SubDim, a_new, a_new_t;
        double factor;

//------Initialize rank_one_delta_J_zero_B-----------------------------------------------------------------------
        for(int j=0; j<B_N_Sys_Number_Jn[n_num]; j++)
        if(B_N_Sys_Value_Jn[n_num][j]!=0) {

                for(int m=0; m<para.S+1; m++)
                for(int n=0; n<para.S+1; n++)
                if((oldJm=B_N_IndexOld[n_num][m][j])!=-1 && (oldJn=B_N_IndexOld[n_num][n][j])!=-1) {

                        if(oldJm==oldJn && B_Sys_Value_Jn[n_num-1][oldJm]!=0) {

                                position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][n][j]+B_N_Start[n_num][m][j];
                                factor=(B_N_Sys_Value_Jn[n_num][j]+1.0)*B_six_j_S_Dia_old[n_num-1][oldJm][oldJm][j];
                                int sign=(B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJm]+para.S+2)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_Dia_op)[oldJm][a_old];
                                }

                        }

                       else if(oldJn-oldJm==1 && B_Sys_Value_Jn[n_num-1][oldJn]-B_Sys_Value_Jn[n_num-1][oldJm]==2) {

                                position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][n][j]+B_N_Start[n_num][m][j];
                                factor=(B_N_Sys_Value_Jn[n_num][j]+1.0)*B_six_j_S_Dia_old[n_num-1][oldJn][oldJm][j];
                                int sign=(B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJm]+2+para.S)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        a_new_t=B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_new%B_N_Sys_SubBlockNumber_Jn[n_num][j])+a_new/B_N_Sys_SubBlockNumber_Jn[n_num][j];
                                        (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJm][a_old];
                                        (*new_op)[j][a_new_t]+=-phase*factor*(*old_M_Dia_op)[oldJm][a_old];
                                }
                        }

                }

        }
}

//===============================================================================================================
//                                      New rank_one_delta_J_one_A
//===============================================================================================================
inline void ChiralCorrelation::New_rank_one_delta_J_one_A(Parameter &para, const int &n_num, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {
        int oldJn, oldJm, position, SubDim, a_new;
        double factor;


        for(int j=0; j<A_N_Sys_Number_Jn[n_num]-1; j++)
        if(A_N_Sys_Value_Jn[n_num][j+1]-A_N_Sys_Value_Jn[n_num][j]==2) {

                double const_number=sqrt((A_N_Sys_Value_Jn[n_num][j]+1.0)*(A_N_Sys_Value_Jn[n_num][j+1]+1.0));

                for(int m=0; m<para.S+1; m++)
                for(int n=0; n<para.S+1; n++)
                if((oldJm=A_N_IndexOld[n_num][m][j])!=-1 && (oldJn=A_N_IndexOld[n_num][n][j+1])!=-1) {

                        if(oldJn==oldJm && A_Sys_Value_Jn[n_num-1][oldJm]!=0) {

                                position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][n][j+1]+A_N_Start[n_num][m][j];
                                factor=const_number*A_six_j_S_M_Dia_old[n_num-1][oldJm][oldJn][j];
                                int sign=(A_N_Sys_Value_Jn[n_num][j+1]+A_Sys_Value_Jn[n_num-1][oldJm]+2+para.S)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_Dia_op)[oldJm][a_old];
                                }
                        }

                        else if(oldJn-oldJm==1 && A_Sys_Value_Jn[n_num-1][oldJn]-A_Sys_Value_Jn[n_num-1][oldJm]==2) {

                                position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][n][j+1]+A_N_Start[n_num][m][j];
                                factor=const_number*A_six_j_S_M_Dia_old[n_num-1][oldJm][oldJn][j];
                                int sign=(A_N_Sys_Value_Jn[n_num][j+1]+A_Sys_Value_Jn[n_num-1][oldJm]+2+para.S)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJm][a_old];
                                }
                        }

                        else if(oldJm-oldJn==1 && A_Sys_Value_Jn[n_num-1][oldJm]-A_Sys_Value_Jn[n_num-1][oldJn]==2) {

                                position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][n][j+1]+A_N_Start[n_num][m][j];
                                factor=const_number*A_six_j_S_M_Dia_old[n_num-1][oldJm][oldJn][j];
                                int sign=(A_N_Sys_Value_Jn[n_num][j+1]+A_Sys_Value_Jn[n_num-1][oldJm]+2+para.S)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                        (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJn][a_old];
                                }
                        }

		}
        }
}

//===============================================================================================================
//                                      New rank_one_delta_J_one_B
//===============================================================================================================
inline void ChiralCorrelation::New_rank_one_delta_J_one_B(Parameter &para, const int &n_num, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {
        int oldJn, oldJm, position, SubDim, a_new;
        double factor;

//------Initialize rank_one_delta_J_one_B-------------------------------------------------------------------------
        for(int j=0; j<B_N_Sys_Number_Jn[n_num]-1; j++)
        if(B_N_Sys_Value_Jn[n_num][j+1]-B_N_Sys_Value_Jn[n_num][j]==2) {

                double const_number=sqrt((B_N_Sys_Value_Jn[n_num][j]+1.0)*(B_N_Sys_Value_Jn[n_num][j+1]+1.0));

                for(int m=0; m<para.S+1; m++)
                for(int n=0; n<para.S+1; n++)
                if((oldJm=B_N_IndexOld[n_num][m][j])!=-1 && (oldJn=B_N_IndexOld[n_num][n][j+1])!=-1) {

                        if(oldJn==oldJm && B_Sys_Value_Jn[n_num-1][oldJm]!=0) {

                                position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][n][j+1]+B_N_Start[n_num][m][j];
                                factor=const_number*B_six_j_S_M_Dia_old[n_num-1][oldJm][oldJn][j];
                                int sign=(B_N_Sys_Value_Jn[n_num][j+1]+B_Sys_Value_Jn[n_num-1][oldJm]+2+para.S)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_Dia_op)[oldJm][a_old];
                                }
                        }

                        else if(oldJn-oldJm==1 && B_Sys_Value_Jn[n_num-1][oldJn]-B_Sys_Value_Jn[n_num-1][oldJm]==2) {

                                position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][n][j+1]+B_N_Start[n_num][m][j];
                                factor=const_number*B_six_j_S_M_Dia_old[n_num-1][oldJm][oldJn][j];
                                int sign=(B_N_Sys_Value_Jn[n_num][j+1]+B_Sys_Value_Jn[n_num-1][oldJm]+2+para.S)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJm])+a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                                        (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJm][a_old];
                                }
                        }

                        else if(oldJm-oldJn==1 && B_Sys_Value_Jn[n_num-1][oldJm]-B_Sys_Value_Jn[n_num-1][oldJn]==2) {

                                position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][n][j+1]+B_N_Start[n_num][m][j];
                                factor=const_number*B_six_j_S_M_Dia_old[n_num-1][oldJm][oldJn][j];
                                int sign=(B_N_Sys_Value_Jn[n_num][j+1]+B_Sys_Value_Jn[n_num-1][oldJm]+2+para.S)/2;
                                if(sign%2==1)   factor=-factor;
                                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJm]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];

                                for(int a_old=0; a_old<SubDim; a_old++) {
                                        a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                        (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJn][a_old];
                                }
                        }

                }

        }
}

//===============================================================================================================
//                       Initial_rank_zero_A: rank_zero can only be obtained by couple 1 and 1
//===============================================================================================================
inline void ChiralCorrelation::Initial_rank_zero_A(Parameter &para, const int &n_num, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {

        int oldJn, oldJm, position, SubDim, a_new, a_new_t;
        double factor;

//------Initialize rank_zero_new_A--------------------------------------------------------------------------------
        for(int j=0; j<A_N_Sys_Number_Jn[n_num]; j++)
        for(int n=0; n<para.S+1; n++)
        for(int m=0; m<para.S+1; m++)
        if((oldJn=A_N_IndexOld[n_num][n][j])!=-1)
        if((oldJm=A_N_IndexOld[n_num][m][j])!=-1) {
                if(oldJn==oldJm && A_Sys_Value_Jn[n_num-1][oldJn]!=0) {
                        position=(A_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*A_N_Start[n_num][n][j];
                        factor=pow(-1.0,(A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJn]+para.S)/2)*constant*A_six_j_H[n_num-1][oldJn][oldJn][j];
                        SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                (*new_op)[j][a_new]+=factor*(*old_Dia_op)[oldJn][a_sys];
                        }
                }

                else if(oldJm-oldJn==1 && A_Sys_Value_Jn[n_num-1][oldJm]-A_Sys_Value_Jn[n_num-1][oldJn]==2) {
                        position=A_N_Sys_SubBlockNumber_Jn[n_num][j]*A_N_Start[n_num][m][j]+A_N_Start[n_num][n][j];
                        factor=pow(-1.0,(A_N_Sys_Value_Jn[n_num][j]+A_Sys_Value_Jn[n_num-1][oldJm]+para.S)/2)*constant*A_six_j_H[n_num-1][oldJn][oldJm][j];
                        SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                a_new_t=A_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_new%A_N_Sys_SubBlockNumber_Jn[n_num][j])+a_new/A_N_Sys_SubBlockNumber_Jn[n_num][j];
                                (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJn][a_sys];
                                (*new_op)[j][a_new_t]+=-factor*(*old_M_Dia_op)[oldJn][a_sys];
                        }

                }

        }

}

//===============================================================================================================
//                                          Initial_rank_zero_B
//===============================================================================================================
inline void ChiralCorrelation::Initial_rank_zero_B(Parameter &para, const int &n_num, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op) {

        int oldJn, oldJm, position, SubDim, a_new, a_new_t;
        double factor;

//------Initialize rank_zero_new_B--------------------------------------------------------------------------------
        for(int j=0; j<B_N_Sys_Number_Jn[n_num]; j++)
        for(int n=0; n<para.S+1; n++)
        for(int m=0; m<para.S+1; m++)
        if((oldJn=B_N_IndexOld[n_num][n][j])!=-1)
        if((oldJm=B_N_IndexOld[n_num][m][j])!=-1) {
                if(oldJn==oldJm && B_Sys_Value_Jn[n_num-1][oldJm]!=0) {
                        position=(B_N_Sys_SubBlockNumber_Jn[n_num][j]+1)*B_N_Start[n_num][n][j];
			factor=pow(-1.0,(B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJn]+para.S)/2)*constant*B_six_j_H[n_num-1][oldJn][oldJn][j];
                        SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                (*new_op)[j][a_new]+=factor*(*old_Dia_op)[oldJn][a_sys];
                        }
                }

               	else if(oldJm-oldJn==1 && B_Sys_Value_Jn[n_num-1][oldJm]-B_Sys_Value_Jn[n_num-1][oldJn]==2) {
                        position=B_N_Sys_SubBlockNumber_Jn[n_num][j]*B_N_Start[n_num][m][j]+B_N_Start[n_num][n][j];
                        factor=pow(-1.0,(B_N_Sys_Value_Jn[n_num][j]+B_Sys_Value_Jn[n_num-1][oldJm]+para.S)/2)*constant*B_six_j_H[n_num-1][oldJn][oldJm][j];
                        SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJm];
                        for(int a_sys=0; a_sys<SubDim; a_sys++) {
                                a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_sys/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_sys%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                                a_new_t=B_N_Sys_SubBlockNumber_Jn[n_num][j]*(a_new%B_N_Sys_SubBlockNumber_Jn[n_num][j])+a_new/B_N_Sys_SubBlockNumber_Jn[n_num][j];
                                (*new_op)[j][a_new]+=factor*(*old_M_Dia_op)[oldJn][a_sys];
                                (*new_op)[j][a_new_t]+=-factor*(*old_M_Dia_op)[oldJn][a_sys];
                        }

                }

        }
}

//===============================================================================================================
//                                              New_rank_zero_A
//===============================================================================================================
inline void ChiralCorrelation::New_rank_zero_A(Parameter &para, const int &n_num, double ***new_op, double ***old_op) {
        int oldJn, position, SubDim, a_new;

//------New rank_zero_new_A---------------------------------------------------------------------------------------
        for(int i=0; i<A_N_Sys_Number_Jn[n_num]; i++)
        for(int n=0; n<para.S+1; n++)
        if((oldJn=A_N_IndexOld[n_num][n][i])!=-1) {
                position=(A_N_Sys_SubBlockNumber_Jn[n_num][i]+1)*A_N_Start[n_num][n][i];
                SubDim=A_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                for(int a_old=0; a_old<SubDim; a_old++) {
                        a_new=position+A_N_Sys_SubBlockNumber_Jn[n_num][i]*(a_old/A_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_old%A_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        (*new_op)[i][a_new]+=(*old_op)[oldJn][a_old];
                }

        }

}

//===============================================================================================================
//                                              New_rank_zero_B
//===============================================================================================================
inline void ChiralCorrelation::New_rank_zero_B(Parameter &para, const int &n_num, double ***new_op, double ***old_op) {
        int oldJn, position, SubDim, a_new;

//------New rank_zero_new_B---------------------------------------------------------------------------------------
        for(int i=0; i<B_N_Sys_Number_Jn[n_num]; i++)
        for(int n=0; n<para.S+1; n++)
        if((oldJn=B_N_IndexOld[n_num][n][i])!=-1) {
                position=(B_N_Sys_SubBlockNumber_Jn[n_num][i]+1)*B_N_Start[n_num][n][i];
                SubDim=B_Sys_SubBlockNumber_Jn[n_num-1][oldJn]*B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                for(int a_old=0; a_old<SubDim; a_old++) {
                        a_new=position+B_N_Sys_SubBlockNumber_Jn[n_num][i]*(a_old/B_Sys_SubBlockNumber_Jn[n_num-1][oldJn])+a_old%B_Sys_SubBlockNumber_Jn[n_num-1][oldJn];
                        (*new_op)[i][a_new]+=(*old_op)[oldJn][a_old];
                }

        }
}

//===============================================================================================================
//						Delete WaveFunctions
//===============================================================================================================
inline void ChiralCorrelation::DeleteFunction(Super &sup) {
        for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++)
                delete [] WaveFunction_block[i];
        delete [] WaveFunction_block;

	for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++)
		delete [] WaveFunction_config_2[i];
	delete [] WaveFunction_config_2;

	for(int i=0; i<sup.BlockNumber_for_TargetSpin_config_3; i++)
		delete [] WaveFunction_config_3[i];
	delete [] WaveFunction_config_3;
}

//===============================================================================================================
//					Delete the created space
//===============================================================================================================
inline void ChiralCorrelation::DeleteSpace(const int &lsys, Parameter &para) {
	int A_site=lsys;
	int B_site=para.N-lsys-2;

//------Delete A_6j coefficients---------------------------------------------------------------------------------
   //---A_six_j_S_Dia_old----------------------------------------------------------------------------------------
	for(int i=0; i<A_site-1; i++) {
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			for(int k=0; k<A_Sys_Number_Jn[i]; k++) {
				delete [] A_six_j_S_Dia_old[i][j][k];
			}
			delete [] A_six_j_S_Dia_old[i][j];
		}
		delete [] A_six_j_S_Dia_old[i];
	}
	delete [] A_six_j_S_Dia_old;

   //---A_six_j_S_Dia_n------------------------------------------------------------------------------------------
	for(int i=0; i<A_site-1; i++) {
		for(int j=0; j<A_N_Sys_Number_Jn[i+1]; j++) {
			delete [] A_six_j_S_Dia_n[i][j];
		}
		delete [] A_six_j_S_Dia_n[i];
	}
	delete [] A_six_j_S_Dia_n;

   //---A_six_j_S_M_Dia_old--------------------------------------------------------------------------------------
   	for(int i=0; i<A_site-1; i++) {
                for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
                        for(int k=0; k<A_Sys_Number_Jn[i]; k++) {
                                delete [] A_six_j_S_M_Dia_old[i][j][k];
                        }
                        delete [] A_six_j_S_M_Dia_old[i][j];
                }
                delete [] A_six_j_S_M_Dia_old[i];
        }
        delete [] A_six_j_S_M_Dia_old;
  
   //---A_six_j_S_M_Dia_n----------------------------------------------------------------------------------------
	for(int i=0; i<A_site-1; i++) {
                for(int j=0; j<A_N_Sys_Number_Jn[i+1]-1; j++) {
                        delete [] A_six_j_S_M_Dia_n[i][j];
                }
                delete [] A_six_j_S_M_Dia_n[i];
        }
        delete [] A_six_j_S_M_Dia_n;

   //---A_six_j_H------------------------------------------------------------------------------------------------
   	for(int i=0; i<A_site-1; i++) {
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			for(int k=0; k<A_Sys_Number_Jn[i]; k++) {
				delete [] A_six_j_H[i][j][k];
			}
			delete [] A_six_j_H[i][j];
		}
		delete [] A_six_j_H[i];
	}
	delete [] A_six_j_H;

//------Delete B_6j coefficients---------------------------------------------------------------------------------
   //---B_six_j_S_Dia_old----------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
        	for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                	for(int k=0; k<B_Sys_Number_Jn[i]; k++) {
                        	delete [] B_six_j_S_Dia_old[i][j][k];
                        }
                        delete [] B_six_j_S_Dia_old[i][j];
                }
                delete [] B_six_j_S_Dia_old[i];
        }
        delete [] B_six_j_S_Dia_old;

   //---B_six_j_S_Dia_n------------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]; j++) {
                        delete [] B_six_j_S_Dia_n[i][j];
                }
                delete [] B_six_j_S_Dia_n[i];
        }
        delete [] B_six_j_S_Dia_n;

   //---B_six_j_S_M_Dia_old--------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++) {
                                delete [] B_six_j_S_M_Dia_old[i][j][k];
                        }
                        delete [] B_six_j_S_M_Dia_old[i][j];
                }
                delete [] B_six_j_S_M_Dia_old[i];
        }
        delete [] B_six_j_S_M_Dia_old;

   //---B_six_j_S_M_Dia_n----------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
                for(int j=0; j<B_N_Sys_Number_Jn[i+1]-1; j++) {
                        delete [] B_six_j_S_M_Dia_n[i][j];
                }
                delete [] B_six_j_S_M_Dia_n[i];
        }
        delete [] B_six_j_S_M_Dia_n;

   //---B_six_j_H------------------------------------------------------------------------------------------------
	for(int i=0; i<B_site-1; i++) {
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        for(int k=0; k<B_Sys_Number_Jn[i]; k++) {
                                delete [] B_six_j_H[i][j][k];
                        }
                        delete [] B_six_j_H[i][j];
                }
                delete [] B_six_j_H[i];
        }
        delete [] B_six_j_H;

//------Delete A_N-matrices--------------------------------------------------------------------------------------
	for(int i=0; i<A_site; i++) {
		for(int j=0; j<para.S+1; j++) {
			delete [] A_N_IndexOld[i][j];	delete [] A_N_Start[i][j];
		}
		delete [] A_N_IndexOld[i];	delete [] A_N_Start[i];
	}
	delete [] A_N_IndexOld;			delete [] A_N_Start;

	for(int i=0; i<A_site; i++) {
		delete [] A_N_Sys_Value_Jn[i];		delete [] A_N_Sys_SubBlockNumber_Jn[i];
	}
	delete [] A_N_Sys_Value_Jn;			delete [] A_N_Sys_SubBlockNumber_Jn;

	delete [] A_N_Sys_Number_Jn;

//------Delete B_N-matrices--------------------------------------------------------------------------------------
        for(int i=0; i<B_site; i++) {
                for(int j=0; j<para.S+1; j++) {
                        delete [] B_N_IndexOld[i][j];   delete [] B_N_Start[i][j];
                }
                delete [] B_N_IndexOld[i];      delete [] B_N_Start[i];
        }
        delete [] B_N_IndexOld;                 delete [] B_N_Start;

        for(int i=0; i<B_site; i++) {
                delete [] B_N_Sys_Value_Jn[i];          delete [] B_N_Sys_SubBlockNumber_Jn[i];
        }
        delete [] B_N_Sys_Value_Jn;                     delete [] B_N_Sys_SubBlockNumber_Jn;

        delete [] B_N_Sys_Number_Jn;

//------Delete A-matrices----------------------------------------------------------------------------------------
	for(int i=0; i<A_site; i++) {
		for(int j=0; j<A_Sys_Number_Jn[i]; j++) {
			delete [] A[i][j];
		}
		delete [] A[i];
	}
	delete [] A;
	
	for(int i=0; i<A_site; i++) {
		delete [] A_Sys_Value_Jn[i];		delete [] A_Sys_SubBlockNumber_Jn[i];
		delete [] A_density_dim[i];		delete [] A_OldSub[i];
	}
	delete [] A_Sys_Value_Jn;			delete [] A_Sys_SubBlockNumber_Jn;	
	delete [] A_density_dim;			delete [] A_OldSub;

	delete [] A_Sys_Number_Jn;
//---------------------------------------------------------------------------------------------------------------

//------Delete B-matrices----------------------------------------------------------------------------------------
	for(int i=0; i<B_site; i++) {
                for(int j=0; j<B_Sys_Number_Jn[i]; j++) {
                        delete [] B[i][j];
                }
                delete [] B[i];
        }
        delete [] B;

        for(int i=0; i<B_site; i++) {
                delete [] B_Sys_Value_Jn[i];		delete [] B_Sys_SubBlockNumber_Jn[i];
                delete [] B_density_dim[i];		delete [] B_OldSub[i];
        }
        delete [] B_Sys_Value_Jn;       		delete [] B_Sys_SubBlockNumber_Jn;      
	delete [] B_density_dim;			delete [] B_OldSub;

        delete [] B_Sys_Number_Jn;
}

//===============================================================================================================
ChiralCorrelation::~ChiralCorrelation() {}

//==================================================END==========================================================
