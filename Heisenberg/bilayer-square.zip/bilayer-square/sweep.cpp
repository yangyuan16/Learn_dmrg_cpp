#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
using namespace std;

#include"sub.h"
#include"super.h"
#include"superenergy.h"
#include"spincorrelation.h"
#include"dimercorrelation.h"
#include"chiralcorrelation.h"
#include"bulkenergy.h"
#include"sqspin.h"
#include"denmat.h"
#include"common.h"
#include"sweep.h"

//===================================DMRG process of the 2D spin lattices========================================
Sweep::Sweep(Parameter &para) {

	if(para.Sign=='N') {

		lsys=1;		//System contains one site in the beginning
		lns=1;		//System is added a spin site in each iteraction process

		Initial(para);

		for(; lsys<para.N/2; )	
			Infinite(para, lsys, lns);

		//------First sweep from Left to Right
		step=0;
		num=0;
		number=0;
		max_num=para.Max_Num;
	        initialstate=para.StateNoKept;      //number of kept states for the first sweep from left to right
	        site_start=1;//para.untruncated_site/2-1;//left end site of the sweep region
        	site_end=para.N-2;//para.untruncated_site/2;//right end site of the sweep region
	        direction='R';  //from left to right
		precision=1.e-4;

		Finite_Sweep(para, para.N/2, site_end, direction, initialstate, step, precision);//site_end

		//------Finite sweep from left to right and right to left
		for(step=1; step<max_num; step++) {

        	        if(step%2==1)      {
                	        direction='L';

                        	FILE *g=fopen("control_file/max_num", "r+");
				fscanf(g, "%d\n", &max_num);
        	                fclose(g);

	                        FILE *f=fopen("control_file/optimalstate", "r+");
				fseek(f, number, SEEK_SET);
                	        fscanf(f, "%d\n", &optimalstate_sweep); cout<<"\n M="<<optimalstate_sweep;
				if(optimalstate_sweep<10)  number=number+2;
				else if(9<optimalstate_sweep && optimalstate_sweep<100)  number=number+3;
				else if(99<optimalstate_sweep && optimalstate_sweep<1000)  number=number+4;
				else if(999<optimalstate_sweep && optimalstate_sweep<10000)  number=number+5;
                        	fclose(f);

	                        FILE *v=fopen("control_file/tolerance", "r+");
				fseek(v, num, SEEK_SET);
                	        fscanf(v, "%lf\n", &precision); cout<<"\n Precision="<<precision;
				num=num+7;
	                        fclose(v);

        	                Finite_Sweep(para, site_start, site_end, direction, optimalstate_sweep, step, precision);
        	       	}
	
	                else if(step%2==0) {
        	                direction='R';

                	        FILE *g=fopen("control_file/max_num", "r+");
				fscanf(g, "%d\n", &max_num);
	                        fclose(g);

				FILE *f=fopen("control_file/optimalstate", "r+");
				fseek(f, number, SEEK_SET);
                	        fscanf(f, "%d\n", &optimalstate_sweep);	cout<<"\n M="<<optimalstate_sweep;
				if(optimalstate_sweep<10)  number=number+2;
				else if(9<optimalstate_sweep && optimalstate_sweep<100)  number=number+3;
				else if(99<optimalstate_sweep && optimalstate_sweep<1000)  number=number+4;
				else if(999<optimalstate_sweep && optimalstate_sweep<10000)  number=number+5;
                        	fclose(f);
 
	                        FILE *v=fopen("control_file/tolerance", "r+");
				fseek(v, num, SEEK_SET);
                	        fscanf(v, "%lf\n", &precision); cout<<"\n Precision="<<precision;
				num=num+7;
	                        fclose(v);
	
        	                Finite_Sweep(para, site_start, site_end, direction, optimalstate_sweep, step, precision);
                	}

        	}

	}

	else if(para.Sign=='R') {

		lsys=1;		//System contains one site in the beginning
		lns=1;		//System is added a spin site in each iteraction process

		//------First sweep from Left to Right
		step=43;
		num=0;
		number=0;
		max_num=para.Max_Num;
	        initialstate=10000;//para.StateNoKept; //number of kept states for the first sweep
	        site_start=1;//para.untruncated_site/2-1;//left end site of the sweep region
        	site_end=para.N-2;//para.untruncated_site/2;//right end site of the sweep region
	        direction='L';  //from left to right
		precision=1.e-6;

		Finite_Sweep(para, 74, site_end, direction, initialstate, step, precision);

		//------Finite sweep from left to right and right to left
		for(step=44; step<max_num; step++) {

        	        if(step%2==1)      {
                	        direction='L';

                        	FILE *g=fopen("control_file/max_num", "r+");
				fscanf(g, "%d\n", &max_num);
        	                fclose(g);

	                        FILE *f=fopen("control_file/optimalstate", "r+");
				fseek(f, number, SEEK_SET);
                	        fscanf(f, "%d\n", &optimalstate_sweep); cout<<"\n M="<<optimalstate_sweep;
				if(optimalstate_sweep<10)  number=number+2;
				else if(9<optimalstate_sweep && optimalstate_sweep<100)  number=number+3;
				else if(99<optimalstate_sweep && optimalstate_sweep<1000)  number=number+4;
				else if(999<optimalstate_sweep && optimalstate_sweep<10000)  number=number+5;
                        	fclose(f);

	                        FILE *v=fopen("control_file/tolerance", "r+");
				fseek(v, num, SEEK_SET);
                	        fscanf(v, "%lf\n", &precision); cout<<"\n Precision="<<precision;
				num=num+7;
	                        fclose(v);

        	                Finite_Sweep(para, site_start, site_end, direction, optimalstate_sweep, step, precision);
        	       	}
	
	                else if(step%2==0) {
        	                direction='R';

                	        FILE *g=fopen("control_file/max_num", "r+");
				fscanf(g, "%d\n", &max_num);
	                        fclose(g);

				FILE *f=fopen("control_file/optimalstate", "r+");
				fseek(f, number, SEEK_SET);
                	        fscanf(f, "%d\n", &optimalstate_sweep);	cout<<"\n M="<<optimalstate_sweep;
				if(optimalstate_sweep<10)  number=number+2;
				else if(9<optimalstate_sweep && optimalstate_sweep<100)  number=number+3;
				else if(99<optimalstate_sweep && optimalstate_sweep<1000)  number=number+4;
				else if(999<optimalstate_sweep && optimalstate_sweep<10000)  number=number+5;
                        	fclose(f);
 
	                        FILE *v=fopen("control_file/tolerance", "r+");
				fseek(v, num, SEEK_SET);
                	        fscanf(v, "%lf\n", &precision); cout<<"\n Precision="<<precision;
				num=num+7;
	                        fclose(v);
	
        	                Finite_Sweep(para, site_start, site_end, direction, optimalstate_sweep, step, precision);
                	}

        	}

	}
/*
	step=1;
	precision=1.e-6;

        if(step%2==1)  direction='L';
        else if(step%2==0)  direction='R';

        Measurement(para, step, precision);
*/
}

//===========================================Initialize sys and env blocks=======================================
inline void Sweep::Initial(Parameter &para) {
	Sub *sys=new Sub(para);

	sys->Print_space(1, lsys);
	sys->Print_space(2, lsys);

	sys->Print_operator_H(1, lsys);
	sys->Print_operator_S_Dia(1, lsys);
	sys->Print_operator_S_M_Dia(1, lsys);

	sys->Print_operator_H(2, lsys);
	sys->Print_operator_S_Dia(2, lsys);
	sys->Print_operator_S_M_Dia(2, lsys);

	delete sys;
}

//=======================================Infinite Iteration process===============================================
inline void Sweep::Infinite(Parameter &para, int &lsys, const int &lns) {
//------Read in the data from the hard disk----------------------------------------------------------------------
	cout<<"\n lsys="<<lsys;

    //--Read in sys_space and env_space
	Sub *sys_space=new Sub("space", 1, lsys);
	Sub *env_space=new Sub("space", 2, lsys);

    //--Read in sys_operator and env_operator
	Sub *sys_operator=new Sub(1, lsys);
	Sub *env_operator=new Sub(2, lsys);

//------Space of blocks of sysnew and envnew---------------------------------------------------------------------
	lsys+=lns;

	Sub *sysnew_space=new Sub(1, para, *sys_space);
	Sub *envnew_space=new Sub(2, para, *env_space);

//------Diagonalization of the Hamiltonian-----------------------------------------------------------------------
    //--Allocate space for wave function blocks
	Super *sup_space=new Super(para, sys_space, env_space, sysnew_space, envnew_space);

    //--Allocate space for diagonalization
	Super *sup_diagonalization=new Super("infinite", para, sys_operator, env_operator, *sup_space);

    //--Diagonalization of the Hamiltonian by Matrix-Vector multiplication
 	para.total_site++;
	precision=1.e-4;
	SuperEnergy *supeng=new SuperEnergy(para, *sup_space, *sup_diagonalization, precision);

	ground_state_energy=supeng->eigenvalue;
	excited_state_energy=0.0;
	WriteEnergy(para, ground_state_energy, excited_state_energy, lsys-1, para.total_site);

    //--Destruct the functions for diagonalization
	delete supeng;
	delete sup_diagonalization;

//------Adding site and truncation of system block----------------------------------------------------------------
    //--Create space for eigensystem of reduced density matrix
	Sub *reduced_density_sys=new Sub(*sysnew_space);

    //--Find the eigensystem of reduced density matrix
        DenMat *densys=new DenMat(1, para, *sup_space, *reduced_density_sys);
        delete densys;
 
    //--Create space for truncation
	Sub *systrun_space=new Sub(para, *reduced_density_sys); 
	systrun_space->Print_space(1, lsys);

    //--New and truncate H operator
    	direction='H';
        Sub *sysnew_operator_H=new Sub(direction, para, *sys_operator, *sysnew_space);
	Sub *systrun_operator_H=new Sub(para, direction, *reduced_density_sys, *systrun_space, *sysnew_operator_H);

	systrun_operator_H->Print_operator_H(1, lsys);
	delete systrun_operator_H;	delete sysnew_operator_H;

    //--New and truncate S_Dia operator
        direction='S';
        Sub *sysnew_operator_S=new Sub(direction, para, *sys_operator, *sysnew_space);
        Sub *systrun_operator_S=new Sub(para, direction, *reduced_density_sys, *systrun_space, *sysnew_operator_S);

        systrun_operator_S->Print_operator_S_Dia(1, lsys);
        delete systrun_operator_S;      delete sysnew_operator_S;

    //--New and truncate S_M_Dia operator
    	direction='M';
        Sub *sysnew_operator_M=new Sub(direction, para, *sys_operator, *sysnew_space);
        Sub *systrun_operator_M=new Sub(para, direction, *reduced_density_sys, *systrun_space, *sysnew_operator_M);
        
        systrun_operator_M->Print_operator_S_M_Dia(1, lsys);
        delete systrun_operator_M;      delete sysnew_operator_M;

	delete sys_operator;

	direction='r';
        SuperEnergy *trun_sys=new SuperEnergy(para, *sup_space, *reduced_density_sys, *systrun_space, direction);
        delete trun_sys;

	delete systrun_space;
	delete reduced_density_sys;

//------Adding site and truncate of environment block-------------------------------------------------------------
    //--Create space for eigensystem of reduced density matrix
        Sub *reduced_density_env=new Sub(*envnew_space);

    //--Find eigensystem of reduced density matrix
        DenMat *denenv=new DenMat(2, para, *sup_space, *reduced_density_env);
        delete denenv;

    //--Create space for truncation
        Sub *envtrun_space=new Sub(para, *reduced_density_env);
        envtrun_space->Print_space(2, lsys);

    //--New and truncate H operator 
    	direction='H';
        Sub *envnew_operator_H=new Sub(direction, *envnew_space, *env_operator, para);
        Sub *envtrun_operator_H=new Sub(para, direction, *reduced_density_env, *envtrun_space, *envnew_operator_H);

        envtrun_operator_H->Print_operator_H(2, lsys);
        delete envtrun_operator_H;      delete envnew_operator_H;

    //--New and truncate S_Dia operator
    	direction='S';
        Sub *envnew_operator_S=new Sub(direction, *envnew_space, *env_operator, para);
        Sub *envtrun_operator_S=new Sub(para, direction, *reduced_density_env, *envtrun_space, *envnew_operator_S);

        envtrun_operator_S->Print_operator_S_Dia(2, lsys);
        delete envtrun_operator_S;      delete envnew_operator_S;

    //--New and truncate S_M_Dia operator
    	direction='M';
        Sub *envnew_operator_M=new Sub(direction, *envnew_space, *env_operator, para);
        Sub *envtrun_operator_M=new Sub(para, direction, *reduced_density_env, *envtrun_space, *envnew_operator_M);

        envtrun_operator_M->Print_operator_S_M_Dia(2, lsys);
        delete envtrun_operator_M;      delete envnew_operator_M;

	delete env_operator;

	direction='l';
        SuperEnergy *trun_env=new SuperEnergy(para, *sup_space, *reduced_density_env, *envtrun_space, direction);
        delete trun_env;

	delete envtrun_space;
        delete reduced_density_env;

//------Delete spaces--------------------------------------------------------------------------------------------
	delete sup_space;
	delete sysnew_space;		delete envnew_space;
	delete sys_space;               delete env_space;
}

//===============================================================================================================
//                                              Finite Sweep Iteration 
//===============================================================================================================
inline void Sweep::Finite_Sweep(Parameter &para, const int &lsys_start, const int &lsys_end, char &D, const int &optimalstate, const int &step, const double &precision) {
        if(D=='R')      {Finite_Sweep_LeftToRight(para, lsys_start, lsys_end, optimalstate, step, precision);}
        else if(D=='L') {Finite_Sweep_RightToLeft(para, lsys_start, lsys_end, optimalstate, step, precision);}
}

//==============================================================================================================
//                                   Finite_Sweep: From Left to Right process
//==============================================================================================================
inline void Sweep::Finite_Sweep_LeftToRight(Parameter &para, const int &lsys_start, const int &lsys_end, const int &optimalstate, const int &step, const double &precision) {

        FILE *LOG=fopen("LOG", "a+");
        fprintf(LOG, "*********Finite sweep from left to right. Start and end at %d,%d", lsys_start, lsys_end);
        fprintf(LOG, "\n\n");
        fclose(LOG);


        for(lsys=lsys_start; lsys<lsys_end; ) {//lsys denotes the length of system block
		cout<<"\n lsys="<<lsys<<endl;

                FILE *log=fopen("LOG", "a+");
                fprintf(log, "*********Length of system block=%d\n", lsys);
                fprintf(log, "\n");
                fclose(log);

//------Read in system and environment blocks from results of Infinite sweep iteration---------------------------
	    //--Read in sys_space and env_space
		Sub *sys_space=new Sub("space", 1, lsys);
		Sub *env_space=new Sub("space", 2, para.N-lsys-2);

            //--Read in sys_operators and env_operators
		Sub *sys_operator=new Sub(1, lsys);
		Sub *env_operator=new Sub(2, para.N-lsys-2);


//------New space of sysnew and envnew---------------------------------------------------------------------------
		lsys+=lns;

	    //--space of sysnew and envnew
		Sub *sysnew_space=new Sub(1, para, *sys_space);
		Sub *envnew_space=new Sub(para, "nonoperator", *env_space);


//------Construct the space for diagonalization and the diagonalization of the Hamiltonian-----------------------
	    //--Allocate space for blocks of wave function
		Super *sup_space=new Super(para, sys_space, env_space, sysnew_space, envnew_space);

	    //--Allocate space for diagonalization
		Super *sup_diagonalization=new Super("finite", para, sys_operator, env_operator, *sup_space);

	    //--Diagonalization by matrix-vector multiplication
                if(lsys-1>site_start) {
                        para.total_site++;
                        SuperEnergy *supeng=new SuperEnergy(para, *sup_space, *sup_diagonalization, "right", precision);
                        ground_state_energy=supeng->eigenvalue;
			excited_state_energy=0.0;//supeng->eigenvalue_excited;
                        WriteEnergy(para, ground_state_energy, excited_state_energy, lsys-1, para.total_site);
			WriteEnergy_sweep(para, lsys-1, step, ground_state_energy, excited_state_energy);
                        delete supeng;
                }

                else if(lsys-1==site_start) {
                        SuperEnergy *supeng=new SuperEnergy(para, *sup_space, *sup_diagonalization, 2, precision);
                        delete supeng;
                }

	    //--Destruct sup_diagonalization
		delete sup_diagonalization;

		delete env_operator;

	//------Adding site and truncate the system block--------------------------------------------------------
	        Sub *reduced_density_sys=new Sub(*sysnew_space);

	        DenMat *densys=new DenMat(1, para, *sup_space, *reduced_density_sys);
        	delete densys;

	        Sub *systrun_space=new Sub(para, *reduced_density_sys, optimalstate);
                systrun_space->Print_space(1, lsys);

		direction='H';
	        Sub *sysnew_operator_H=new Sub(direction, para, *sys_operator, *sysnew_space);
	        Sub *systrun_operator_H=new Sub(para, direction, *reduced_density_sys, *systrun_space, *sysnew_operator_H);

        	systrun_operator_H->Print_operator_H(1, lsys);
        	delete systrun_operator_H;      delete sysnew_operator_H;

		direction='S';
	        Sub *sysnew_operator_S=new Sub(direction, para, *sys_operator, *sysnew_space);
        	Sub *systrun_operator_S=new Sub(para, direction, *reduced_density_sys, *systrun_space, *sysnew_operator_S);

        	systrun_operator_S->Print_operator_S_Dia(1, lsys);
        	delete systrun_operator_S;      delete sysnew_operator_S;

		direction='M';
	        Sub *sysnew_operator_M=new Sub(direction, para, *sys_operator, *sysnew_space);
        	Sub *systrun_operator_M=new Sub(para, direction, *reduced_density_sys, *systrun_space, *sysnew_operator_M);

        	systrun_operator_M->Print_operator_S_M_Dia(1, lsys);
        	delete systrun_operator_M;      delete sysnew_operator_M;

		delete sys_operator;

                if(lsys<site_end) {     //site increasing steps
			direction='r';
                        SuperEnergy *trun_func=new SuperEnergy(para, *sup_space, *reduced_density_sys, *systrun_space, direction);
                        delete trun_func;
                }

                else if(lsys==site_end) {       //reach the end of the sweep in a direction
                        SuperEnergy *trun_func=new SuperEnergy(*sup_space, *systrun_space, 1);
                        delete trun_func;
                }

		delete systrun_space;
	        delete reduced_density_sys;

		delete sup_space;
		delete sysnew_space;		delete envnew_space;
		delete sys_space;		delete env_space;
	}
}

//===============================================================================================================
//                                    Finite_Sweep: From Right to Left process
//===============================================================================================================
inline void Sweep::Finite_Sweep_RightToLeft(Parameter &para, const int &lsys_start, const int &lsys_end, const int &optimalstate, const int &step, const double &precision) {

	FILE *LOG=fopen("LOG", "a+");
	fprintf(LOG, "*********Finite sweep from right to left. Start and end at %d,%d", lsys_start, lsys_end);
	fprintf(LOG, "\n\n");
	fclose(LOG);

	for(lsys=lsys_start; lsys<lsys_end; ) { //Here, lsys denotes the length of environment block
		cout<<"\n lsys="<<lsys<<endl;

		FILE *log=fopen("LOG", "a+");
		fprintf(log, "*********Length of environment block is %d\n", lsys);
		fprintf(log, "\n");
		fclose(log);

//------Read in system and environment blocks from results of Infinite sweep iteration---------------------------
            //--Read in sys_space and env_space
		Sub *sys_space=new Sub("space", 1, para.N-lsys-2);
		Sub *env_space=new Sub("space", 2, lsys);

            //--Read in sys_operators and env_operators
		Sub *sys_operator=new Sub(1, para.N-lsys-2);
		Sub *env_operator=new Sub(2, lsys);


//------New space of sysnew and envnew---------------------------------------------------------------------------
		lsys+=lns;

            //--space of sysnew and envnew
		Sub *sysnew_space=new Sub(para, "nonoperator", *sys_space);
		Sub *envnew_space=new Sub(2, para, *env_space);


//------Construct the space for diagonalization and the diagonalization of the Hamiltonian-----------------------
	    //--Allocate space for blocks of wave function
		Super *sup_space=new Super(para, sys_space, env_space, sysnew_space, envnew_space);

	    //--Allocate space for diagonalization
		Super *sup_diagonalization=new Super("finite", para, sys_operator, env_operator, *sup_space);

            //--Diagonalization by matrix-vector multiplication
		if(lsys-1>site_start) {
                        para.total_site++;
                        SuperEnergy *supeng=new SuperEnergy(para, *sup_space, *sup_diagonalization, "left", precision);
                        ground_state_energy=supeng->eigenvalue;
			excited_state_energy=0.0;//supeng->eigenvalue_excited;
                        WriteEnergy(para, ground_state_energy, excited_state_energy, lsys-1, para.total_site);
			WriteEnergy_sweep(para, lsys-1, step, ground_state_energy, excited_state_energy);
                        delete supeng;
                }

                else if(lsys-1==site_start) {
                        SuperEnergy *supeng=new SuperEnergy(para, *sup_space, *sup_diagonalization, 1, precision);
                        delete supeng;
                }

	    //--Destruct sup_diagonalization
	    	delete sup_diagonalization;

		delete sys_operator;

        //------Adding site and truncate the system block--------------------------------------------------------
		Sub *reduced_density_env=new Sub(*envnew_space);

	        DenMat *denenv=new DenMat(2, para, *sup_space, *reduced_density_env);
        	delete denenv;

                Sub *envtrun_space=new Sub(para, *reduced_density_env, optimalstate);
                envtrun_space->Print_space(2, lsys);

		direction='H';
 	        Sub *envnew_operator_H=new Sub(direction, direction, para, *env_operator, *envnew_space);
        	Sub *envtrun_operator_H=new Sub(para, direction, *reduced_density_env, *envtrun_space, *envnew_operator_H);

	        envtrun_operator_H->Print_operator_H(2, lsys);
        	delete envtrun_operator_H;      delete envnew_operator_H;

		direction='S';
	        Sub *envnew_operator_S=new Sub(direction, direction, para, *env_operator, *envnew_space);
        	Sub *envtrun_operator_S=new Sub(para, direction, *reduced_density_env, *envtrun_space, *envnew_operator_S);

        	envtrun_operator_S->Print_operator_S_Dia(2, lsys);
        	delete envtrun_operator_S;      delete envnew_operator_S;

		direction='M';
	        Sub *envnew_operator_M=new Sub(direction, direction, para, *env_operator, *envnew_space);
        	Sub *envtrun_operator_M=new Sub(para, direction, *reduced_density_env, *envtrun_space, *envnew_operator_M);

	        envtrun_operator_M->Print_operator_S_M_Dia(2, lsys);
        	delete envtrun_operator_M;      delete envnew_operator_M;

		delete env_operator;

                if(lsys<site_end) {
			direction='l';
                        SuperEnergy *trun_func=new SuperEnergy(para, *sup_space, *reduced_density_env, *envtrun_space, direction);
                        delete trun_func;
                }

                else if(lsys==site_end) {
                        SuperEnergy *trun_func=new SuperEnergy(*sup_space, *envtrun_space, 2);
                        delete trun_func;
                }

		delete envtrun_space;
	        delete reduced_density_env;

                delete sup_space;
                delete sysnew_space;            delete envnew_space;
                delete sys_space;               delete env_space;
	}
}

//===============================================================================================================
//                                      Measurement
//===============================================================================================================
inline void Sweep::Measurement(Parameter &para, const int &step, const double &precision) {
        if(step==0)      Measurement_LeftToRight(para, precision);
        else if(step==1) Measurement_RightToLeft(para, precision);
}

//-------------------------------------------------------------------------------------
inline void Sweep::Measurement_RightToLeft(Parameter &para, const double &precision) {

        lsys=para.N/2-1;
        cout<<"\n lsys="<<lsys<<endl;

        Sub *sys_space=new Sub("space", 1, para.N-lsys-2);
        Sub *env_space=new Sub("space", 2, lsys);

        Sub *sys_operator=new Sub(1, para.N-lsys-2);
        Sub *env_operator=new Sub(2, lsys);

        Sub *sysnew_space=new Sub(para, "nonoperator", *sys_space);
        Sub *envnew_space=new Sub(2, para, *env_space);

        Super *sup_space=new Super(para, sys_space, env_space, sysnew_space, envnew_space);

        Super *sup_diagonalization=new Super("finite", para, sys_operator, env_operator, *sup_space);

        para.total_site++;
        SuperEnergy *supeng=new SuperEnergy(para, *sup_space, *sup_diagonalization, "left", precision);
        ground_state_energy=supeng->eigenvalue;
        excited_state_energy=0.0;//supeng->eigenvalue_excited;
        WriteEnergy(para, ground_state_energy, excited_state_energy, lsys, para.total_site);
        WriteEnergy_sweep(para, lsys, step, ground_state_energy, excited_state_energy);
        WriteWave_Function(sup_space->BlockNumber_for_TargetSpin, sup_space->Dim_block, sup_space->WaveFunction_block, sup_space->WaveFunction_excited_block);

        delete supeng;
        delete sup_diagonalization;
        delete sys_operator;    delete env_operator;
        delete sup_space;
        delete sysnew_space;            delete envnew_space;
        delete sys_space;               delete env_space;

        Sub *sys_measure=new Sub("space", 1, para.N-lsys-2);
        Sub *env_measure=new Sub("space", 2, lsys);

        Sub *sysnew_measure=new Sub(para, "nonoperator", *sys_measure);
        Sub *envnew_measure=new Sub(2, para, *env_measure);

        Super *sup_measure=new Super(sys_measure, env_measure, sysnew_measure, envnew_measure, para);

//        Sqspin *sqspin = new Sqspin(para.N-lsys-2, para, *sup_measure);
//        delete sqspin;

//        ChiralCorrelation *chiral=new ChiralCorrelation(para.N-lsys-2, para, *sup_measure);
//        delete chiral;

//        SpinCorrelation *spin=new SpinCorrelation(para.N-lsys-2, para, *sup_measure);
//        delete spin;

	BulkEnergy *bulk = new BulkEnergy(para.N-lsys-2, para, *sup_measure);
        delete bulk;

        DimerCorrelation *dimer=new DimerCorrelation(lsys, para, *sup_measure);
        delete dimer;

        delete sup_measure;
        delete sysnew_measure;  delete envnew_measure;
        delete sys_measure;     delete env_measure;

}

//--------------------------------------------------------------------
inline void Sweep::Measurement_LeftToRight(Parameter &para, const double &precision) {

        lsys=para.N/2-1;
        cout<<"\n lsys="<<lsys<<endl;

        Sub *sys_space=new Sub("space", 1, lsys);
        Sub *env_space=new Sub("space", 2, para.N-lsys-2);

        Sub *sys_operator=new Sub(1, lsys);
        Sub *env_operator=new Sub(2, para.N-lsys-2);

        Sub *sysnew_space=new Sub(1, para, *sys_space);
        Sub *envnew_space=new Sub(para, "nonoperator", *env_space);

        Super *sup_space=new Super(para, sys_space, env_space, sysnew_space, envnew_space);

        Super *sup_diagonalization=new Super("finite", para, sys_operator, env_operator, *sup_space);

        para.total_site++;
        SuperEnergy *supeng=new SuperEnergy(para, *sup_space, *sup_diagonalization, "right", precision);
        ground_state_energy=supeng->eigenvalue;
        excited_state_energy=0.0;//supeng->eigenvalue_excited;
        WriteEnergy(para, ground_state_energy, excited_state_energy, lsys, para.total_site);
        WriteEnergy_sweep(para, lsys, step, ground_state_energy, excited_state_energy);
        WriteWave_Function(sup_space->BlockNumber_for_TargetSpin, sup_space->Dim_block, sup_space->WaveFunction_block, sup_space->WaveFunction_excited_block);

        delete supeng;
        delete sup_diagonalization;
        delete sys_operator;    	delete env_operator;
        delete sup_space;
        delete sysnew_space;            delete envnew_space;
        delete sys_space;               delete env_space;

        Sub *sys_measure=new Sub("space", 1, lsys);
        Sub *env_measure=new Sub("space", 2, para.N-lsys-2);

        Sub *sysnew_measure=new Sub(1, para, *sys_measure);
        Sub *envnew_measure=new Sub(para, "nonoperator", *env_measure);

        Super *sup_measure=new Super(sys_measure, env_measure, sysnew_measure, envnew_measure, para);

	BulkEnergy *bulk = new BulkEnergy(lsys, para, *sup_measure);
        delete bulk;

        DimerCorrelation *dimer=new DimerCorrelation(lsys, para, *sup_measure);
        delete dimer;

//        SpinCorrelation *spin=new SpinCorrelation(lsys, para, *sup_measure);
//        delete spin;

    //    ChiralCorrelation *chiral=new ChiralCorrelation(lsys, para, *sup_measure);
      //  delete chiral;

        delete sup_measure;
        delete sysnew_measure;  delete envnew_measure;
        delete sys_measure;     delete env_measure;

}

//================================================================================================================
//                                      Save the ground state energy to file
//===============================================================================================================
inline void Sweep::WriteEnergy(Parameter &para, const double &ground_state_energy, const double &excited_state_energy, const int &lsys, const int &site) {
	FILE *e=fopen("e/ground_state_energy", "a+");
        fprintf(e, "%d\t", site);
        fprintf(e, "%-20.20f\n", ground_state_energy);
        fclose(e);

        if(lsys==para.N/2-1) {
                FILE *b=fopen("e/ground_state_energy_middle", "a+");
                fprintf(b, "%-20.20f\n", ground_state_energy);
                fclose(b);
        }
}

//===============================================================================================================
//				Save the ground state energy in each sweep step to file
//===============================================================================================================
inline void Sweep::WriteEnergy_sweep(Parameter &para, const int &site_num, const int &step_num, const double &energy, const double &excited) {
        FILE *e=fopen(Combine("e/ground_state_energy_sweep-", step_num) , "a+");
        fprintf(e, "%d\t", site_num);
        fprintf(e, "%-20.20f\n", energy);
        fclose(e);
}

//===============================================================================================================
//					Save the wave function
//===============================================================================================================
inline void Sweep::WriteWave_Function(const int &BlockNumber, int *Dim_block, double **WaveFunction, double **WaveFunction_excited) {
	FILE *g=fopen("wavefunction/wavefunction_ground", "w+");

	for(int i=0; i<BlockNumber; i++)
	for(int j=0; j<Dim_block[i]; j++) 
		fprintf(g, "%f\n", WaveFunction[i][j]);

	fclose(g);
}
//================================================================================================================
