class Parameter {
public:
	Parameter(char &sign, const int &max_num, const int &s, const int &total_j, const int &statenokept, const int &n_u, const int &n_x, const int &n_y, const int &n, char &geometry, const double &j_n, const double &j_nn, const double &j_nnn);

//---------------------------------Model parameters and DMRG parameters------------------------------------------
	int S, Total_j, StateNoKept, N_u, N_x, N_y, N, untruncated_site, total_site, Max_Num;
	char Geometry, Sign;
	double J_n, J_nn, J_nnn;

//----------Table that stores the spin sites with interactions, the index denotes the number of the site after the2D lattice is extended to a 1D chain along a certain path. 
	int *Table;		//indexes to mark the two spin sites with interactions
	int *Table_sys;
	int **Table_sys_site;
	int *Table_env;
	int **Table_env_site;

	double *Interaction;	//Interactions between bonds

	~Parameter();
	
private:
	int TotalSite;
	inline void Build_Table_KagomeLattice();
};
