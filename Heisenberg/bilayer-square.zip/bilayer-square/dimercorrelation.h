class DimerCorrelation {

public:

	DimerCorrelation(const int &lsys, Parameter &para, Super &sup);
	~DimerCorrelation();

private:
	char trans_N, trans_T, side_R, side_L, uplo;
	double alpha, beta;

  //----Create spaces for matrices and functions
	double **WaveFunction_block;
	double **WaveFunction_config_2;
	double **WaveFunction_config_3;

	double **dimer_start;
	double **dimer_end;
	double ****dimer_correlation;

	inline void CreateSpace(const int &lsys, Parameter &para);

	inline void CreateFunction(Super &sup);

	inline void DeleteSpace(const int &lsys, Parameter &para);

	inline void DeleteFunction(Super &sup);

	//------A_N-matrices
	int *A_N_Sys_Number_Jn;
	int **A_N_Sys_Value_Jn;
	int **A_N_Sys_SubBlockNumber_Jn;
	int ***A_N_IndexOld;
	int ***A_N_Start;

	double ****A_six_j_S_Dia_old;
        double ***A_six_j_S_Dia_n;
        double ****A_six_j_S_M_Dia_old;
        double ***A_six_j_S_M_Dia_n;
	double ****A_six_j_H;

	//------B_N-matrices
	int *B_N_Sys_Number_Jn;
	int **B_N_Sys_Value_Jn;
	int **B_N_Sys_SubBlockNumber_Jn;
	int ***B_N_IndexOld;
	int ***B_N_Start;

	double ****B_six_j_S_Dia_old;
        double ***B_six_j_S_Dia_n;
        double ****B_six_j_S_M_Dia_old;
        double ***B_six_j_S_M_Dia_n;
	double ****B_six_j_H;

	//------A-matrices
	int *A_Sys_Number_Jn;
	int **A_Sys_Value_Jn;
	int **A_Sys_SubBlockNumber_Jn;
	int **A_density_dim;
	int **A_OldSub;
	double ***A;

	//------B-matrices
	int *B_Sys_Number_Jn;
	int **B_Sys_Value_Jn;
	int **B_Sys_SubBlockNumber_Jn;
	int **B_density_dim;
	int **B_OldSub;
	double ***B;

	double **Si_Dia_old_A, **Si_M_Dia_old_A, **Si_Dia_new_A, **Si_M_Dia_new_A;
        double **Si_Dia_old_B, **Si_M_Dia_old_B, **Si_Dia_new_B, **Si_M_Dia_new_B;

	inline void New_A_Si_initial(const int &n_num);
	inline void New_B_Si_initial(const int &n_num);

	inline void New_A_Si_new(const int &n_num);
	inline void New_B_Si_new(const int &n_num);

	inline void Truncate_A_Si(const int &n_num);
	inline void Truncate_B_Si(const int &n_num);

	double **SiSj_old_A, **SiSj_new_A;
	double **SiSj_old_B, **SiSj_new_B;

	inline void Initial_A_SiSj(const int &n_num);
	inline void Initial_A_SiSj_Square(const int &n_num);

	inline void Initial_B_SiSj(const int &n_num);
	inline void Initial_B_SiSj_Square(const int &n_num);

	inline void New_A_SiSj(const int &n_num);
	inline void New_B_SiSj(const int &n_num);

	inline void Truncate_A_SiSj(const int &n_num);
	inline void Truncate_B_SiSj(const int &n_num);

	inline void Print(Parameter &para);

//------dimer-dimer correlation function-------------------------------------------------------------------------
	inline void CreateSpace_dimer_dimer(Parameter &para);
	
	inline void Dimer_Correlation(const int &lsys, Parameter &para, Super &sup);
		inline void Dimer_i_sys_j_sys_k_sys_l_sys(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

                inline void Dimer_i_sys_k_sys_j_sys_l_sys(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);


                inline void Dimer_i_sys_j_sys_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
		//1-3
                inline void Dimer_i_sys_j_sys_k_sys_l_ns(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
		//1-4
                inline void Dimer_i_sys_j_sys_k_sys_l_ne(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
		//1-5
                inline void Dimer_i_sys_j_sys_k_ns_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
		//1-6
                inline void Dimer_i_sys_j_sys_k_ne_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
		//1-7
                inline void Dimer_i_sys_j_sys_k_sys_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		//2-2
                inline void Dimer_i_env_j_env_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

                inline void Dimer_i_env_k_env_j_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		//3-2
		inline void Dimer_i_sys_j_ns_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
		//3-6
		inline void Dimer_i_sys_j_ns_k_ne_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

                inline void Dimer_i_sys_j_ns_k_sys_l_ne(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		//4-2
               	inline void Dimer_i_sys_j_ne_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

               	inline void Dimer_i_sys_j_env_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

               	inline void Dimer_i_ns_j_env_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

               	inline void Dimer_i_ns_j_env_k_ns_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

	      	inline void Dimer_i_ne_j_env_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

               	inline void Dimer_i_sys_k_sys_j_ns_l_ns(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

               	inline void Dimer_i_sys_j_ne_k_sys_l_ne(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_i_sys_j_ne_k_ns_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

	//------two sites-----------------------------------------------------------------------------------------
		inline void Dimer_rank_two_i_sys_j_env_k_sys_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_two_i_sys_j_ne_k_sys_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_two_i_sys_j_env_k_ns_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_two_i_sys_j_env_k_sys_l_ns(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
	
		inline void Dimer_rank_two_i_sys_j_env_k_ne_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_two_i_sys_j_ne_k_sys_l_ns(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_two_i_ns_j_env_k_ne_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_two_i_sys_j_ns_k_sys_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_two_i_ne_j_env_k_sys_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
	
		inline void Dimer_rank_two_i_ns_j_env_k_sys_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);


	//------three sites--------------------------------------------------------------------------------------
		inline void Dimer_rank_three_i_sys_j_sys_k_sys_l_ns(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_sys_j_sys_k_sys_l_ne(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_sys_j_ne_k_sys_l_sys(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_sys_j_env_k_sys_l_sys(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_sys_j_sys_k_sys_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_k_sys_i_sys_j_sys_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_env_j_env_k_ne_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_ns_j_env_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_ns_j_env_l_env_k_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_sys_j_env_l_env_k_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_sys_j_env_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_three_i_env_j_env_k_sys_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

	//------four sites---------------------------------------------------------------------------------------
		inline void Dimer_rank_four_i_sys_j_sys_k_sys_l_sys(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
		inline void Dimer_rank_four_k_sys_l_sys_i_sys_j_sys(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

		inline void Dimer_rank_four_i_env_j_env_k_env_l_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);
		inline void Dimer_rank_four_k_env_l_env_i_env_j_env(const int &i, const int &j, const int &k, const int &l, const int &lsys, Parameter &para, Super &sup);

	inline void Initial_SiSjSk_A(const int &n_num);
	inline void Initial_SiSjSk_B(const int &n_num);

//------Irreducible tensor operators for two spins---------------------------------------------------------------
	//------A block---------------------------------------
        double **two_spin_rank_zero_operator_new_A;

        double **two_spin_rank_one_operator_Dia_new_A;
        double **two_spin_rank_one_operator_M_Dia_new_A;

        double **two_spin_rank_two_operator_Dia_new_A;
        double **two_spin_rank_two_operator_M_Dia_new_A;
        double **two_spin_rank_two_operator_two_M_Dia_new_A;

        double **two_spin_rank_zero_operator_old_A;

        double **two_spin_rank_one_operator_Dia_old_A;
        double **two_spin_rank_one_operator_M_Dia_old_A;

        double **two_spin_rank_two_operator_Dia_old_A;
        double **two_spin_rank_two_operator_M_Dia_old_A;
        double **two_spin_rank_two_operator_two_M_Dia_old_A;

	//------B block---------------------------------------
        double **two_spin_rank_zero_operator_new_B;

        double **two_spin_rank_one_operator_Dia_new_B;
        double **two_spin_rank_one_operator_M_Dia_new_B;

        double **two_spin_rank_two_operator_Dia_new_B;
        double **two_spin_rank_two_operator_M_Dia_new_B;
        double **two_spin_rank_two_operator_two_M_Dia_new_B;

        double **two_spin_rank_zero_operator_old_B;

        double **two_spin_rank_one_operator_Dia_old_B;
        double **two_spin_rank_one_operator_M_Dia_old_B;

        double **two_spin_rank_two_operator_Dia_old_B;
        double **two_spin_rank_two_operator_M_Dia_old_B;
        double **two_spin_rank_two_operator_two_M_Dia_old_B;

  //----Initialization
	inline void Initial_rank_zero_A(const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);

	inline void Truncate_delta_J_zero_A(const int &n_num, double ***new_op, double ***old_op);
	inline void Truncate_delta_J_zero_B(const int &n_num, double ***new_op, double ***old_op);

        inline void Initial_rank_zero_B(const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);

	//------rank_one_delta_J_zero
	inline void Initial_rank_one_delta_J_zero_A(const int &n_num, const int &old_rank, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);

	inline void Initial_rank_one_delta_J_zero_B(const int &n_num, const int &old_rank, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);


	inline void Initial_rank_one_delta_J_one_A(const int &n_num, const int &old_rank, const int &block, int **low, int **large, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);

	inline void Initial_rank_one_delta_J_one_B(const int &n_num, const int &old_rank, const int &block, int **low, int **large, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);


	inline void New_rank_one_delta_J_zero_A(const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);

	inline void New_rank_one_delta_J_zero_B(const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);


	inline void New_rank_one_delta_J_one_A(const int &n_num, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);

	inline void New_rank_one_delta_J_one_B(const int &n_num, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);


	//------rank_two_delta_J_zero
	inline void Initial_rank_two_delta_J_zero_A(const int &n_num, const int &old_rank, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);
	inline void Initial_rank_two_delta_J_zero_B(const int &n_num, const int &old_rank, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);

	inline void New_rank_two_delta_J_zero_A(const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);
	inline void New_rank_two_delta_J_zero_B(const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);

	//------rank_two_delta_J_one
	inline void Initial_rank_two_delta_J_one_A(const int &n_num, const int &old_rank, const int &block, int **low, int **large, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);
	inline void Initial_rank_two_delta_J_one_B(const int &n_num, const int &old_rank, const int &block, int **low, int **large, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);

	inline void New_rank_two_delta_J_one_A(const int &n_num, const int &block, int **low, int **large, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);
	inline void New_rank_two_delta_J_one_B(const int &n_num, const int &block, int **low, int **large, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);

	//------rank_two_delta_J_two
	inline void Initial_rank_two_delta_J_two_A(const int &n_num, const int &old_rank, const int &block_new, int **low_new, int **large_new, const int &block_two, int **low_two, int **large_two, const int &block_three, int **low_three, int **large_three, double ***new_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op, double ***old_three_M_Dia_op);
	inline void Initial_rank_two_delta_J_two_B(const int &n_num, const int &old_rank, const int &block_new, int **low_new, int **large_new, const int &block_two, int **low_two, int **large_two, const int &block_three, int **low_three, int **large_three, double ***new_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op, double ***old_three_M_Dia_op);

	inline void New_rank_two_delta_J_two_A(const int &n_num, const int &block_new, int **low_new, int **large_new, const int &block_old, int **low_old, int **large_old, double ***new_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);
        inline void New_rank_two_delta_J_two_B(const int &n_num, const int &block_new, int **low_new, int **large_new, const int &block_old, int **low_old, int **large_old, double ***new_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);

	inline void Truncate_delta_J_one_A(const int &n_num, double ***new_op, double ***old_op);
	inline void Truncate_delta_J_one_B(const int &n_num, double ***new_op, double ***old_op);

	inline void Truncate_delta_J_two_A(const int &n_num, const int &block_new, int **low_new, int **large_new, const int &block_old, int **low_old, int **large_old, double ***new_op, double ***old_op);
        inline void Truncate_delta_J_two_B(const int &n_num, const int &block_new, int **low_new, int **large_new, const int &block_old, int **low_old, int **large_old, double ***new_op, double ***old_op);

	inline void New_rank_zero_A(const int &n_num, double ***new_op, double ***old_op);
        inline void New_rank_zero_B(const int &n_num, double ***new_op, double ***old_op);

	inline void Initial_two_spin_rank_zero_operator_A(const int &n_num);
	inline void Initial_two_spin_rank_one_operator_A(const int &n_num);
	inline void Initial_two_spin_rank_two_operator_A(const int &n_num);

  //----Truncation
        inline void Truncate_two_spin_rank_zero_operator_A(const int &n_num);
        inline void Truncate_two_spin_rank_one_operator_A(const int &n_num);
        inline void Truncate_two_spin_rank_two_operator_A(const int &n_num);

  //----New by adding a site
	inline void New_two_spin_rank_zero_operator_A(const int &n_num);
	inline void New_two_spin_rank_one_operator_A(const int &n_num);
	inline void New_two_spin_rank_two_operator_A(const int &n_num);

//------Three spins
	int three_spin_rank_three_J_two_old_A, three_spin_rank_three_J_two_new_A;
	int *low_three_spin_rank_three_J_two_old_A, *large_three_spin_rank_three_J_two_old_A;
	int *low_three_spin_rank_three_J_two_new_A, *large_three_spin_rank_three_J_two_new_A;

	int three_spin_rank_three_J_three_old_A, three_spin_rank_three_J_three_new_A;
	int *low_three_spin_rank_three_J_three_old_A, *large_three_spin_rank_three_J_three_old_A;
	int *low_three_spin_rank_three_J_three_new_A, *large_three_spin_rank_three_J_three_new_A;

	inline void Initial_rank_three_delta_J_zero_A(const int &n_num, const int &old_rank, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);

	inline void Initial_rank_three_delta_J_one_A(const int &n_num, const int &old_rank, const int &block, int **low, int **large, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);

	inline void Initial_rank_three_delta_J_two_A(const int &n_num, const int &old_rank, const int &block_new, int **low_new, int **large_new, const int &block_two, int **low_two, int **large_two, const int &block_three, int **low_three, int **large_three, double ***new_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op, double ***old_three_M_Dia_op);

	inline void Initial_rank_three_delta_J_three_A(const int &n_num, const int &old_rank, const int &block_new, int **low_new, int **large_new, const int &block_two, int **low_two, int **large_two, const int &block_three, int **low_three, int **large_three, double ***new_op, double ***old_two_M_Dia_op, double ***old_three_M_Dia_op);

	inline void New_rank_three_delta_J_zero_A(const int &n_num, const double &phase, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op);

	inline void New_rank_three_delta_J_one_A(const int &n_num, const int &block_two, int **low_two, int **large_two, double ***new_op, double ***old_Dia_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op);

	inline void New_rank_three_delta_J_two_A(const int &n_num, const int &block_new, int **low_new, int **large_new, const int &block_two, int **low_two, int **large_two, const int &block_three, int **low_three, int **large_three, double ***new_op, double ***old_M_Dia_op, double ***old_two_M_Dia_op, double ***old_three_M_Dia_op);

	inline void New_rank_three_delta_J_three_A(const int &n_num, const int &block_new, int **low_new, int **large_new, const int &block_two, int **low_two, int **large_two, const int &block_three, int **low_three, int **large_three, double ***new_op, double ***old_two_M_Dia_op, double ***old_three_M_Dia_op);

	inline void Truncate_delta_J_three_A(const int &n_num, const int &block_new, int **low_new, int **large_new, const int &block_old, int **low_old, int **large_old, double ***new_op, double ***old_op);
        inline void Truncate_delta_J_three_B(const int &n_num, const int &block_new, int **low_new, int **large_new, const int &block_old, int **low_old, int **large_old, double ***new_op, double ***old_op);

//------Irreducible tensor operators of three spins--------------------------------------------------------------
  //----rank zero operators
        double **three_spin_rank_zero_operator_new_A;
        double **three_spin_rank_zero_operator_old_A;

  //----rank one operators coupled by spins zero and one
        double **three_spin_rank_one_operator_zero_one_Dia_new_A;
        double **three_spin_rank_one_operator_zero_one_M_Dia_new_A;
        double **three_spin_rank_one_operator_zero_one_Dia_old_A;
        double **three_spin_rank_one_operator_zero_one_M_Dia_old_A;

        double **three_spin_rank_one_operator_zero_one_Dia_new_B;
        double **three_spin_rank_one_operator_zero_one_M_Dia_new_B;
        double **three_spin_rank_one_operator_zero_one_Dia_old_B;
        double **three_spin_rank_one_operator_zero_one_M_Dia_old_B;

  //----rank one operators coupled by spins one and one
        double **three_spin_rank_one_operator_one_one_Dia_new_A;
        double **three_spin_rank_one_operator_one_one_M_Dia_new_A;
        double **three_spin_rank_one_operator_one_one_Dia_old_A;
        double **three_spin_rank_one_operator_one_one_M_Dia_old_A;

        double **three_spin_rank_one_operator_one_one_Dia_new_B;
        double **three_spin_rank_one_operator_one_one_M_Dia_new_B;
        double **three_spin_rank_one_operator_one_one_Dia_old_B;
        double **three_spin_rank_one_operator_one_one_M_Dia_old_B;

  //----rank one operators coupled by spins two and one
        double **three_spin_rank_one_operator_two_one_Dia_new_A;
        double **three_spin_rank_one_operator_two_one_M_Dia_new_A;
        double **three_spin_rank_one_operator_two_one_Dia_old_A;
        double **three_spin_rank_one_operator_two_one_M_Dia_old_A;

        double **three_spin_rank_one_operator_two_one_Dia_new_B;
        double **three_spin_rank_one_operator_two_one_M_Dia_new_B;
        double **three_spin_rank_one_operator_two_one_Dia_old_B;
        double **three_spin_rank_one_operator_two_one_M_Dia_old_B;

  //----operators of four sites
	double **four_spin_rank_zero_operator_zero_new_A;
	double **four_spin_rank_zero_operator_zero_old_A;
	double **four_spin_rank_zero_operator_one_new_A;
	double **four_spin_rank_zero_operator_one_old_A;
	double **four_spin_rank_zero_operator_two_new_A;
	double **four_spin_rank_zero_operator_two_old_A;

	double **four_spin_rank_zero_operator_zero_new_B;
	double **four_spin_rank_zero_operator_zero_old_B;
	double **four_spin_rank_zero_operator_one_new_B;
	double **four_spin_rank_zero_operator_one_old_B;
	double **four_spin_rank_zero_operator_two_new_B;
	double **four_spin_rank_zero_operator_two_old_B;

  //----Create and delete space for irreducible tensor operators-------------------------------------------------
	inline void CreateSpace_rank_J_new_A(const int &n_num, int &rank, const int &delta_J, int **low_spin, int **large_spin);

	inline void CreateSpace_rank_J_new_B(const int &n_num, int &rank, const int &delta_J, int **low_spin, int **large_spin);

	inline void CreateSpace_rank_J_old_A(const int &n_num, int &rank, const int &delta_J, int **low_spin, int **large_spin);

	inline void CreateSpace_rank_J_old_B(const int &n_num, int &rank, const int &delta_J, int **low_spin, int **large_spin);

    //--Create for rank-zero 
	inline void CreateSpace_delta_J_zero_old_A(const int &num, double ***matrix);
        inline void CreateSpace_delta_J_zero_new_A(const int &num, double ***matrix);
        inline void CreateSpace_delta_J_zero_old_B(const int &num, double ***matrix);
        inline void CreateSpace_delta_J_zero_new_B(const int &num, double ***matrix);

    //--Create for rank-one
        inline void CreateSpace_delta_J_one_old_A(const int &num, double ***matrix);
        inline void CreateSpace_delta_J_one_new_A(const int &num, double ***matrix);
        inline void CreateSpace_delta_J_one_old_B(const int &num, double ***matrix);
        inline void CreateSpace_delta_J_one_new_B(const int &num, double ***matrix);

    //--Create for rank-two
    	int rank_two_old_A, rank_two_new_A;
	int rank_two_one_one_old_A, rank_two_one_one_new_A;
	int rank_two_two_one_old_A, rank_two_two_one_new_A;
	int *low_spin_rank_two_old_A, *large_spin_rank_two_old_A;
	int *low_spin_rank_two_new_A, *large_spin_rank_two_new_A;
	int *low_spin_rank_two_one_one_old_A, *large_spin_rank_two_one_one_old_A;
	int *low_spin_rank_two_one_one_new_A, *large_spin_rank_two_one_one_new_A;
	int *low_spin_rank_two_two_one_old_A, *large_spin_rank_two_two_one_old_A;
	int *low_spin_rank_two_two_one_new_A, *large_spin_rank_two_two_one_new_A;

        int rank_two_old_B, rank_two_new_B;
        int *low_spin_rank_two_old_B, *large_spin_rank_two_old_B;
        int *low_spin_rank_two_new_B, *large_spin_rank_two_new_B;

        inline void CreateSpace_delta_J_more_old_A(const int &num, const int &block, int **low, int **large, double ***matrix);
        inline void CreateSpace_delta_J_more_new_A(const int &num, const int &block, int **low, int **large, double ***matrix);
        inline void CreateSpace_delta_J_more_old_B(const int &num, const int &block, int **low, int **large, double ***matrix);
        inline void CreateSpace_delta_J_more_new_B(const int &num, const int &block, int **low, int **large, double ***matrix);

    //--Create for rank-three
        int rank_three_old_A, rank_three_new_A;
        int *low_spin_rank_three_old_A, *large_spin_rank_three_old_A;
        int *low_spin_rank_three_new_A, *large_spin_rank_three_new_A;

        int rank_three_old_B, rank_three_new_B;
        int *low_spin_rank_three_old_B, *large_spin_rank_three_old_B;
        int *low_spin_rank_three_new_B, *large_spin_rank_three_new_B;

    //--Create for rank-four
        int rank_four_old_A, rank_four_new_A;
        int *low_spin_rank_four_old_A, *large_spin_rank_four_old_A;
        int *low_spin_rank_four_new_A, *large_spin_rank_four_new_A;

        int rank_four_old_B, rank_four_new_B;
        int *low_spin_rank_four_old_B, *large_spin_rank_four_old_B;
        int *low_spin_rank_four_new_B, *large_spin_rank_four_new_B;

    //--Free for rank-zero
        inline void FreeSpace_delta_J_zero_old_A(const int &num, double ***matrix);
        inline void FreeSpace_delta_J_zero_new_A(const int &num, double ***matrix);
        inline void FreeSpace_delta_J_zero_old_B(const int &num, double ***matrix);
        inline void FreeSpace_delta_J_zero_new_B(const int &num, double ***matrix);

    //--Free for rank-one
        inline void FreeSpace_delta_J_one_old_A(const int &num, double ***matrix);
        inline void FreeSpace_delta_J_one_new_A(const int &num, double ***matrix);
        inline void FreeSpace_delta_J_one_old_B(const int &num, double ***matrix);
        inline void FreeSpace_delta_J_one_new_B(const int &num, double ***matrix);

    //--Free for rank-two
        inline void FreeSpace_delta_J_more_old_A(const int &block, double ***matrix);
        inline void FreeSpace_delta_J_more_new_A(const int &block, double ***matrix);
        inline void FreeSpace_delta_J_more_old_B(const int &block, double ***matrix);
        inline void FreeSpace_delta_J_more_new_B(const int &block, double ***matrix);

//------Coupling coefficients------------------------------------------------------------------------------------
	inline void Magnetic_quantum_number_sys_env(const int &J_12, const int &J_1, const int &J_1_p, double &result);

	inline void Magnetic_quantum_number_config_three(const int &J_12, const int &J_1, const int &J_1_p, const int &J_2, const int &J_2_p, const int &k1, const int &q1, const int &k2, const int &q2, const double &a, double &result);

	inline void Magnetic_quantum_number_config_one(const int &J_1n, const int &J_1n_p, const int &J_1, const int &J_1_p, const int &J_2, const int &J_2_p, const int &k1, const int &q1, const int &q2, const int &q3, const double &a, double &result);

	inline void Magnetic_quantum_number_config_one_B(const int &J_1n, const int &J_1n_p, const int &J_1, const int &J_1_p, const int &J_2, const int &J_2_p, const int &k1, const int &q1, const int &q2, const int &q3, const double &a, double &result);

	inline void Magnetic_quantum_number_config_one_C(const int &J_1n, const int &J_1n_p, const int &J_1, const int &J_1_p, const int &J_2, const int &J_2_p, const int &k1, const int &q1, const int &q2, const int &q3, const double &a, double &result);

	inline void Magnetic_quantum_number_config_one_D(const int &J_1n, const int &J_1n_p, const int &J_1, const int &J_1_p, const int &J_2, const int &J_2_p, const int &k1, const int &q1, const int &q2, const int &q3, const double &a, double &result);

	inline void Magnetic_quantum_number_config_one_A(const int &J_1n, const int &J_1n_p, const int &J_1, const int &J_1_p, const int &J_2,  const int &k1, const int &q1, const int &q2, const int &q3, const double &a, double &result);

	inline void Magnetic_quantum_number_config_one_E(const int &J_1n, const int &J_1n_p, const int &J_1, const int &J_2, const int &J_2_p,  const int &k1, const int &q1, const int &q2, const int &q3, const double &a, double &result);

	inline void Magnetic_quantum_number_rank_three_sys_ns(const int &J_1n, const int &J_1, const int &J_1_p, const int &k1, const int &q1, double &result);

	inline void Magnetic_quantum_number_rank_three_sys_ne(const int &J_1e, const int &J_1, const int &J_1_p, const int &k1, const int &q1, double &result);

	inline void Magnetic_quantum_number_rank_three_sys_env(const int &J_12, const int &J_1, const int &J_1_p, const int &J_2, const int &J_2_p, const int &k1, const int &q1, double &result);

//------Matrix multiplications-----------------------------------------------------------------------------------
	//------configure 3
	inline void Matrix_Multiplication_AB_config_one(const int &i, const int &j, double &correlation, double **left, double **right, Super &sup);

	inline void Matrix_Multiplication_AB_config_two(const int &i, const int &j, const double &phase, double &correlation, double **left, double **right, Super &sup);

	inline void Matrix_Multiplication_AB_config_three(const int &i, const int &j, const double &phase, double &correlation, double **left, double **right, Super &sup);

	inline void Matrix_Multiplication_AB_config_four(const int &i, const int &j, const double &phase, double &correlation, double **left, double **right, Super &sup);

	//------configure 1
	inline void Matrix_Multiplication_AB_one_config_one(const int &i, const int &j, double &correlation, double **left, double **right, Super &sup);

	inline void Matrix_Multiplication_AB_one_config_two(const int &i, const int &j, const double &phase, double &correlation, double **left, double **right, Super &sup);

	inline void Matrix_Multiplication_AB_one_config_three(const int &i, const int &j, const double &phase, double &correlation, double **left, double **right, Super &sup);

	inline void Matrix_Multiplication_AB_one_config_four(const int &i, const int &j, const double &phase, double &correlation, double **left, double **right, Super &sup);

	//------configure 1, one matrix sys
	inline void Matrix_Multiplication_A_one(const int &i, const int &j, double &correlation, double **left, Super &sup);

	inline void Matrix_Multiplication_A_two(const int &i, const int &j, const double &phase, double &correlation, double **left, Super &sup);

	inline void Matrix_Multiplication_A_one_config_2(const int &i, const int &j, double &correlation, double **left, Super &sup);

	inline void Matrix_Multiplication_A_two_config_2(const int &i, const int &j, const double &phase, double &correlation, double **left, Super &sup);


	//------configure 1, one matrix env
	inline void Matrix_Multiplication_B_one(const int &i, const int &j, double &correlation, double **right, Super &sup);

	inline void Matrix_Multiplication_B_two(const int &i, const int &j, const double &phase, double &correlation, double **right, Super &sup);

	inline void Matrix_Multiplication_B_one_config_2(const int &i, const int &j, double &correlation, double **right, Super &sup);

	inline void Matrix_Multiplication_B_two_config_2(const int &i, const int &j, const double &phase, double &correlation, double **right, Super &sup);


	inline void DeleteSpace_dimer_dimer(Parameter &para);
};
