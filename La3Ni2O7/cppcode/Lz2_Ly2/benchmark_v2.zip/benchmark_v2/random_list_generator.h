#ifndef RANDOM_LIST_GENERATOR_H
#define RANDOM_LIST_GENERATOR_H

class RandomListGenerator{
	public:
		static int* generateRandomList(int listSize, int desiredZeros, int seedValue);
};

#endif // RANDOM_LIST_GENERATOR_H
