#!/bin/bash
#SBATCH -p G1Part_vip12
#SBATHC -N 1
#SBATCH -n 1
#SBATCH -c 12
source /es01/paratera/parasoft/module.sh
module load mpi/intel/20.0.4
module load gsl/2.4

#Loop through numbers from 1 to 100
for ((i=1; i<=5; i++)); do
        echo "SEED number $i"
        # Modify parameter in main.cpp to set the seedvalue
        sed -i "s/Seedvalue = SEED/Seedvalue=$i/g" main.cpp

        # Compile the C++ program
        make

        # Run the compiled program
        #outfile="a${i}.out"
        #nohup ./runDMRG > "$outfile" 2>&1 &
        srun runDMRG

        folder_name="seed_${i}"
        mkdir -p "$folder_name"
        echo "Created folder: $folder_name"
        mv *.dat "$folder_name"
        mv e "$folder_name"
        mv entanglement "$folder_name"

        make clean

        sed -i "s/Seedvalue=$i/Seedvalue = SEED/g" main.cpp

done

