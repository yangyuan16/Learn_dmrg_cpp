//=====================================================================================
// 	   		       DMRG program for t-J model
//			The algorithm includes the SU(2) symmetry.
//				     SHOU-SHU GONG
//=====================================================================================
#include"omp.h"
#include"mkl.h"
#include<iostream>
#include<time.h>
#include<math.h>
#include<stdio.h>
#include<sys/stat.h>
//#include <chrono>
using namespace std;

#include"parameter.h"
#include"sweep.h"

//------Main Program---------
int main() {

	//------Choose a Job
     	char Sign = 'N'; 
        
	//------time setting
	//time_t start, end;
	//time (&start);
	//auto beforeTime = std::chrono::steady_clock::now();
	double duration;
        clock_t start, finish;
        start = clock();

	//------OMP settings
        int thread = slurm_cpus_per_node;
        omp_set_num_threads(thread);

	//------DMRG parameters
	int Spin = 1;			//Spin=1 for spin-1/2.
	int Total_h = 144;		//Quantum number of hole.
	int Total_J = 0;		//Quantum number of spin, Total_J = 2 * J. 对角化的时候
	int Number_hole = Total_h;		//Number of holes in the system.
	int StateNoKept = 1000;		//DMRG optimal state number for infinite step.

	//------Lattice geometry and size
	int N_u = 2;  // y direaction
	int N_x = 48; // x direaction
	int N_y = 3;  // z direaction
	int Total_N = N_u * N_x * N_y;

	//------Model parameters
	//----[layer1]------
	double T_a1_x = 3.0;  // layer1 x direaction, hopping term
	double J_a1_x = 1.0; // layer1 x direaction, AFM J
        double N_a1_x = -0.25 * J_a1_x; // layer1 x direaction, V    
        double T_a1_y = 3.0; // layer1 y direaction, hopping term
	double J_a1_y = 1.0; // layer1 y direaction, AFM J
        double N_a1_y = -0.25 * J_a1_y; // layer1 y direaction, V
	//----[layer2]-----
        double T_a2_x = 3.0;  // layer2 x direaction, hopping term
        double J_a2_x = 1.0; // layer2 x direaction, AFM J
        double N_a2_x = -0.25 * J_a2_x; // layer2 x direaction, V                                         
        double T_a2_y = 3.0; // layer2 y direaction, hopping term
        double J_a2_y = 1.0; // layer2 y direaction, AFM J
        double N_a2_y = -0.25 * J_a2_y; // layer2 y direaction, V	
        //----[layer3]----
	double T_a3_x = 3.0;  // layer3 x direaction, hopping term
        double J_a3_x = 1.0; // layer3 x direaction, AFM J
        double N_a3_x = -0.25 * J_a3_x; // layer3 x direaction, V
        double T_a3_y = 3.0; // layer3 y direaction, hopping term
        double J_a3_y = 1.0; // layer3 y direaction, AFM J
        double N_a3_y = -0.25 * J_a3_y; // layer3 y direaction, V
	//----[between layer1 and layer2]----	
        double T_a12_z = 0.0;  // layer12 z direaction, hopping term
        double J_a12_z = 0.5; // layer12 z direaction, AFM J
        double N_a12_z = 0.0 * J_a12_z; // layer12 z direaction, V
        //----[between layer2 and layer3]----   
        double T_a23_z = 0.0;  // layer23 z direaction, hopping term
        double J_a23_z = 0.5; // layer23 z direaction, AFM J
        double N_a23_z = 0.0 * J_a23_z; // layer23 z direaction, V
        //-----[between layer1 and layer3]---
        double T_a13_z = 0.0;  // layer13 z direaction, hopping term
        double J_a13_z = 0.5; // layer13 z direaction, AFM J
        double N_a13_z = 0.0 * J_a13_z; // layer13 z direaction, V
        //

	//------Open files
        mkdir( "./e", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./entanglement", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./entanglement/spectrum", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./entanglement/entropy", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./spin_correlation", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./wavefunction", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./mid", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./mid/space", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./mid/operator", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./mid/operator/H", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
	mkdir( "./mid/operator/S_Dia", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
	mkdir( "./mid/operator/S_M_Dia", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
	mkdir( "./mid/operator/T", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
	mkdir( "./mid/operator/NN", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./6j_factor", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./6j_factor/S_Dia_old", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./6j_factor/S_Dia_n", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./6j_factor/S_M_Dia_old", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./6j_factor/S_M_Dia_n", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
	mkdir( "./6j_factor/T_old", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
	mkdir( "./6j_factor/T_n", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./6j_factor/H", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./new_block", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./new_block_T", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./truncated_wave_function", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );
        mkdir( "./truncated_density_eigenvector", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH );

	//------Sweep
        Parameter para( Sign, Spin, Total_h, Total_J, Number_hole, StateNoKept, N_u, N_x, N_y, Total_N, T_a1_x, T_a1_y, J_a1_x, J_a1_y, N_a1_x, N_a1_y,
		     T_a2_x, T_a2_y, J_a2_x, J_a2_y, N_a2_x, N_a2_y, T_a3_x, T_a3_y, J_a3_x, J_a3_y, N_a3_x, N_a3_y,T_a12_z, J_a12_z, N_a12_z,T_a23_z, J_a23_z, N_a23_z, 
		     T_a13_z, J_a13_z, N_a13_z
		     );

	Sweep sweep( para );
	cout << endl;
	//auto afterTime = std::chrono::steady_clock::now();
        finish = clock();
        cout << "---------------------"<<endl;
	duration = (double)(finish - start)/CLOCKS_PER_SEC;
	cout << duration << " second" << endl;
        printf("%f seconds\n", duration);
	//cout << "\n Time="<<difftime(end, start) << endl;
	cout << "finished!!!"<< endl; 
        return 0;

}
