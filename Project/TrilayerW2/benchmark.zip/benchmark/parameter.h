class Parameter {

public:

	Parameter(char &sign, const int &spin, const int &total_h, const int &total_j, const int &number_hole, const int &statenokept, const int &n_u, const int &n_x, const int &n_y, const int &total_n, const double &t_a1_x, const double &t_a1_y, const double &j_a1_x, const double &j_a1_y, const double &n_a1_x, const double &n_a1_y, const double &t_a2_x, const double &t_a2_y, const double &j_a2_x, const double &j_a2_y, const double &n_a2_x, const double &n_a2_y, const double &t_a3_x, const double &t_a3_y, const double &j_a3_x, const double &j_a3_y, const double &n_a3_x, const double &n_a3_y, const double &t_a12_z, const double &j_a12_z, const double &n_a12_z, const double &t_a23_z, const double &j_a23_z, const double &n_a23_z, const double &t_a13_z, const double &j_a13_z, const double &n_a13_z);

 //------Model and DMRG parameters
 	char Sign;
        int Spin, Total_h, Total_J, Number_hole, StateNoKept, N_u, N_x, N_y, Total_N, untruncated_site, total_site;
        double T_a1_x, T_a1_y, J_a1_x, J_a1_y, N_a1_x, N_a1_y;
	double T_a2_x, T_a2_y, J_a2_x, J_a2_y, N_a2_x, N_a2_y;
	double T_a3_x, T_a3_y, J_a3_x, J_a3_y, N_a3_x, N_a3_y;
	double T_a12_z, J_a12_z, N_a12_z;
	double T_a23_z, J_a23_z, N_a23_z;
	double T_a13_z, J_a13_z, N_a13_z;

	int * QuantumNumber_hole;
	int * QuantumNumber_J;	

 //------Table that stores the sites with interactions
 	//T coupling
        int *Table_T;
 
        int *Table_T_sys;
        int **Table_T_sys_site;
        int *Table_T_env;
        int **Table_T_env_site;

        double *Interaction_T; 

	//J coupling
        int *Table_J;
 
        int *Table_J_sys;
        int **Table_J_sys_site;

        int *Table_J_env;
        int **Table_J_env_site;

        double *Interaction_J; 

	//N coupling
 	int *Table_N;
 
        int *Table_N_sys;
        int **Table_N_sys_site;

        int *Table_N_env;
        int **Table_N_env_site;

        double *Interaction_N; 

        ~Parameter();

private:

	int TotalSite;

	inline void Parameter_Initial();
	inline void QuantumNumber_Initial();
        inline void Interaction_Table_Initial();

};
