
char *Combine(char *s1, long ks);
char *Combine(char *s1, char *s2);
