#include"jacobi.h"

class DenMat:public Jacobi {
public:
	DenMat(const int &f, Parameter &para, Super &sup, Sub &sysnew);
        ~DenMat();

private:

	int control_number;

    //--parameters for BLAS subroutine
	char jobz, uplo, trans_N, trans_T;
	int BlockNumber, Dim_den, n, lda, lwork, info, x, y;
	double beta, factor, den_sum;

	int *J_sysnew, *J_envnew, *Dim_block;
	double *a, *a_ground, *a_excited;
	double *work, *work_ground, *work_excited;
	double *w, *w_ground, *w_excited;

	double **wavefunc_new;
	double **wavefunc_excited_new;

	inline void CreateSpace(Parameter &para, Super &sup);

        inline void DenMat_Jacobi_sysnew(Super &sup, Sub &sysnew);
        inline void DenMat_Jacobi_envnew(Super &sup, Sub &envnew);

        inline void Find_aa_sysnew(Super &sup, int &js);
        inline void Find_aa_envnew(Super &sup, int &je);

	inline void Initial_Lapack(int &Dim);
	inline void FreeSpace();
};

