#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;
#include<assert.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<time.h>

#include"common.h"
#include"sub.h"
#include"super.h"
#include"denmat.h"

//=================================================BLAS ROUTINES=================================================
extern "C" {
void dgemm_(char *transa, char *transb, const int *m, const int *n, const int *k, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);
//===============================================================================================================
//==============================================LAPACK SUBROUTINE================================================
void dsyev_(char *jobz, char *uplo, int *n, double *a, int *lda, double *w, double *work, int *lwork, int *info);
}
//===============================================================================================================

//================================Reduced density matrix of blocks===============================================
DenMat::DenMat(const int &f, Parameter &para, Super &sup, Sub &sysnew):Jacobi() {
        FILE *fr=fopen("control_file/target_state_number", "r+");
        fscanf(fr, "%d\n", &control_number);
        fclose(fr);

	time_t start, end;
	time (&start);

	CreateSpace(para, sup);

	if(f==1) {
		DenMat_Jacobi_sysnew(sup, sysnew);
	}
	else if(f==2) {
		DenMat_Jacobi_envnew(sup, sysnew);
	}

	FreeSpace();

	time (&end);
	FILE *LOG=fopen("LOG", "a+");
	fprintf(LOG, "********************************************************\n");
        fprintf(LOG, "Time for density matrix is %f\n", difftime(end, start));
        fprintf(LOG, "\n");
	fprintf(LOG, "**********************************************************");
        fclose(LOG);
}

//========================================Create Space for wave functions========================================
inline void DenMat::CreateSpace(Parameter &para, Super &sup) {
  //------Create block space-------------------------------------------------------------------------------------
	int index, J_min, J_max, J_num, oldJ_sys, oldJ_env, position_old, position_new;

  	trans_N='N';	trans_T='T';
  	index=0;	BlockNumber=0;
	beta=1.0;

	for(int j_sysnew=0; j_sysnew<sup.sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<sup.envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sup.sysnew_space->Sys_Value_Jn[j_sysnew]-sup.envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sup.sysnew_space->Sys_Value_Jn[j_sysnew]+sup.envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                	BlockNumber++;
                }
        }

	J_sysnew=new int [BlockNumber];	    J_envnew=new int [BlockNumber];	Dim_block=new int [BlockNumber];
	for(int i=0; i<BlockNumber; i++) {
		J_sysnew[i]=0;		J_envnew[i]=0;		Dim_block[i]=0;
	}

  //------Initialize the values of above angular numbers---------------------------------------------------------
	index=0;
	for(int j_sysnew=0; j_sysnew<sup.sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<sup.envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sup.sysnew_space->Sys_Value_Jn[j_sysnew]-sup.envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sup.sysnew_space->Sys_Value_Jn[j_sysnew]+sup.envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                        J_sysnew[index]=j_sysnew;	J_envnew[index]=j_envnew;	
			Dim_block[index++]=sup.sysnew_space->Sys_SubBlockNumber_Jn[j_sysnew]*sup.envnew_space->Sys_SubBlockNumber_Jn[j_envnew];
                }
        }

  //------Find WaveFunc_new--------------------------------------------------------------------------------------
	if(control_number==1) {
                wavefunc_new=new double * [BlockNumber];

                for(int i=0; i<BlockNumber; i++) {
                        wavefunc_new[i]=new double [Dim_block[i]];

                        for(int j=0; j<Dim_block[i]; j++) 
                                wavefunc_new[i][j]=(double) 0;
                }

                for(int i=0; i<BlockNumber; i++) {
                        for(int ns=0; ns<para.S+1; ns++)
                        for(int ne=0; ne<para.S+1; ne++)
                        if((oldJ_sys=sup.sysnew_space->IndexOld[ns][J_sysnew[i]])!=-1 && (oldJ_env=sup.envnew_space->IndexOld[ne][J_envnew[i]])!=-1) {
                                for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
                                if(sup.J_sysnew[j]==J_sysnew[i] && sup.J_envnew[j]==J_envnew[i] && sup.J_sys[j]==oldJ_sys && sup.J_env[j]==oldJ_env) {

                                        for(int a_env=0; a_env<sup.env_space->Sys_SubBlockNumber_Jn[oldJ_env]; a_env++)
                                        for(int a_sys=0; a_sys<sup.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]; a_sys++) {
                                                position_old=a_env*sup.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]+a_sys;
                                                position_new=(sup.envnew_space->Start[ne][J_envnew[i]]+a_env)*sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]]+sup.sysnew_space->Start[ns][J_sysnew[i]]+a_sys;//The sequence of loop "a_env" and "a_sys" is important for computation speed!!!
                                                wavefunc_new[i][position_new]=sup.WaveFunction_block[j][position_old];
                                        }
                                }
                        }
		}

	}

	else if(control_number==2) {

		wavefunc_new=new double * [BlockNumber];
		wavefunc_excited_new=new double * [BlockNumber];

		for(int i=0; i<BlockNumber; i++) {
			wavefunc_new[i]=new double [Dim_block[i]];    
			wavefunc_excited_new[i]=new double [Dim_block[i]];

			for(int j=0; j<Dim_block[i]; j++) {
				wavefunc_new[i][j]=(double) 0;   
				wavefunc_excited_new[i][j]=(double) 0;
			}
		}

		for(int i=0; i<BlockNumber; i++) {
			for(int ns=0; ns<para.S+1; ns++)
			for(int ne=0; ne<para.S+1; ne++)
			if((oldJ_sys=sup.sysnew_space->IndexOld[ns][J_sysnew[i]])!=-1 && (oldJ_env=sup.envnew_space->IndexOld[ne][J_envnew[i]])!=-1) {
				for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)
                        	if(sup.J_sysnew[j]==J_sysnew[i] && sup.J_envnew[j]==J_envnew[i] && sup.J_sys[j]==oldJ_sys && sup.J_env[j]==oldJ_env) {

					for(int a_env=0; a_env<sup.env_space->Sys_SubBlockNumber_Jn[oldJ_env]; a_env++)
					for(int a_sys=0; a_sys<sup.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]; a_sys++) {
                                        	position_old=a_env*sup.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]+a_sys;
						position_new=(sup.envnew_space->Start[ne][J_envnew[i]]+a_env)*sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]]+sup.sysnew_space->Start[ns][J_sysnew[i]]+a_sys;//The sequence of loop "a_env" and "a_sys" is important for computation speed!!!
						wavefunc_new[i][position_new]=sup.WaveFunction_block[j][position_old];
						wavefunc_excited_new[i][position_new]=sup.WaveFunction_excited_block[j][position_old];
					}
				}
			}
		}

	}
}

//================================================================================================================
//================================================================================================================
//============================================DenMat_Jacobi_sysnew===============================================
inline void DenMat::DenMat_Jacobi_sysnew(Super &sup, Sub &sysnew) {
  //------Diagonalization by Lapack subroutine dsyev-------------------------------------------------------------
	if(control_number==1) {

                double entropy=0.0;

                FILE *g=fopen(Combine("entanglement/spectrum/sys-ground_state-", sysnew.TotSiteNo), "w+");

                for(int js=0; js<sysnew.Sys_Number_Jn; js++)
                if(sysnew.Sys_SubBlockNumber_Jn[js]!=0) {
                        double constant=(sysnew.Sys_Value_Jn[js]+1.0);

                        Initial_Lapack(sysnew.Sys_SubBlockNumber_Jn[js]);
                        Find_aa_sysnew(sup, js);

                        dsyev_(&jobz, &uplo, &n, a, &lda, w, work, &lwork, &info);

                        for(int i=(sysnew.Sys_SubBlockNumber_Jn[js]-1), it=0; i>=0; i--, it++) {

                                sysnew.dm_eig[js][it]=fabs(w[i]);//w:from small to large, dm_eig: from large to small
				if(fabs(w[i])>1.e-15)
                                entropy+=-fabs(w[i])*log(fabs(w[i]))*constant;

                                fprintf(g, "%d\t", sysnew.Sys_Value_Jn[js]);
                                fprintf(g, "%f\n", -log(fabs(w[i])));

                                for(int j=0; j<sysnew.Sys_SubBlockNumber_Jn[js]; j++)
                                        sysnew.dm_wave[js][it*sysnew.Sys_SubBlockNumber_Jn[js]+j]=a[i*sysnew.Sys_SubBlockNumber_Jn[js]+j];
                        }

                        delete [] a;         delete [] work;      delete [] w;         
                }

                fclose(g);

                FILE *f=fopen("entanglement/entropy/sys-ground_state", "a+"); 
                fprintf(f, "%d\t", sysnew.TotSiteNo);
                fprintf(f, "%f\n", entropy);
                fclose(f);

	}

	else if(control_number==2) {

		double entropy=0.0, entropy_e=0.0;

	        FILE *g=fopen(Combine("entanglement/spectrum/sys-ground_state-", sysnew.TotSiteNo), "w+");
	        FILE *e=fopen(Combine("entanglement/spectrum/sys-excited_state-", sysnew.TotSiteNo), "w+");

	        for(int js=0; js<sysnew.Sys_Number_Jn; js++)
	        if(sysnew.Sys_SubBlockNumber_Jn[js]!=0) {
			double constant=(sysnew.Sys_Value_Jn[js]+1.0)/log(2.0);

                	Initial_Lapack(sysnew.Sys_SubBlockNumber_Jn[js]);
	                Find_aa_sysnew(sup, js);

	                dsyev_(&jobz, &uplo, &n, a, &lda, w, work, &lwork, &info);
			dsyev_(&jobz, &uplo, &n, a_ground, &lda, w_ground, work_ground, &lwork, &info);
			dsyev_(&jobz, &uplo, &n, a_excited, &lda, w_excited, work_excited, &lwork, &info);
		
	                for(int i=(sysnew.Sys_SubBlockNumber_Jn[js]-1), it=0; i>=0; i--, it++) {

	                        sysnew.dm_eig[js][it]=w[i];//w:from small to large, dm_eig: from large to small
	                        entropy+=-fabs(w_ground[i])*log(fabs(w_ground[i]))*constant;
	                        entropy_e+=-fabs(w_excited[i])*log(fabs(w_excited[i]))*constant;

	                        fprintf(g, "%d\t", sysnew.Sys_Value_Jn[js]);
	                        fprintf(g, "%f\n", -log(fabs(w_ground[i])));

	                        fprintf(e, "%d\t", sysnew.Sys_Value_Jn[js]);
	                        fprintf(e, "%f\n", -log(fabs(w_excited[i])));

	                        for(int j=0; j<sysnew.Sys_SubBlockNumber_Jn[js]; j++)
	                                sysnew.dm_wave[js][it*sysnew.Sys_SubBlockNumber_Jn[js]+j]=a[i*sysnew.Sys_SubBlockNumber_Jn[js]+j];
        	        }

               	 	delete [] a;  	     delete [] a_ground;         delete [] a_excited;
			delete [] work;      delete [] work_ground;      delete [] work_excited;   
			delete [] w;	     delete [] w_ground;         delete [] w_excited;
        	}

        	fclose(g);
		fclose(e);

	        FILE *f=fopen("entanglement/entropy/sys-ground_state", "a+");
	        fprintf(f, "%d\t", sysnew.TotSiteNo);
	        fprintf(f, "%f\n", entropy);
	        fclose(f);

	        FILE *b=fopen("entanglement/entropy/sys-excited_state", "a+");
	        fprintf(b, "%d\t", sysnew.TotSiteNo);
	        fprintf(b, "%f\n", entropy_e);
	        fclose(b);

	}
}

//============================================DenMat_Jacobi_envnew===============================================
inline void DenMat::DenMat_Jacobi_envnew(Super &sup, Sub &envnew) {
  //------Diagonalization by Lapack subroutine dsyev-------------------------------------------------------------
	if(control_number==1) {

                double entropy=0.0;

                FILE *g=fopen(Combine("entanglement/spectrum/env-ground_state-", envnew.TotSiteNo), "w+");

                for(int je=0; je<envnew.Sys_Number_Jn; je++)
                if(envnew.Sys_SubBlockNumber_Jn[je]!=0) {
                        double constant=(envnew.Sys_Value_Jn[je]+1.0);

                        Initial_Lapack(envnew.Sys_SubBlockNumber_Jn[je]);
                        Find_aa_envnew(sup, je);

                        dsyev_(&jobz, &uplo, &n, a, &lda, w, work, &lwork, &info);

                        for(int i=(envnew.Sys_SubBlockNumber_Jn[je]-1), it=0; i>=0; i--, it++) {

                                envnew.dm_eig[je][it]=fabs(w[i]);//w: from small to large, dm_eig: from large to small
                                if(fabs(w[i])>1.e-15)
				entropy+=-fabs(w[i])*log(fabs(w[i]))*constant;

                                fprintf(g, "%d\t", envnew.Sys_Value_Jn[je]);
                                fprintf(g, "%f\n", -log(fabs(w[i])));

                                for(int j=0; j<envnew.Sys_SubBlockNumber_Jn[je]; j++)
                                        envnew.dm_wave[je][it*envnew.Sys_SubBlockNumber_Jn[je]+j]=a[i*envnew.Sys_SubBlockNumber_Jn[je]+j];
                        }

                        delete [] a;    delete [] work;      delete [] w;        
                }

                fclose(g);

                FILE *f=fopen("entanglement/entropy/env-ground_state", "a+"); 
                fprintf(f, "%d\t", envnew.TotSiteNo);
                fprintf(f, "%f\n", entropy);
                fclose(f);

	}

	else if(control_number==2) {

	        double entropy=0.0, entropy_e=0.0;

	        FILE *g=fopen(Combine("entanglement/spectrum/env-ground_state-", envnew.TotSiteNo), "w+");
	        FILE *e=fopen(Combine("entanglement/spectrum/env-excited_state-", envnew.TotSiteNo), "w+");

	        for(int je=0; je<envnew.Sys_Number_Jn; je++)
	        if(envnew.Sys_SubBlockNumber_Jn[je]!=0) {
			double constant=(envnew.Sys_Value_Jn[je]+1.0)/log(2.0);

	                Initial_Lapack(envnew.Sys_SubBlockNumber_Jn[je]);
	                Find_aa_envnew(sup, je);

	                dsyev_(&jobz, &uplo, &n, a, &lda, w, work, &lwork, &info);
	                dsyev_(&jobz, &uplo, &n, a_ground, &lda, w_ground, work_ground, &lwork, &info);
        	        dsyev_(&jobz, &uplo, &n, a_excited, &lda, w_excited, work_excited, &lwork, &info);

                	for(int i=(envnew.Sys_SubBlockNumber_Jn[je]-1), it=0; i>=0; i--, it++) {

                       		envnew.dm_eig[je][it]=w[i];//w: from small to large, dm_eig: from large to small
                        	entropy+=-fabs(w_ground[i])*log(fabs(w_ground[i]))*constant;
                 	        entropy_e+=-fabs(w_excited[i])*log(fabs(w_excited[i]))*constant;

                        	fprintf(g, "%d\t", envnew.Sys_Value_Jn[je]);
                        	fprintf(g, "%f\n", -log(fabs(w_ground[i])));

                        	fprintf(e, "%d\t", envnew.Sys_Value_Jn[je]);
                        	fprintf(e, "%f\n", -log(fabs(w_excited[i])));

                        	for(int j=0; j<envnew.Sys_SubBlockNumber_Jn[je]; j++)
                                	envnew.dm_wave[je][it*envnew.Sys_SubBlockNumber_Jn[je]+j]=a[i*envnew.Sys_SubBlockNumber_Jn[je]+j];
                	}

                	delete [] a;         delete [] a_ground;         delete [] a_excited;
			delete [] work;      delete [] work_ground;      delete [] work_excited;
			delete [] w;         delete [] w_ground;         delete [] w_excited;
        	}

	        fclose(g);
		fclose(e);
	
       		FILE *f=fopen("entanglement/entropy/env-ground_state", "a+");
	        fprintf(f, "%d\t", envnew.TotSiteNo);
	        fprintf(f, "%f\n", entropy);
	        fclose(f);

	        FILE *b=fopen("entanglement/entropy/env-excited_state", "a+");
	        fprintf(b, "%d\t", envnew.TotSiteNo);
	        fprintf(b, "%f\n", entropy_e);
	        fclose(b);

	}
}

//================================Initialize parameters for Lapack subroutine dsyev==============================
inline void DenMat::Initial_Lapack(int &Dim) {
	if(control_number==1) {
                jobz='V';       //eigenvalues and eigenvectors are computed
                uplo='U';       //a stores the upper triangular part of A
                n=Dim;          //The order of the matrix A
                lda=Dim;        //The first dimension of the array a
                lwork=40*n;     //The dimension of the array work. Constraint:lwork>=max(1, 3n-1), check work(1)!
                a=new double [lda*n];

                work=new double [lwork];

                w=new double [n];//contains the eigenvalues of the matrix A in ascending order!!!

                for(int i=0; i<lda*n; i++) 
                        a[i]=0.0;    

                for(int i=0; i<lwork; i++) 
                        work[i]=0.0;  

                for(int i=0; i<n; i++) 
                        w[i]=0.0;    

	}

	else if(control_number==2) {
		jobz='V';	//eigenvalues and eigenvectors are computed
		uplo='U';	//a stores the upper triangular part of A
		n=Dim;		//The order of the matrix A
		lda=Dim;	//The first dimension of the array a
		lwork=40*n;	//The dimension of the array work. Constraint:lwork>=max(1, 3n-1), check work(1)!
		a=new double [lda*n];	
		a_ground=new double [lda*n];
		a_excited=new double [lda*n];

		work=new double [lwork];
		work_ground=new double [lwork];
		work_excited=new double [lwork];

		w=new double [n];//contains the eigenvalues of the matrix A in ascending order!!!
		w_ground=new double [n];
		w_excited=new double [n];

		for(int i=0; i<lda*n; i++) {
			a[i]=0.0;	a_ground[i]=0.0;	a_excited[i]=0.0;
		}

		for(int i=0; i<lwork; i++) {
			work[i]=0.0;	work_ground[i]=0.0;	work_excited[i]=0.0;
		}

		for(int i=0; i<n; i++) {
			w[i]=0.0;	w_ground[i]=0.0;	w_excited[i]=0.0;
		}
	}

}

//================Find the matrix elements for each subblocks of the sysnew reduced density matrices=============
inline void DenMat::Find_aa_sysnew(Super &sup, int &js) {
	if(control_number==1) {

                factor=1.0/(sup.sysnew_space->Sys_Value_Jn[js]+1.0);
                for(int i=0; i<BlockNumber; i++)
                if(J_sysnew[i]==js) 
                        dgemm_(&trans_N, &trans_T, &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], &sup.envnew_space->Sys_SubBlockNumber_Jn[J_envnew[i]], &factor, wavefunc_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], wavefunc_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], &beta, a, &sup.sysnew_space->Sys_SubBlockNumber_Jn[js]);

	}

	else if(control_number==2) {

		factor=1.0/(sup.sysnew_space->Sys_Value_Jn[js]+1.0);
		for(int i=0; i<BlockNumber; i++)
		if(J_sysnew[i]==js) {
			dgemm_(&trans_N, &trans_T, &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], &sup.envnew_space->Sys_SubBlockNumber_Jn[J_envnew[i]], &factor, wavefunc_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], wavefunc_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], &beta, a_ground, &sup.sysnew_space->Sys_SubBlockNumber_Jn[js]);

                	dgemm_(&trans_N, &trans_T, &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], &sup.envnew_space->Sys_SubBlockNumber_Jn[J_envnew[i]], &factor, wavefunc_excited_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], wavefunc_excited_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[js], &beta, a_excited, &sup.sysnew_space->Sys_SubBlockNumber_Jn[js]);
		}

		for(int i=0; i<n*n; i++)
			a[i]=(a_ground[i]+a_excited[i])*0.5;

	}
}

//================Find the matrix elements for each subblocks of the envnew reduced density matrices=============
inline void DenMat::Find_aa_envnew(Super &sup, int &je) {
	if(control_number==1) {

                factor=1.0/(sup.envnew_space->Sys_Value_Jn[je]+1.0);
                for(int i=0; i<BlockNumber; i++)
                if(J_envnew[i]==je) 
                        dgemm_(&trans_T, &trans_N, &sup.envnew_space->Sys_SubBlockNumber_Jn[je], &sup.envnew_space->Sys_SubBlockNumber_Jn[je], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]], &factor, wavefunc_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]], wavefunc_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]], &beta, a, &sup.envnew_space->Sys_SubBlockNumber_Jn[je]);

	}

	else if(control_number==2) {

		factor=1.0/(sup.envnew_space->Sys_Value_Jn[je]+1.0);
		for(int i=0; i<BlockNumber; i++)
		if(J_envnew[i]==je) {
			dgemm_(&trans_T, &trans_N, &sup.envnew_space->Sys_SubBlockNumber_Jn[je], &sup.envnew_space->Sys_SubBlockNumber_Jn[je], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]], &factor, wavefunc_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]], wavefunc_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]], &beta, a_ground, &sup.envnew_space->Sys_SubBlockNumber_Jn[je]);

	                dgemm_(&trans_T, &trans_N, &sup.envnew_space->Sys_SubBlockNumber_Jn[je], &sup.envnew_space->Sys_SubBlockNumber_Jn[je], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]], &factor, wavefunc_excited_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]], wavefunc_excited_new[i], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew[i]], &beta, a_excited, &sup.envnew_space->Sys_SubBlockNumber_Jn[je]);
		}

		for(int i=0; i<n*n; i++) {
			a[i]=(a_ground[i]+a_excited[i])*0.5;
			a[i]=a_ground[i];
		}

	}
}

//===================================================Free Space==================================================
inline void DenMat::FreeSpace() {
	if(control_number==1) {

                for(int i=0; i<BlockNumber; i++) 
                        delete [] wavefunc_new[i];    
                delete [] wavefunc_new;          

                delete [] J_sysnew;       delete [] J_envnew;   delete [] Dim_block;

	}

	else if(control_number==2) {

		for(int i=0; i<BlockNumber; i++) {
			delete [] wavefunc_new[i];	delete [] wavefunc_excited_new[i];
		}
		delete [] wavefunc_new;			delete [] wavefunc_excited_new;

		delete [] J_sysnew;       delete [] J_envnew;   delete [] Dim_block;
	
	}
}

//===============================================================================================================
DenMat::~DenMat() {}
//===================================================END==========================================================
