#include<iostream>
#include<fstream>
#include<stdio.h>
#include<stdlib.h>
#include<iomanip>
#include<time.h>
#include<math.h>
#include<gsl/gsl_sf_coupling.h>
using namespace std;

#include"sub.h"
#include"super.h"
#include"superenergy.h"
#include"common.h"
//=================================================BLAS ROUTINES=================================================
extern "C" {
void daxpy_(const int *n, double *alpha, double *x, const int *incx, double *y, const int *incy);

void dgemm_(char *transa, char *transb, const int *m, const int *n, const int *k, const double *alpha, double *a, const int *lda, double *b, const int *ldb, const double *beta, double *c, const int *ldc);
}
//===============================================================================================================
//========================================DPJDREVCOM subroutine of JADAMILU======================================
extern "C" {
void dpjdrevcom_(int *N, double *A, int *JA, int *IA, double *EIGS, double *RES, double *X, int *LX, int *NEIG, double *SIGMA, int *ISEARCH, int *NINIT, int *MADSPACE, int *ITER, double *TOL, double *SHIFT, double *DROPTOL, double *MEM, int *ICNTL, int *IJOB, int *NDX1, int *NDX2, int *IPRINT, int *INFO, double *GAP);

void dpjdcleanup_();    //dpjd* use the same clean up subroutine!!!
}
//===============================================================================================================
//===============================================================================================================

//================================================================================================================
//==============================Diagonalizing the Hamiltonian in infinite sweep===================================
SuperEnergy::SuperEnergy(Parameter &para, Super &sup_space, Super &sup, const double &lan_precision):Conjugate(sup.Dim) {
	time_t start, end;
	time (&start);

	if(sup.Dim<400)	
	SupConjugate(sup_space, sup);
  //------DPJDREVCOM diagonalization:in infinite sweep, no initial guess function is used------------------------
//	DPJDREVCOM_Parameter(sup, 0);	//"0" indicates no initial guess wave function
//	DPJDREVCOM(para, sup_space, sup);
	else {
		Davidson_Parameter(0, sup, lan_precision);
		Davidson(para, sup_space, sup);
	}

	time (&end);
	FILE *LOG=fopen("LOG", "a+");
	fprintf(LOG, "Dimension of the diagonalizing Hamiltonian is %ld\n", sup.Dim);
//	fprintf(LOG, "MAT-VEC iteration step is %ld\n", ITER);
        fprintf(LOG, "Time for diagonalization is %f\n", difftime(end, start));
//	fprintf(LOG, "Time for each MAT-VEC step is %f\n", difftime(end, start)/ITER);
	fprintf(LOG, "********************************************************");
        fprintf(LOG, "\n\n");
        fclose(LOG);
}

//=================Diagonalizing the Hamiltonian in finite sweep for the start point in each sweep===============
SuperEnergy::SuperEnergy(Parameter &para, Super &sup_space, Super &sup, const int &n, const double &lan_precision):Conjugate(sup.Dim) {
	time_t start, end;
	time (&start);

	Davidson_Parameter(1, sup, lan_precision);
//	DPJDREVCOM_Parameter(sup, 1);

	if(n==1) {
		FILE *fp=fopen(Combine(Combine("truncated_wave_function/", n), sup.sys->TotSiteNo+1), "rb");
        	fread(&X[0], sizeof(double), sup.Dim, fp);
//		fread(&X[sup.Dim], sizeof(double), sup.Dim, fp);
		fclose(fp);
	}

	else if(n==2) {
		FILE *fp=fopen(Combine(Combine("truncated_wave_function/", n), sup.env->TotSiteNo+1), "rb");
                fread(&X[0], sizeof(double), sup.Dim, fp);
//		fread(&X[sup.Dim], sizeof(double), sup.Dim, fp);
        	fclose(fp);
	}

	Davidson(para, sup_space, sup);
//	DPJDREVCOM(para, sup_space, sup);

	time (&end);
	FILE *LOG=fopen("LOG", "a+");
	fprintf(LOG, "Dimension of the diagonalizing Hamiltonian is %ld\n", sup.Dim);
//	fprintf(LOG, "MAT-VEC iteration step is %ld\n", ITER);
	fprintf(LOG, "Time for diagonalization is %f\n", difftime(end, start));
//	fprintf(LOG, "Time for each MAT-VEC step is %f\n", difftime(end, start)/ITER);
	fprintf(LOG, "********************************************************");
	fprintf(LOG, "\n\n");
	fclose(LOG);
}

//==============================Diagonalizing the Hamiltonian in finite sweep====================================
SuperEnergy::SuperEnergy(Parameter &para, Super &sup_space, Super &sup, char *direction, const double &lan_precision):Conjugate(sup.Dim) {
	time_t start, end;
	time (&start);

  //------Wave function transformations and initial guess wave function for diagonalization----------------------
  	trans_N='N';	trans_T='T';
	alpha=1.0;	beta=0.0;

  	if(direction=="left")		Initialtrialfunction_Right_to_Left(para, sup_space);
	else if(direction=="right")	Initialtrialfunction_Left_to_Right(para, sup_space);

  //------DPJDREVCOM diagonalization in finite sweep: using initial guess wave function--------------------------
	Davidson_Parameter(1, sup, lan_precision);
//	DPJDREVCOM_Parameter(sup, 1);
	
	for(int i=0; i<sup.BlockNumber_for_TargetSpin; i++)
	for(int j=0; j<sup.Dim_block[i]; j++) {
		X[sup.Table_2to1[i][j]]=sup_space.WaveFunction_block[i][j];
//		X[sup.Dim+sup.Table_2to1[i][j]]=sup_space.WaveFunction_excited_block[i][j];
	}

	Davidson(para, sup_space, sup);
//	DPJDREVCOM(para, sup_space, sup);
//	SupConjugate(sup_space, sup);

  //------Davidson diagonalization in finite sweep---------------------------------------------------------------
	time (&end);
	FILE *LOG=fopen("LOG", "a+");
	fprintf(LOG, "Dimension of the diagonalizing Hamiltonian is %ld\n", sup.Dim);
//	fprintf(LOG, "MAT-VEC iteration step is %ld\n", ITER);
	fprintf(LOG, "Time for diagonalization is %f\n", difftime(end, start));
//	fprintf(LOG, "Time for each MAT-VEC step is %f\n", difftime(end, start)/ITER);
	fprintf(LOG, "********************************************************");
	fprintf(LOG, "\n\n");
	fclose(LOG);
}

//================================================================================================================
//	Diagonalization Method: 1.Conjugate method, 2.Davidson method, 3.Jacobi-Davidson method
//================================================================================================================
//==============================1.Diagonalizing the Hamiltonian by the conjugate method===========================
//================================================================================================================
inline void SuperEnergy::SupConjugate(Super &sup_space, Super &sup) {
	int j;
        for(j=0; j<500; j++) {  //"500" see conjugate::abc_2(iter)
                if(j==0)  sup.H_V(f0, f1, sup.Dim) ; // f1 = H f0 //f1 = 0 ,f0 = sqrt(1./Dim) ;
                if(abc_2(j)) break;
                sup.H_V(f2, f3, sup.Dim); // f3 = H f2
                abc_4();
        }

	eigenvalue=eng;
//	eigenvalue_excited=eng;
        sup.NormalizedCopy(f0, sup_space.WaveFunction);

	for(int i=0; i<sup.Dim; i++)
		sup_space.WaveFunction_block[sup.Table_1to2_Num[i]][sup.Table_1to2_Site[i]]=sup_space.WaveFunction[i];

	cout<<"\n Energy="<<eigenvalue/(2*sup_space.sysnew_space->TotSiteNo)<<endl;
}

//================================================================================================================
//==============================2.Diagonalizing the Hamiltonian by the Davidson method============================
//================================================================================================================
inline void SuperEnergy::Davidson_Parameter(const int &sign, Super &sup, const double &lan_precision) {
	n=sup.Dim;
	eigennum=1;
        input=0;
        maxiteration=200;

        if(sign==0) {minibase=12; totalbase=36; precision=lan_precision;}
        else if(sign==1) {minibase=2;  totalbase=12; precision=lan_precision;}

        EIGS=new double [10];

        X=new double [n];

        if(sign==0) {
                double sum=0.0;
                for(int j=0; j<n; j++) {
                        double s=drand48();
                        sum+=s*s;
                        X[j]=s;   
                }

                sum=1.0/sqrt(sum);
                for(int j=0; j<n; j++) {
                        X[j]*=sum;  
                }
        }
/*
        X=new double [2*n];

        if(sign==0) {
                double sum=0.0;
                for(int j=0; j<n; j++) {
                        double s=drand48();
                        sum+=s*s;
                        X[j]=s;      X[j+n]=s;
                }

                sum=1.0/sqrt(sum);
                for(int j=0; j<n; j++) {
			X[j]*=sum;      X[j+n]*=sum;
		}
        }
*/
}

//===============================================================================================================
inline void SuperEnergy::Davidson(Parameter &para, Super &sup_space, Super &sup) {
	FILE *e=fopen("e/iteration_step", "a+");
        fprintf(e, "%d\t", para.total_site);
        fclose(e);

        sup.diagonalizeLSMatrix(n, eigennum, precision, totalbase, minibase, maxiteration, input, X, EIGS);

        sup.NormalizedCopy(&X[0], sup_space.WaveFunction);
//	sup.NormalizedCopy(&X[n], sup_space.WaveFunction_excited);

	eigenvalue=EIGS[0];
//	eigenvalue_excited=EIGS[1];

	cout<<"\n E(0)="<<EIGS[0]<<endl;//"\t E(1)="<<EIGS[1]<<endl;

	for(int i=0; i<sup.Dim; i++) {
                sup_space.WaveFunction_block[sup.Table_1to2_Num[i]][sup.Table_1to2_Site[i]]=sup_space.WaveFunction[i];
//                sup_space.WaveFunction_excited_block[sup.Table_1to2_Num[i]][sup.Table_1to2_Site[i]]=sup_space.WaveFunction_excited[i];		
	}

	delete [] EIGS;		delete [] X;
}

//================================================================================================================//==============================3.Diagonalizing the Hamiltonian by the Jacobi-Davidson method=====================//================================================================================================================
inline void SuperEnergy::DPJDREVCOM_Parameter(Super &sup, const int &ninit) {
  //------Int type input variants--------------------------------------------------------------------------------
	N=sup.Dim;      //Dimension of the diagonalized matrix.
	NEIG=2;         //(input/output) On input, the number of eigenvalue(s) to be computed; On output, the number of eigenvalues effectively computed with the required accuracy.
	ISEARCH=0;      //(input) If ISEARCH<=0: compute the smallest eigenvalues; if ISEARCH=1: compute the smallest eigenvalues and use SIGMA as initial guess; if ISEARCH>=2: compute the eigenvalues closest to SIGMA.
	NINIT=ninit;	//(input) Number of initial guess(es) provided. May be set to 0: no initial guess.
	MADSPACE=20;    //(input) Maximal dimension of the search space (usually between 10 and 20). At least 2!
	ITER=1000;      //(input/output) On input, the maximum number of matrix vector multiplications; On output, actual number of matrix vector multiplications.
	IJOB=0;         //(input/output) Input: one should use IJOB=0 on the first call, and leave IJOB unchanged on subsequent calls; Output: IJOB=0: work done-terminate.
	IPRINT=1;       //(input) If zero: only error messages are printed on standard output; if negative, extensive information is provided; most users should be satisfied with the information provided for positive IPRINT. Thedefault value of IPRINT is 6, which refers to the standard output. If, instead, IPRINT is set to a positive number(different from 5), the information is printed in the file with unit number equal to the indicated value.
	LX=N*(3*MADSPACE+NEIG+1)+4*MADSPACE*MADSPACE;   //(input) Dimension of X. Should be at least N*(2*MADSPACE+NEIG+4)+3*MADSPACE**2+MAX(MADSPACE**2, NEIG). If MADSPACE>=3, use LX not smaller than N*(3*MADSPACE+NEIG+1)+3*MADSPACE**2+MAX(MADSPACE**2,NEIG) to guarantee optimal performance.
	cout<<"\n LX="<<LX<<endl;
//---------------------------------------------------------------------------------------------------------------

  //------Int type input arrays----------------------------------------------------------------------------------
	ICNTL=new int [5];
	for(int i=0; i<5; i++)
		ICNTL[i]=0;     //Initialize and default settings. (input/output) ICNTL(1) should be set to zero (default value), except if X overwrites he arrays in A, JA, IA, in which case one should set ICNTL(1)=2
	JA=new int [1];         //If a diagonal preconditioning is wanted, one should set JA(1) negative, then JA does not need to have a length greater than 1.
	JA[0]=-1;               //JA(1) is negative to set the diagonal preconditioning.
//	IA=new int [1];         //IA is neither referenced when setting a diagonal preconditioning.
//---------------------------------------------------------------------------------------------------------------

  //------Double type input--------------------------------------------------------------------------------------
	SIGMA=0.0;      //(input) If ISEARCH<=0: not used; if ISEARCH=1: estimation of the smallest eigenvalue; ifISEARCH>=2: the "target" for the computed eigenvalues.

	FILE *f=fopen("control_file/tolerance", "r+");
	fscanf(f, "%lf\n", &TOL);
	fclose(f);

//	TOL=1.e-2;     //(input) The tolerance on residual norm. Iterations to compute eigenvector number i are stopped whenever ||A*x(i)-EIGS(i)*x(i)||<=TOL, where ||x(i)||=1.

	SHIFT=0.0;      //(input/output) used only if ISEARCH=1.
//	DROPTOL=1.e-8;  //(input/output) On input, drop tolerance for the multilevel incomplete factorization. A small drop tolerance will typically lead to more fill-in, i.e. more memory will be consumed and the application of the preconditioner is more costly. On the other hand, the number of iteration steps is expected to be less for a smaller drop tolerance. On output: suggested new value for the DROPTOL parameter. In the case of diagonal preconditioning, DROPTOL is not referenced.
//	MEM=20.0;       //(input) MEM prescribes the amount of memory the user is willing to spend for the preconditioner. MEM is relative to the number of nonzero of the input matrix. If it turns out the preconditioner that is computed does not fit into the memory area that is offered by the user, it will terminate with an error message. In this case one can either increase MEM or one has to increase DROPTOL. In the case of diagonal preconditioning, MEM is not referenced.
//---------------------------------------------------------------------------------------------------------------

  //------Double type input arrays-------------------------------------------------------------------------------
	A=new double [N];               //A contains the diagonal elements of the preconditioning matrix.
	for(int i=0; i<N; i++)  
		A[i]=0.0;

	X=new double [LX];
//	for(int i=0; i<LX; i++)
//		X[i]=(double) 0;        //(input/output+workspace) On input, the initial guess (not required, see NINIT) On output, the iterated approximate eigenvectors. On output (input), approximate eigenvector number i is stored in X(1+N*(i-1):N*i), for i=1,...,NEIG (for i=1,...,NINIT).

	EIGS=new double [NEIG];         //(input/output) On input, eigenvalue estimates corresponding to provided initial guesses, used only if NINIT>(MADSPACE+1)/2 to make sure that initial approximate eigenvectors are processed in the right order. If NINIT>(MADSPACE+1)/2, initial approximations should be in stored in increasing order of eigenvalues if ISEARCH<=1, or in increasing distance of eigenvalues to SIGMA if ISEARCH>=2. On output, eigenvalues as they are computed.

	RES=new double [NEIG];          //(output) Residual norms: RES(i)=||A*x(i)-EIGS(i)*x(i)||.
//---------------------------------------------------------------------------------------------------------------
  //------Output-------------------------------------------------------------------------------------------------
//	INFO: If INFO=0, normal termination; INFO>0: allowed maximum number of matrix vector multiplications performed without finding all wanted eigenvalues; INFO<0: an error occurred.
//	NDX1, NDX2: Indicate indices into X() for the needed MATVEC when IJOB=1.
//	GAP: The estimated distance between the set of NEIG computed eigenvalues and the remaining part of the spectrum; may be inaccurate!!!
//---------------------------------------------------------------------------------------------------------------
}

//===============================================================================================================
inline void SuperEnergy::DPJDREVCOM(Parameter &para, Super &sup_space, Super &sup) {
  //------The subroutines to make the eigenvalue problem by Jacobi-Davidson method-------------------------------
	sup.getMatrixDiagElement(A, N);

	dpjdrevcom_(&N, A, JA, IA, EIGS, RES, X, &LX, &NEIG, &SIGMA, &ISEARCH, &NINIT, &MADSPACE, &ITER, &TOL, &SHIFT, &DROPTOL, &MEM, ICNTL, &IJOB, &NDX1, &NDX2, &IPRINT, &INFO, &GAP);

	while(IJOB==1) {
	sup.H_V(&X[NDX1-1], &X[NDX2-1], N);
		dpjdrevcom_(&N, A, JA, IA, EIGS, RES, X, &LX, &NEIG, &SIGMA, &ISEARCH, &NINIT, &MADSPACE, &ITER, &TOL, &SHIFT, &DROPTOL, &MEM, ICNTL, &IJOB, &NDX1, &NDX2, &IPRINT, &INFO, &GAP);
	}

	sup.NormalizedCopy(&X[0], sup_space.WaveFunction);
//	sup.NormalizedCopy(&X[N], sup_space.WaveFunction_excited);
	
	for(int i=0; i<sup.Dim; i++) {
		sup_space.WaveFunction_block[sup.Table_1to2_Num[i]][sup.Table_1to2_Site[i]]=sup_space.WaveFunction[i];
//                sup_space.WaveFunction_excited_block[sup.Table_1to2_Num[i]][sup.Table_1to2_Site[i]]=sup_space.WaveFunction_excited[i];
	}

	cout<<"\n E(0)="<<EIGS[0]<<"\t Iteration Step="<<ITER<<endl;
//	cout<<"\n E(0)="<<EIGS[0]<<"\t E(1)="<<EIGS[1]<<"\t Iteration Step="<<ITER<<endl;

//	FILE *e=fopen("e/iteration_step", "a+");
//	fprintf(e, "%d\t", para.total_site);
  //      fprintf(e, "%ld\n", ITER);
//        fclose(e);

	eigenvalue=EIGS[0];
//	eigenvalue_excited=EIGS[1];
	
	dpjdcleanup_();

	delete [] ICNTL;	delete [] JA;	delete [] A;	delete [] X;	delete [] EIGS;	delete [] RES;
}
//================================================================================================================//================================================================================================================//================================================================================================================


//================================================================================================================//================================================================================================================//		Wave function transformations and initializing the trial function for diagonalization
//===============================================================================================================
inline void SuperEnergy::Initialtrialfunction_Left_to_Right(Parameter &para, Super &sup_space) {
	time_t start, end;
	time (&start);

//------Second transformation from (sys, ns+envtrun) to (sys+ns, envtrun)-----------------------------------------
//Transform (Block_sys[n+1], S[n+2]+Block_env[n+3]) to (Block_sys[n+1]+S[n+2], Block_env[n+3])
  //------Transformed wave function(Block_sys[n+1]+S[n+2], Block_env[n+3])----------------------------------------
    //------Read envtrun:Block_env[n+3]---------------------------------------------------------------------------
	FILE *fp=fopen(Combine(Combine("truncated_density_eigenvector/", 2), sup_space.env_space->TotSiteNo+1), "rb");
	fread(&truncated_Sys_Number_Jn, sizeof(int), 1, fp);

	truncated_Sys_Value_Jn=new int [truncated_Sys_Number_Jn];
	truncated_Sys_SubBlockNumber_Jn=new int [truncated_Sys_Number_Jn];
	truncated_density_dim=new int [truncated_Sys_Number_Jn];

	fread(truncated_Sys_Value_Jn, sizeof(int), truncated_Sys_Number_Jn, fp);
	fread(truncated_Sys_SubBlockNumber_Jn, sizeof(int), truncated_Sys_Number_Jn, fp);
	fread(truncated_density_dim, sizeof(int), truncated_Sys_Number_Jn, fp);

	truncated_density_eigenvector=new double * [truncated_Sys_Number_Jn];
	for(int i=0; i<truncated_Sys_Number_Jn; i++) {
		truncated_density_eigenvector[i]=new double [truncated_density_dim[i]];
		for(int j=0; j<truncated_density_dim[i]; j++)
			truncated_density_eigenvector[i][j]=(double) 0;
	}

	for(int i=0; i<truncated_Sys_Number_Jn; i++)
		fread(truncated_density_eigenvector[i], sizeof(double), truncated_density_dim[i], fp);
	fclose(fp);

    //------Create space for the transformed wave function:(Block_sys[n+1]+S[n+2], Block_env[n+3])----------------
    //Block_sys[n+1]+S[n+2]==sup.Block_sysnew, "truncated-" here indicate the transformed quantities--------------
    	truncated_block_number=0;
	for(int j_sysnew=0; j_sysnew<sup_space.sysnew_space->Sys_Number_Jn; j_sysnew++)//Block_sys[n+1]+S[n+2]
	for(int j_envtrun=0; j_envtrun<truncated_Sys_Number_Jn; j_envtrun++) {//Block_env[n+3]
		J_min=abs(sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]-truncated_Sys_Value_Jn[j_envtrun]);
		J_max=sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]+truncated_Sys_Value_Jn[j_envtrun];
		J_num=(J_max-J_min)/2+1;
		for(int n=0; n<J_num; n++)
		if(para.Total_j==J_min+2*n) {
			for(int j_s=0; j_s<para.S+1; j_s++)
			if(sup_space.sysnew_space->IndexOld[j_s][j_sysnew]!=-1)
				truncated_block_number++;
		}
	}

    //------Create space for the angular numbers of the transformed blocks---------------------------------------
	J_trun=new int [truncated_block_number];//J_trun=Block_env[n+3]:truncated-(Sys_Number_Jn,Sys_Value_Jn,..)
	J_old=new int [truncated_block_number];//J_old=Block_sys[n+1]:sup.sys->(Sys_Number_Jn,Sys_Value_Jn,...)
	J_new=new int [truncated_block_number];//J_new=Block_sys[n+1]+S[n+2]:sup.sysnew->(Sys_Number_Jn,...)
	truncated_block_dim=new int [truncated_block_number];//truncated_block_dim=Dim.Block_env[n+3]*Dim.Block_sys[n+1]
	for(int i=0; i<truncated_block_number; i++) {
		J_trun[i]=0;	J_old[i]=0;	J_new[i]=0;	truncated_block_dim[i]=0;
	}

    //------Initialize the values of the above angular numbers---------------------------------------------------
	index=0;
	for(int j_sysnew=0; j_sysnew<sup_space.sysnew_space->Sys_Number_Jn; j_sysnew++)
	for(int j_envtrun=0; j_envtrun<truncated_Sys_Number_Jn; j_envtrun++) {
		J_min=abs(sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]-truncated_Sys_Value_Jn[j_envtrun]);
		J_max=sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]+truncated_Sys_Value_Jn[j_envtrun];
		J_num=(J_max-J_min)/2+1;
		for(int n=0; n<J_num; n++)
		if(para.Total_j==J_min+2*n) {
			for(int j_s=0; j_s<para.S+1; j_s++)
			if((oldJ_sys=sup_space.sysnew_space->IndexOld[j_s][j_sysnew])!=-1) {
				J_trun[index]=j_envtrun;     J_old[index]=oldJ_sys;     J_new[index]=j_sysnew;
				truncated_block_dim[index++]=sup_space.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]*truncated_Sys_SubBlockNumber_Jn[j_envtrun];
			}
		}
	}

    //------Create space for the transformed wave function-------------------------------------------------------
    	truncated_wave_function=new double * [truncated_block_number];
//        truncated_wave_function_excited=new double * [truncated_block_number];

    	for(int i=0; i<truncated_block_number; i++) {
		truncated_wave_function[i]=new double [truncated_block_dim[i]];
//                truncated_wave_function_excited[i]=new double [truncated_block_dim[i]];

		for(int j=0; j<truncated_block_dim[i]; j++) {
			truncated_wave_function[i][j]=(double) 0;
//                        truncated_wave_function_excited[i][j]=(double) 0;
		}
	}
  //-------------------------------------------------------------------------------------------------------------

  //------Wave function that to be transformed: read from the truncated wave function in the last step------------
  //(Block_sys[n+1], S[n+2]+Block_env[n+3]), obtained from the last step
    //------Create space for the initial wave function and read it from the truncated wave function--------------
	FILE *fw=fopen(Combine(Combine("truncated_wave_function/", 1), sup_space.sys_space->TotSiteNo), "rb");
	fread(&untruncated_block_number, sizeof(int), 1, fw);//(Block_sys[n+1], S[n+2]+Block_env[n+3])
	
	J_envnew_untrun=new int [untruncated_block_number];//J_envnew_untrun==S[n+2]+Block_env[n+3]
	J_sys_untrun=new int [untruncated_block_number];   //J_sys_untrun==Block_sys[n+1]
	J_env_untrun=new int [untruncated_block_number];   //J_env_untrun==Block_env[n+3]
	untruncated_block_dim=new int [untruncated_block_number];//Dim==Dim.J_sys_untrun*Dim.J_env_untrun	

	fread(J_sys_untrun, sizeof(int), untruncated_block_number, fw);
	fread(J_env_untrun, sizeof(int), untruncated_block_number, fw);
	fread(J_envnew_untrun, sizeof(int), untruncated_block_number, fw);
	fread(untruncated_block_dim, sizeof(int), untruncated_block_number, fw);

	untruncated_wave_function=new double * [untruncated_block_number];
//        untruncated_wave_function_excited=new double * [untruncated_block_number];

	for(int i=0; i<untruncated_block_number; i++) {
		untruncated_wave_function[i]=new double [untruncated_block_dim[i]];
//                untruncated_wave_function_excited[i]=new double [untruncated_block_dim[i]];

		for(int j=0; j<untruncated_block_dim[i]; j++) {
			untruncated_wave_function[i][j]=(double) 0;
//                        untruncated_wave_function_excited[i][j]=(double) 0;
		}
	}

	for(int i=0; i<untruncated_block_number; i++)
		fread(untruncated_wave_function[i], sizeof(double), untruncated_block_dim[i], fw);

//        for(int i=0; i<untruncated_block_number; i++)
//                fread(untruncated_wave_function_excited[i], sizeof(double), untruncated_block_dim[i], fw);

	fclose(fw);

    //------Read in the block spin value of S[n+2]+Block_env[n+3]------------------------------------------------
	FILE *fr=fopen(Combine(Combine("new_block/", 2), sup_space.envnew_space->TotSiteNo+1), "rb");
        fread(&new_Sys_Number_Jn, sizeof(int), 1, fr);

	new_Sys_Value_Jn=new int [new_Sys_Number_Jn];	//Sys_Value_Jn of S[n+2]+Block_env[n+3]

        fread(new_Sys_Value_Jn, sizeof(int), new_Sys_Number_Jn, fr);
        fclose(fr);

    //------The 6-j coefficient for the basis transformation in this step----------------------------------------
   	six_j_basis_transformation=new double * [truncated_block_number];//First index indicates truncated block
	for(int i=0; i<truncated_block_number; i++) {
		index=0;
		for(int j=0; j<untruncated_block_number; j++)//Second index indicates untruncated block
		if(J_sys_untrun[j]==J_old[i] && J_env_untrun[j]==J_trun[i])//J_env_untrun and J_trun indicate the 
			index++;//same environment block!!! So it is not necessary to judge by Sys_Value_Jn!!!
		six_j_basis_transformation[i]=new double [index];
		for(int n=0; n<index; n++)
			six_j_basis_transformation[i][n]=(double) 0;

		index=0;
		for(int j=0; j<untruncated_block_number; j++)
		if(J_sys_untrun[j]==J_old[i] && J_env_untrun[j]==J_trun[i]) {//Block_sys[n+1] and Block_env[n+3]
			alpha=(para.Total_j+1.0)*sqrt((sup_space.sysnew_space->Sys_Value_Jn[J_new[i]]+1.0)*(new_Sys_Value_Jn[J_envnew_untrun[j]]+1.0));
			for(int m_s=0; m_s<para.S+1; m_s++)//m of S[n+2]
			for(int m_1=0; m_1<sup_space.sys_space->Sys_Value_Jn[J_old[i]]+1; m_1++)//Block_sys[n+1]
			for(int m_3=0; m_3<truncated_Sys_Value_Jn[J_trun[i]]+1; m_3++)//m of Block_env[n+3]
			if((-para.S+2*(m_s+m_1+m_3)-sup_space.sys_space->Sys_Value_Jn[J_old[i]]-truncated_Sys_Value_Jn[J_trun[i]])==para.Total_j) {//Target in the subspace of m_total==the maximal m (para.Total_j)
				six_j_basis_transformation[i][index]+=alpha*pow(-1.0,(sup_space.sysnew_space->Sys_Value_Jn[J_new[i]]-new_Sys_Value_Jn[J_envnew_untrun[j]]+2*sup_space.sys_space->Sys_Value_Jn[J_old[i]]+2*para.Total_j+2*(m_1+m_3)-sup_space.sys_space->Sys_Value_Jn[J_old[i]]-truncated_Sys_Value_Jn[J_trun[i]])/2)*gsl_sf_coupling_3j(sup_space.sysnew_space->Sys_Value_Jn[J_new[i]], truncated_Sys_Value_Jn[J_trun[i]], para.Total_j, -para.S+2*(m_s+m_1)-sup_space.sys_space->Sys_Value_Jn[J_old[i]], -truncated_Sys_Value_Jn[J_trun[i]]+2*m_3, -para.Total_j)*gsl_sf_coupling_3j(sup_space.sys_space->Sys_Value_Jn[J_old[i]], new_Sys_Value_Jn[J_envnew_untrun[j]], para.Total_j, -sup_space.sys_space->Sys_Value_Jn[J_old[i]]+2*m_1, -para.S+2*(m_s+m_3)-truncated_Sys_Value_Jn[J_trun[i]], -para.Total_j)*gsl_sf_coupling_3j(sup_space.sys_space->Sys_Value_Jn[J_old[i]], para.S, sup_space.sysnew_space->Sys_Value_Jn[J_new[i]], -sup_space.sys_space->Sys_Value_Jn[J_old[i]]+2*m_1, -para.S+2*m_s, para.S+sup_space.sys_space->Sys_Value_Jn[J_old[i]]-2*(m_s+m_1))*gsl_sf_coupling_3j(truncated_Sys_Value_Jn[J_trun[i]], para.S, new_Sys_Value_Jn[J_envnew_untrun[j]], -truncated_Sys_Value_Jn[J_trun[i]]+2*m_3, -para.S+2*m_s, para.S+truncated_Sys_Value_Jn[J_trun[i]]-2*(m_s+m_3));
			}
			index++;
		}
	}
  //------------------------------------------------------------------------------------------------------------- 

  //------Transform the wave function from the basis (Block_sys[n+1], S[n+2]+Block_env[n+3]) to (Block_sys[n+1]+
  //S[n+2], Block_env[n+3]): multiply a factor of the 6-j coefficient obtained above-----------------------------
	int inc=1;		//increament index in BLAS subroutine daxpy_()
  	for(int i=0; i<truncated_block_number; i++) {
 		index=0;
		for(int j=0; j<untruncated_block_number; j++)
		if(J_sys_untrun[j]==J_old[i] && J_env_untrun[j]==J_trun[i]) {
			daxpy_(&truncated_block_dim[i], &six_j_basis_transformation[i][index], untruncated_wave_function[j], &inc, truncated_wave_function[i], &inc);
//                        daxpy_(&truncated_block_dim[i], &six_j_basis_transformation[i][index], untruncated_wave_function_excited[j], &inc, truncated_wave_function_excited[i], &inc);
			index++;
		}
	}
  //-------------------------------------------------------------------------------------------------------------

//------Delete the untruncated block quantities to reuse them for the next transformation step-------------------
	for(int i=0; i<untruncated_block_number; i++) {
		delete [] untruncated_wave_function[i];
//                delete [] untruncated_wave_function_excited[i];
	}
	delete [] untruncated_wave_function;		//delete [] untruncated_wave_function_excited;

	delete [] J_envnew_untrun;      delete [] J_sys_untrun;         delete [] J_env_untrun;
	delete [] untruncated_block_dim; 
//---------------------------------------------------------------------------------------------------------------

//------Third wave function transformation: from (Block_sys[n+1]+S[n+2], Block_env[n+3]) to (Block_sys[n+1]+S[n+2]
//, S[n+3]+Block_env[n+4]), which is the last step of transformation to provide the initial guess function for 
//diagonalization. The space for the transformed wave function has been created in Class Super!------------------
  //------Create space for the transformed wave function (use untruncated block quantities)----------------------
    //------Find block number------------------------------------------------------------------------------------
	untruncated_block_number=0;
	for(int j_sysnew=0; j_sysnew<sup_space.sysnew_space->Sys_Number_Jn; j_sysnew++)
	for(int j_envnew=0; j_envnew<sup_space.envnew_space->Sys_Number_Jn; j_envnew++) {
		J_min=abs(sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]-sup_space.envnew_space->Sys_Value_Jn[j_envnew]);
		J_max=sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]+sup_space.envnew_space->Sys_Value_Jn[j_envnew];
		J_num=(J_max-J_min)/2+1;
		for(int n=0; n<J_num; n++)
		if(para.Total_j==J_min+2*n) {
			for(int j_s=0; j_s<para.S+1; j_s++)
	  		if(sup_space.sysnew_space->IndexOld[j_s][j_sysnew]!=-1) 
				untruncated_block_number++;
		}
	}

    //------Create space for angular momentum numbers------------------------------------------------------------
	J_sysnew_untrun=new int [untruncated_block_number];
	J_envnew_untrun=new int [untruncated_block_number];
	J_sys_untrun=new int [untruncated_block_number];
	untruncated_block_dim=new int [untruncated_block_number];

	for(int i=0; i<untruncated_block_number; i++) {
		J_sysnew_untrun[i]=0;	J_envnew_untrun[i]=0;	J_sys_untrun[i]=0;   untruncated_block_dim[i]=0;
	}

    //------Initialize the above angular momentum numbers--------------------------------------------------------
	index=0;
	for(int j_sysnew=0; j_sysnew<sup_space.sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<sup_space.envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]-sup_space.envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]+sup_space.envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                        for(int j_s=0; j_s<para.S+1; j_s++)
                        if((oldJ_sys=sup_space.sysnew_space->IndexOld[j_s][j_sysnew])!=-1) {
				J_sysnew_untrun[index]=j_sysnew;	J_envnew_untrun[index]=j_envnew;	
				J_sys_untrun[index]=oldJ_sys;
				untruncated_block_dim[index++]=sup_space.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]*sup_space.envnew_space->Sys_SubBlockNumber_Jn[j_envnew];
			}
                }
        }

    //------Create space for untruncated_wave_function-----------------------------------------------------------
	untruncated_wave_function=new double * [untruncated_block_number];
//        untruncated_wave_function_excited=new double * [untruncated_block_number];

	for(int i=0; i<untruncated_block_number; i++) {
		untruncated_wave_function[i]=new double [untruncated_block_dim[i]];
//                untruncated_wave_function_excited[i]=new double [untruncated_block_dim[i]];

		for(int j=0; j<untruncated_block_dim[i]; j++) {
			untruncated_wave_function[i][j]=(double) 0;
//                        untruncated_wave_function_excited[i][j]=(double) 0;
		}
	}
  //------------------------------------------------------------------------------------------------------------- 

  //------Wave function transformation from (Block_sys[n+1]+S[n+2], Block_env[n+3]) to (Block_sys[n+1]+S[n+2], 
  //S[n+3]+Block_env[n+4]) by matrix-matrix multiplication------------------------------------------------------- 
	for(int i=0; i<untruncated_block_number; i++)
	for(int j=0; j<truncated_block_number; j++)
	if(J_new[j]==J_sysnew_untrun[i] && truncated_Sys_Value_Jn[J_trun[j]]==sup_space.envnew_space->Sys_Value_Jn[J_envnew_untrun[i]] && J_old[j]==J_sys_untrun[i]) {
		dgemm_(&trans_N, &trans_T, &sup_space.sys_space->Sys_SubBlockNumber_Jn[J_sys_untrun[i]], &sup_space.envnew_space->Sys_SubBlockNumber_Jn[J_envnew_untrun[i]], &truncated_Sys_SubBlockNumber_Jn[J_trun[j]], &alpha, truncated_wave_function[j], &sup_space.sys_space->Sys_SubBlockNumber_Jn[J_sys_untrun[i]], truncated_density_eigenvector[J_trun[j]], &sup_space.envnew_space->Sys_SubBlockNumber_Jn[J_envnew_untrun[i]], &beta, untruncated_wave_function[i], &sup_space.sys_space->Sys_SubBlockNumber_Jn[J_sys_untrun[i]]);

//                dgemm_(&trans_N, &trans_T, &sup_space.sys_space->Sys_SubBlockNumber_Jn[J_sys_untrun[i]], &sup_space.envnew_space->Sys_SubBlockNumber_Jn[J_envnew_untrun[i]], &truncated_Sys_SubBlockNumber_Jn[J_trun[j]], &alpha, truncated_wave_function_excited[j], &sup_space.sys_space->Sys_SubBlockNumber_Jn[J_sys_untrun[i]], truncated_density_eigenvector[J_trun[j]], &sup_space.envnew_space->Sys_SubBlockNumber_Jn[J_envnew_untrun[i]], &beta, untruncated_wave_function_excited[i], &sup_space.sys_space->Sys_SubBlockNumber_Jn[J_sys_untrun[i]]);
	}
  //-------------------------------------------------------------------------------------------------------------

  //------Read from untruncated_wave_function to sup.WaveFunction_block------------------------------------------
	for(int i=0; i<sup_space.BlockNumber_for_TargetSpin; i++)
	for(int j=0; j<untruncated_block_number; j++)
	if(sup_space.J_sysnew[i]==J_sysnew_untrun[j] && sup_space.J_envnew[i]==J_envnew_untrun[j] && sup_space.J_sys[i]==J_sys_untrun[j]) {
		for(int j_e=0; j_e<para.S+1; j_e++)
		if((oldJ_env=sup_space.envnew_space->IndexOld[j_e][J_envnew_untrun[j]])!=-1 && oldJ_env==sup_space.J_env[i]) {
			for(int a_env=0; a_env<sup_space.env_space->Sys_SubBlockNumber_Jn[sup_space.J_env[i]]; a_env++)
			for(int a_sys=0; a_sys<sup_space.sys_space->Sys_SubBlockNumber_Jn[sup_space.J_sys[i]]; a_sys++) {
				position_old=(sup_space.envnew_space->Start[j_e][J_envnew_untrun[j]]+a_env)*sup_space.sys_space->Sys_SubBlockNumber_Jn[sup_space.J_sys[i]]+a_sys;
				position_new=a_env*sup_space.sys_space->Sys_SubBlockNumber_Jn[sup_space.J_sys[i]]+a_sys;
				sup_space.WaveFunction_block[i][position_new]=untruncated_wave_function[j][position_old];
//                                sup_space.WaveFunction_excited_block[i][position_new]=untruncated_wave_function_excited[j][position_old];
			}
		}
	}

//------Delete all the created space------------------------------------------------------------------------------
	for(int i=0; i<truncated_block_number; i++)
		delete [] six_j_basis_transformation[i];
	delete [] six_j_basis_transformation;

	for(int i=0; i<untruncated_block_number; i++) {
		delete [] untruncated_wave_function[i];     //delete [] untruncated_wave_function_excited[i];
	}
	delete [] untruncated_wave_function;		    //delete [] untruncated_wave_function_excited;                

	delete [] J_sysnew_untrun;	delete [] J_envnew_untrun;	delete [] J_sys_untrun;			
	delete [] untruncated_block_dim;				delete [] new_Sys_Value_Jn;

	for(int i=0; i<truncated_block_number; i++) {
		delete [] truncated_wave_function[i];       //delete [] truncated_wave_function_excited[i];
	}
	delete [] truncated_wave_function;	            //delete [] truncated_wave_function_excited;

	delete [] J_trun;	delete [] J_old;	delete [] J_new;	delete [] truncated_block_dim;

	for(int i=0; i<truncated_Sys_Number_Jn; i++) 
		delete [] truncated_density_eigenvector[i];
	delete [] truncated_density_eigenvector;

	delete [] truncated_density_dim;		delete [] truncated_Sys_Value_Jn;		
	delete [] truncated_Sys_SubBlockNumber_Jn;
//---------------------------------------------------------------------------------------------------------------
	time (&end);
	FILE *LOG_e=fopen("LOG", "a+");
        fprintf(LOG_e, "Time for wave function transformation is %f\n", difftime(end, start));
        fprintf(LOG_e, "\n\n");
        fclose(LOG_e);
}

//===============================================================================================================
inline void SuperEnergy::Initialtrialfunction_Right_to_Left(Parameter &para, Super &sup_space) {
	time_t start, end;
	time (&start);

//------Second wave function transformation from (Block_sys[n]+S[n+1], Block_env[n+2]) to (Block_sys[n], S[n+1]+
//Block_env[n+2])------------------------------------------------------------------------------------------------
  //------Transformed wave function for basis space: (Block_sys[n], S[n+1]+Block_env[n+2])-----------------------
    //------Read systrun:Block_sys[n]-------------------------------------------------------------------------
	FILE *fp=fopen(Combine(Combine("truncated_density_eigenvector/", 1), sup_space.sys_space->TotSiteNo+1), "rb");
	fread(&truncated_Sys_Number_Jn, sizeof(int), 1, fp);

	truncated_Sys_Value_Jn=new int [truncated_Sys_Number_Jn];
	truncated_Sys_SubBlockNumber_Jn=new int [truncated_Sys_Number_Jn];
	truncated_density_dim=new int [truncated_Sys_Number_Jn];

	fread(truncated_Sys_Value_Jn, sizeof(int), truncated_Sys_Number_Jn, fp);
	fread(truncated_Sys_SubBlockNumber_Jn, sizeof(int), truncated_Sys_Number_Jn, fp);
	fread(truncated_density_dim, sizeof(int), truncated_Sys_Number_Jn, fp);

	truncated_density_eigenvector=new double * [truncated_Sys_Number_Jn];
	for(int i=0; i<truncated_Sys_Number_Jn; i++) {
		truncated_density_eigenvector[i]=new double [truncated_density_dim[i]];
		for(int j=0; j<truncated_density_dim[i]; j++)
			truncated_density_eigenvector[i][j]=(double) 0;
	}

	for(int i=0; i<truncated_Sys_Number_Jn; i++)
		fread(truncated_density_eigenvector[i], sizeof(double), truncated_density_dim[i], fp);
	fclose(fp);

    //-------Create space for the transformed wave function:(Block_sys[n], S[n+1]+Block_env[n+2])----------------
    //S[n+1]+Block_env[n+2]==sup.Block_envnew, "truncated-" here indicate the transformed quantities-------------
    	truncated_block_number=0;
	for(int j_systrun=0; j_systrun<truncated_Sys_Number_Jn; j_systrun++)//Block_sys[n]
	for(int j_envnew=0; j_envnew<sup_space.envnew_space->Sys_Number_Jn; j_envnew++) {
		J_min=abs(sup_space.envnew_space->Sys_Value_Jn[j_envnew]-truncated_Sys_Value_Jn[j_systrun]);
		J_max=sup_space.envnew_space->Sys_Value_Jn[j_envnew]+truncated_Sys_Value_Jn[j_systrun];
		J_num=(J_max-J_min)/2+1;
		for(int n=0; n<J_num; n++)
		if(para.Total_j==J_min+2*n) {
			for(int j_e=0; j_e<para.S+1; j_e++)
			if(sup_space.envnew_space->IndexOld[j_e][j_envnew]!=-1)
				truncated_block_number++;
		}
	}

    //------Create space for the angular numbers of the transformed blocks---------------------------------------
	J_trun=new int [truncated_block_number];//J_trun=Block_sys[n]:truncated-(Sys_Number_Jn,Sys_Value_Jn,..)
	J_old=new int [truncated_block_number];//J_old=Block_env[n+2]:sup.env->(Sys_Number_Jn,Sys_Value_Jn,...)
	J_new=new int [truncated_block_number];//J_new=S[n+1]+Block_env[n+2]:sup.envnew->(Sys_Number_Jn,...)
	truncated_block_dim=new int [truncated_block_number];//truncated_block_dim=Dim.Block_env[n+2]*Dim.Block_sys[n]
	for(int i=0; i<truncated_block_number; i++) {
		J_trun[i]=0;    J_old[i]=0;     J_new[i]=0;     truncated_block_dim[i]=0;
	}

    //------Initialize the values of the above angular numbers---------------------------------------------------
	index=0;
	for(int j_systrun=0; j_systrun<truncated_Sys_Number_Jn; j_systrun++)//Block_sys[n]
	for(int j_envnew=0; j_envnew<sup_space.envnew_space->Sys_Number_Jn; j_envnew++) {
		J_min=abs(sup_space.envnew_space->Sys_Value_Jn[j_envnew]-truncated_Sys_Value_Jn[j_systrun]);
		J_max=sup_space.envnew_space->Sys_Value_Jn[j_envnew]+truncated_Sys_Value_Jn[j_systrun];
		J_num=(J_max-J_min)/2+1;
		for(int n=0; n<J_num; n++)
		if(para.Total_j==J_min+2*n) {
			for(int j_e=0; j_e<para.S+1; j_e++)
			if((oldJ_env=sup_space.envnew_space->IndexOld[j_e][j_envnew])!=-1) {
				J_trun[index]=j_systrun;     J_old[index]=oldJ_env;	J_new[index]=j_envnew;
				truncated_block_dim[index++]=sup_space.env_space->Sys_SubBlockNumber_Jn[oldJ_env]*truncated_Sys_SubBlockNumber_Jn[j_systrun];
			}
                }
        }

    //------Create space for the transformed wave function-------------------------------------------------------
	truncated_wave_function=new double * [truncated_block_number];
//        truncated_wave_function_excited=new double * [truncated_block_number];

	for(int i=0; i<truncated_block_number; i++) {
		truncated_wave_function[i]=new double [truncated_block_dim[i]];
//		truncated_wave_function_excited[i]=new double [truncated_block_dim[i]];

		for(int j=0; j<truncated_block_dim[i]; j++) {
			truncated_wave_function[i][j]=(double) 0;
//                        truncated_wave_function_excited[i][j]=(double) 0;
		}
	}
    //-----------------------------------------------------------------------------------------------------------

  //------Wave function that to be transformed: read from the truncated wave function in the last step-----------
  //(Block_sys[n]+S[n+1], Block_env[n+2]), obtained from the last step
    //------Create space for the initial wave function and read it from the truncated wave function--------------
	FILE *fw=fopen(Combine(Combine("truncated_wave_function/", 2), sup_space.env_space->TotSiteNo), "rb");
        fread(&untruncated_block_number, sizeof(int), 1, fw);//(Block_sys[n]+S[n+1], Block_env[n+2])
        
	J_env_untrun=new int [untruncated_block_number];   //J_env_untrun==Block_env[n+2]
        J_sys_untrun=new int [untruncated_block_number];   //J_sys_untrun==Block_sys[n]
	J_sysnew_untrun=new int [untruncated_block_number];//J_sysnew_untrun==S[n+1]+Block_sys[n] 
        untruncated_block_dim=new int [untruncated_block_number];//Dim==Dim.J_sys_untrun*Dim.J_env_untrun       

        fread(J_env_untrun, sizeof(int), untruncated_block_number, fw);
        fread(J_sys_untrun, sizeof(int), untruncated_block_number, fw);
        fread(J_sysnew_untrun, sizeof(int), untruncated_block_number, fw);
        fread(untruncated_block_dim, sizeof(int), untruncated_block_number, fw);

        untruncated_wave_function=new double * [untruncated_block_number];
//        untruncated_wave_function_excited=new double * [untruncated_block_number];

        for(int i=0; i<untruncated_block_number; i++) {
                untruncated_wave_function[i]=new double [untruncated_block_dim[i]];
//                untruncated_wave_function_excited[i]=new double [untruncated_block_dim[i]];

                for(int j=0; j<untruncated_block_dim[i]; j++) {
                        untruncated_wave_function[i][j]=(double) 0;
//                        untruncated_wave_function_excited[i][j]=(double) 0;
		}
        }

	for(int i=0; i<untruncated_block_number; i++)
		fread(untruncated_wave_function[i], sizeof(double), untruncated_block_dim[i], fw);

//        for(int i=0; i<untruncated_block_number; i++)
//                fread(untruncated_wave_function_excited[i], sizeof(double), untruncated_block_dim[i], fw);

	fclose(fw);

    //------Read in the block spin value of Block_sys[n]+S[n+1]--------------------------------------------------
	FILE *fr=fopen(Combine(Combine("new_block/", 1), sup_space.sysnew_space->TotSiteNo+1), "rb");
	fread(&new_Sys_Number_Jn, sizeof(int), 1, fr);
	new_Sys_Value_Jn=new int [new_Sys_Number_Jn];   //Sys_Value_Jn of Block_sys[n]+S[n+1]
	fread(new_Sys_Value_Jn, sizeof(int), new_Sys_Number_Jn, fr);
	fclose(fr);

    //------The 6-j coefficient for the basis transformation in this step----------------------------------------
	six_j_basis_transformation=new double * [truncated_block_number];//First index indicates truncated block
	for(int i=0; i<truncated_block_number; i++) {
		index=0;
		for(int j=0; j<untruncated_block_number; j++)  //Second index indicates untruncated block
		if(J_sys_untrun[j]==J_trun[i] && J_env_untrun[j]==J_old[i])
			index++;
		six_j_basis_transformation[i]=new double [index];
		for(int n=0; n<index; n++)
			six_j_basis_transformation[i][n]=(double) 0;

		index=0;
		for(int j=0; j<untruncated_block_number; j++)
		if(J_sys_untrun[j]==J_trun[i] && J_env_untrun[j]==J_old[i]) {
			alpha=(para.Total_j+1.0)*sqrt((sup_space.envnew_space->Sys_Value_Jn[J_new[i]]+1.0)*(new_Sys_Value_Jn[J_sysnew_untrun[j]]+1.0));
			for(int m_s=0; m_s<para.S+1; m_s++)// m of S[n+1]
			for(int m_n=0; m_n<truncated_Sys_Value_Jn[J_trun[i]]+1; m_n++) // m of Block_sys[n]
			for(int m_2=0; m_2<sup_space.env_space->Sys_Value_Jn[J_old[i]]+1; m_2++)//Block_env[n+2]
			if((-para.S+2*(m_s+m_n+m_2)-truncated_Sys_Value_Jn[J_trun[i]]-sup_space.env_space->Sys_Value_Jn[J_old[i]])==para.Total_j) {//Target in the subspace of m_total==the maximal m (para.Total_j)
				six_j_basis_transformation[i][index]+=alpha*pow(-1.0,(-sup_space.envnew_space->Sys_Value_Jn[J_new[i]]+new_Sys_Value_Jn[J_sysnew_untrun[j]]+2*truncated_Sys_Value_Jn[J_trun[i]]+2*para.Total_j+2*(m_n+m_2)-sup_space.env_space->Sys_Value_Jn[J_old[i]]-truncated_Sys_Value_Jn[J_trun[i]])/2)*gsl_sf_coupling_3j(truncated_Sys_Value_Jn[J_trun[i]], sup_space.envnew_space->Sys_Value_Jn[J_new[i]], para.Total_j, -truncated_Sys_Value_Jn[J_trun[i]]+2*m_n, -para.S+2*(m_s+m_2)-sup_space.env_space->Sys_Value_Jn[J_old[i]], -para.Total_j)*gsl_sf_coupling_3j(new_Sys_Value_Jn[J_sysnew_untrun[j]], sup_space.env_space->Sys_Value_Jn[J_old[i]], para.Total_j, -para.S+2*(m_s+m_n)-truncated_Sys_Value_Jn[J_trun[i]], -sup_space.env_space->Sys_Value_Jn[J_old[i]]+2*m_2, -para.Total_j)*gsl_sf_coupling_3j(sup_space.env_space->Sys_Value_Jn[J_old[i]], para.S, sup_space.envnew_space->Sys_Value_Jn[J_new[i]], -sup_space.env_space->Sys_Value_Jn[J_old[i]]+2*m_2, -para.S+2*m_s, para.S+sup_space.env_space->Sys_Value_Jn[J_old[i]]-2*(m_s+m_2))*gsl_sf_coupling_3j(truncated_Sys_Value_Jn[J_trun[i]], para.S, new_Sys_Value_Jn[J_sysnew_untrun[j]], -truncated_Sys_Value_Jn[J_trun[i]]+2*m_n, -para.S+2*m_s, para.S+truncated_Sys_Value_Jn[J_trun[i]]-2*(m_s+m_n));
			}
			index++;
		}
	}
  //-------------------------------------------------------------------------------------------------------------

  //------Transform the wave function from the basis (Block_sys[n]+S[n+1], Block_env[n+2]) to (Block_sys[n], 
  //S[n+1]+Block_env[n+2]): multiply a factor of the 6-j coefficient obtained above------------------------------
  	int inc=1;
	for(int i=0; i<truncated_block_number; i++) {
		index=0;
		for(int j=0; j<untruncated_block_number; j++)
		if(J_sys_untrun[j]==J_trun[i] && J_env_untrun[j]==J_old[i]) {
			daxpy_(&truncated_block_dim[i], &six_j_basis_transformation[i][index], untruncated_wave_function[j], &inc, truncated_wave_function[i], &inc);
//                        daxpy_(&truncated_block_dim[i], &six_j_basis_transformation[i][index], untruncated_wave_function_excited[j], &inc, truncated_wave_function_excited[i], &inc);
			index++;
		}
	}
  //--------------------------------------------------------------------------------------------------------------

//------Delete the untruncated block quantities to reuse them for the next transformation step-------------------
	for(int i=0; i<untruncated_block_number; i++) {
		delete [] untruncated_wave_function[i];    //delete [] untruncated_wave_function_excited[i];
	}
	delete [] untruncated_wave_function;               //delete [] untruncated_wave_function_excited;

	delete [] J_sysnew_untrun;      delete [] J_sys_untrun;         delete [] J_env_untrun;
	delete [] untruncated_block_dim;
//---------------------------------------------------------------------------------------------------------------

//------Third wave function transformation: from (Block_sys[n], S[n+1]+Block_env[n+2]) to (Block_sys[n-1]+S[n],
//S[n+1]+Block_env[n+2]), which is the last step of transformation to provide the initial guess function for diag
//-onalization. The space for the transformed wave function has been created in Class Super!----------------------
  //------Create space for the transformed wave function (use untruncated block quantities)----------------------
    //------Find block number------------------------------------------------------------------------------------
	untruncated_block_number=0;
        for(int j_sysnew=0; j_sysnew<sup_space.sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<sup_space.envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]-sup_space.envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]+sup_space.envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                        for(int j_e=0; j_e<para.S+1; j_e++)
                        if(sup_space.envnew_space->IndexOld[j_e][j_envnew]!=-1)
                                untruncated_block_number++;
                }
        }

     //------Create space for angular momentum numbers------------------------------------------------------------
	J_sysnew_untrun=new int [untruncated_block_number];
	J_envnew_untrun=new int [untruncated_block_number];
	J_env_untrun=new int [untruncated_block_number];
	untruncated_block_dim=new int [untruncated_block_number];

	for(int i=0; i<untruncated_block_number; i++) {
		J_sysnew_untrun[i]=0;   J_envnew_untrun[i]=0;   J_env_untrun[i]=0;   untruncated_block_dim[i]=0;
	}

    //------Initialize the above angular momentum numbers--------------------------------------------------------
	index=0;
	for(int j_sysnew=0; j_sysnew<sup_space.sysnew_space->Sys_Number_Jn; j_sysnew++)
	for(int j_envnew=0; j_envnew<sup_space.envnew_space->Sys_Number_Jn; j_envnew++) {
		J_min=abs(sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]-sup_space.envnew_space->Sys_Value_Jn[j_envnew]);
		J_max=sup_space.sysnew_space->Sys_Value_Jn[j_sysnew]+sup_space.envnew_space->Sys_Value_Jn[j_envnew];
		J_num=(J_max-J_min)/2+1;
		for(int n=0; n<J_num; n++)
		if(para.Total_j==J_min+2*n) {
			for(int j_e=0; j_e<para.S+1; j_e++)
			if((oldJ_env=sup_space.envnew_space->IndexOld[j_e][j_envnew])!=-1) {
                                J_sysnew_untrun[index]=j_sysnew;        J_envnew_untrun[index]=j_envnew;
                                J_env_untrun[index]=oldJ_env;
                                untruncated_block_dim[index++]=sup_space.env_space->Sys_SubBlockNumber_Jn[oldJ_env]*sup_space.sysnew_space->Sys_SubBlockNumber_Jn[j_sysnew];
                        }
                }
        }

    //------Create space for untruncated_wave_function-----------------------------------------------------------
	untruncated_wave_function=new double * [untruncated_block_number];
//        untruncated_wave_function_excited=new double * [untruncated_block_number];

	for(int i=0; i<untruncated_block_number; i++) {
		untruncated_wave_function[i]=new double [untruncated_block_dim[i]];
//                untruncated_wave_function_excited[i]=new double [untruncated_block_dim[i]];

		for(int j=0; j<untruncated_block_dim[i]; j++) {
			untruncated_wave_function[i][j]=(double) 0;
//                        untruncated_wave_function_excited[i][j]=(double) 0;
		}
	}
    //-----------------------------------------------------------------------------------------------------------

    //------Wave function transformation from (Block_sys[n], S[n+1]+Block_env[n+2]) to (Block_sys[n-1]+S[n], 
    //S[n+1]+Block_env[n+2]) by matrix-matrix multiplication-----------------------------------------------------
	for(int i=0; i<untruncated_block_number; i++)
	for(int j=0; j<truncated_block_number; j++)
	if(truncated_Sys_Value_Jn[J_trun[j]]==sup_space.sysnew_space->Sys_Value_Jn[J_sysnew_untrun[i]] && J_new[j]==J_envnew_untrun[i]  && J_old[j]==J_env_untrun[i]) { 
		dgemm_(&trans_N, &trans_N, &sup_space.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[i]], &sup_space.env_space->Sys_SubBlockNumber_Jn[J_env_untrun[i]], &truncated_Sys_SubBlockNumber_Jn[J_trun[j]], &alpha, truncated_density_eigenvector[J_trun[j]], &sup_space.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[i]], truncated_wave_function[j], &truncated_Sys_SubBlockNumber_Jn[J_trun[j]], &beta, untruncated_wave_function[i], &sup_space.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[i]]);

//                dgemm_(&trans_N, &trans_N, &sup_space.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[i]], &sup_space.env_space->Sys_SubBlockNumber_Jn[J_env_untrun[i]], &truncated_Sys_SubBlockNumber_Jn[J_trun[j]], &alpha, truncated_density_eigenvector[J_trun[j]], &sup_space.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[i]], truncated_wave_function_excited[j], &truncated_Sys_SubBlockNumber_Jn[J_trun[j]], &beta, untruncated_wave_function_excited[i], &sup_space.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[i]]);
	} 
    //-----------------------------------------------------------------------------------------------------------

    //------Read from untruncated_wave_function to sup.WaveFunction_block----------------------------------------
	for(int i=0; i<sup_space.BlockNumber_for_TargetSpin; i++)
	for(int j=0; j<untruncated_block_number; j++)
	if(sup_space.J_sysnew[i]==J_sysnew_untrun[j] && sup_space.J_envnew[i]==J_envnew_untrun[j] && sup_space.J_env[i]==J_env_untrun[j]) {
                for(int j_s=0; j_s<para.S+1; j_s++)
                if((oldJ_sys=sup_space.sysnew_space->IndexOld[j_s][J_sysnew_untrun[j]])!=-1 && oldJ_sys==sup_space.J_sys[i]) {
                        for(int a_env=0; a_env<sup_space.env_space->Sys_SubBlockNumber_Jn[J_env_untrun[j]]; a_env++)
                        for(int a_sys=0; a_sys<sup_space.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]; a_sys++) {
                                position_old=a_env*sup_space.sysnew_space->Sys_SubBlockNumber_Jn[sup_space.J_sysnew[i]]+sup_space.sysnew_space->Start[j_s][J_sysnew_untrun[j]]+a_sys;
                                position_new=a_env*sup_space.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]+a_sys;
                                sup_space.WaveFunction_block[i][position_new]=untruncated_wave_function[j][position_old];
//                                sup_space.WaveFunction_excited_block[i][position_new]=untruncated_wave_function_excited[j][position_old];
                        }
                }
        }

//------Delete the created space---------------------------------------------------------------------------------
	for(int i=0; i<truncated_block_number; i++)
                delete [] six_j_basis_transformation[i];
        delete [] six_j_basis_transformation;

        for(int i=0; i<untruncated_block_number; i++) {
                delete [] untruncated_wave_function[i];      //delete [] untruncated_wave_function_excited[i];
	}
        delete [] untruncated_wave_function;                 //delete [] untruncated_wave_function_excited;

        delete [] J_sysnew_untrun;      delete [] J_envnew_untrun;      delete [] J_env_untrun;
        delete [] untruncated_block_dim;                                delete [] new_Sys_Value_Jn;

        for(int i=0; i<truncated_block_number; i++) {
                delete [] truncated_wave_function[i];        //delete [] truncated_wave_function_excited[i];
	}
        delete [] truncated_wave_function;                   //delete [] truncated_wave_function_excited;

        delete [] J_trun;       	delete [] J_old;        	delete [] J_new;        
	delete [] truncated_block_dim;

        for(int i=0; i<truncated_Sys_Number_Jn; i++)
                delete [] truncated_density_eigenvector[i];
        delete [] truncated_density_eigenvector;        

	delete [] truncated_density_dim;				delete [] truncated_Sys_Value_Jn;
	delete [] truncated_Sys_SubBlockNumber_Jn;
//---------------------------------------------------------------------------------------------------------------
	time (&end);
	FILE *LOG_e=fopen("LOG", "a+");
        fprintf(LOG_e, "Time for wave function transformation is %f\n", difftime(end, start));
        fprintf(LOG_e, "\n\n");
        fclose(LOG_e);
}

//================================================================================================================//================================================================================================================//To store the density eigenvectors and to perform the first wave function transformation for the guess initial 
//state function in finite sweep. For sysnew:from (Block_sys[n]+S[n+1], S[n+2]+Block_env[n+3]) to (Block_sys[n+1],//S[n+2]+Block_env[n+3]); for envnew:from (Block_sys[n]+S[n+1], S[n+2]+Block_env[n+3]) to (Block_sys[n]+S[n+1],
//Block_env[n+2]).
//================================================================================================================
//==============Truncate wave function and store the truncated density eigenvectors for finite sweep==============
SuperEnergy::SuperEnergy(Parameter &para, Super &sup, Sub &old, Sub &trun, char &direction):Conjugate(sup.Dim) {
	time_t start, end;
	time (&start);

	trans_N='N';	trans_T='T';	alpha=1.0;	beta=0.0;
	if(direction=='r')
		Truncate_sysnew_density_eigenvector(para, sup, old, trun);
	else if(direction=='l')
		Truncate_envnew_density_eigenvector(para, sup, old, trun);

	time (&end);
	FILE *LOG_e=fopen("LOG", "a+");
        fprintf(LOG_e, "Time for saving density matrix and the first function transformation is %f\n", difftime(end, start));
        fprintf(LOG_e, "\n\n");
        fclose(LOG_e);
}

//========================Truncate density eigenvector and wave function:sysnew===================================
inline void SuperEnergy::Truncate_sysnew_density_eigenvector(Parameter &para, Super &sup, Sub &old, Sub &trun) {
//------Create space for truncated_density_eigenvector: valid for both systrun and envtrun------------------------
	truncated_density_dim=new int [trun.Sys_Number_Jn];//Dimension of truncated density eigenvector matrix
	truncated_density_eigenvector=new double * [trun.Sys_Number_Jn];

	for(int i=0; i<trun.Sys_Number_Jn; i++) {
		truncated_density_dim[i]=trun.Sys_SubBlockNumber_Jn[i]*sup.sysnew_space->Sys_SubBlockNumber_Jn[trun.OldSub[i]];//Truncated density eigenvectors are stored in an array with column form from large to small.
		truncated_density_eigenvector[i]=new double [truncated_density_dim[i]];

		for(int j=0; j<truncated_density_dim[i]; j++) 
			truncated_density_eigenvector[i][j]=old.dm_wave[trun.OldSub[i]][j]; 
			//automatically truncate the density eigenvector to store the largest "m" states.

	}
//----------------------------------------------------------------------------------------------------------------

//------Truncate the obtained wave function from (sys+ns,env+ne) to (systrun,env+ne)------------------------------     //------Allocate space for the truncated wave function-------------------------------------------------------
	truncated_block_number=0;

	for(int j_systrun=0; j_systrun<trun.Sys_Number_Jn; j_systrun++)
	for(int j_envnew=0; j_envnew<sup.envnew_space->Sys_Number_Jn; j_envnew++) {
		J_min=abs(trun.Sys_Value_Jn[j_systrun]-sup.envnew_space->Sys_Value_Jn[j_envnew]);
		J_max=trun.Sys_Value_Jn[j_systrun]+sup.envnew_space->Sys_Value_Jn[j_envnew];
		J_num=(J_max-J_min)/2+1;

		for(int n=0; n<J_num; n++)
		if(para.Total_j==J_min+2*n) {
			for(int j_e=0; j_e<para.S+1; j_e++)
			if(sup.envnew_space->IndexOld[j_e][j_envnew]!=-1) 
				truncated_block_number++;	
		}
	}

     //------Create space for the angular indices of the blocks--------------------------------------------------
	J_trun=new int [truncated_block_number];		//J_trun=J_systrun
	J_old=new int [truncated_block_number];			//J_old=J_env
	J_new=new int [truncated_block_number];			//J_new=J_envnew
	truncated_block_dim=new int [truncated_block_number];	//truncated_block_dim=Dim_systrun*Dim_env
	for(int i=0; i<truncated_block_number; i++) {
		J_trun[i]=0;	J_old[i]=0;	J_new[i]=0;	truncated_block_dim[i]=0;
	}

     //------Initialize the values of the above angular indices--------------------------------------------------
	index=0;
     	for(int j_systrun=0; j_systrun<trun.Sys_Number_Jn; j_systrun++)
        for(int j_envnew=0; j_envnew<sup.envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(trun.Sys_Value_Jn[j_systrun]-sup.envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=trun.Sys_Value_Jn[j_systrun]+sup.envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;
                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                        for(int j_e=0; j_e<para.S+1; j_e++)
                        if((oldJ_env=sup.envnew_space->IndexOld[j_e][j_envnew])!=-1) {
				J_trun[index]=j_systrun;	J_old[index]=oldJ_env;
				J_new[index]=j_envnew;	
				truncated_block_dim[index++]=trun.Sys_SubBlockNumber_Jn[j_systrun]*sup.env_space->Sys_SubBlockNumber_Jn[oldJ_env];
			}
                }
        }

     //------Create space for the truncated wave function--------------------------------------------------------
     	truncated_wave_function=new double * [truncated_block_number];

	for(int i=0; i<truncated_block_number; i++) {
    		truncated_wave_function[i]=new double [truncated_block_dim[i]];

		for(int j=0; j<truncated_block_dim[i]; j++) 
			truncated_wave_function[i][j]=(double) 0;
	}
//---------------------------------------------------------------------------------------------------------------

    //------Allocate space for the untruncated wave function: angular numbers J_sys for a given J_sysnew are combined: in order to perform the matrix-matrix multiplication of calculating the truncated wave function-------------
    	untruncated_block_number=0;
	for(int j_sysnew=0; j_sysnew<sup.sysnew_space->Sys_Number_Jn; j_sysnew++)
	for(int j_envnew=0; j_envnew<sup.envnew_space->Sys_Number_Jn; j_envnew++) {
		J_min=abs(sup.sysnew_space->Sys_Value_Jn[j_sysnew]-sup.envnew_space->Sys_Value_Jn[j_envnew]);
		J_max=sup.sysnew_space->Sys_Value_Jn[j_sysnew]+sup.envnew_space->Sys_Value_Jn[j_envnew];
		J_num=(J_max-J_min)/2+1;

		for(int n=0; n<J_num; n++)
		if(para.Total_j==J_min+2*n) {

			for(int j_e=0; j_e<para.S+1; j_e++)
			if(sup.envnew_space->IndexOld[j_e][j_envnew]!=-1) 
				untruncated_block_number++;
		}
	}	
//	cout<<"\n untruncated_block_number="<<untruncated_block_number<<endl;

   //------Create space for the angular numbers of the untruncated blocks----------------------------------------
   	J_sysnew_untrun=new int [untruncated_block_number];
	J_envnew_untrun=new int [untruncated_block_number];
	J_env_untrun=new int [untruncated_block_number];
	untruncated_block_dim=new int [untruncated_block_number];
	for(int i=0; i<untruncated_block_number; i++) {
		J_sysnew_untrun[i]=0;	J_envnew_untrun[i]=0;	J_env_untrun[i]=0;  untruncated_block_dim[i]=0;
	}

   //------Initialize the above angular numbers------------------------------------------------------------------
   	index=0;
   	for(int j_sysnew=0; j_sysnew<sup.sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<sup.envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sup.sysnew_space->Sys_Value_Jn[j_sysnew]-sup.envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sup.sysnew_space->Sys_Value_Jn[j_sysnew]+sup.envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;

                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                        for(int j_e=0; j_e<para.S+1; j_e++)
                        if((oldJ_env=sup.envnew_space->IndexOld[j_e][j_envnew])!=-1) {
                                J_sysnew_untrun[index]=j_sysnew;	J_envnew_untrun[index]=j_envnew;
				J_env_untrun[index]=oldJ_env;	
				untruncated_block_dim[index++]=sup.sysnew_space->Sys_SubBlockNumber_Jn[j_sysnew]*sup.env_space->Sys_SubBlockNumber_Jn[oldJ_env];
			}
                }
        }
//	for(int i=0; i<untruncated_block_number; i++)
//		cout<<"\n J_sysnew_untrun["<<i<<"]="<<J_sysnew_untrun[i]<<"\t J_envnew_untrun["<<i<<"]="<<J_envnew_untrun[i]<<"\t J_env_untrun["<<i<<"]="<<J_env_untrun[i]<<"\t untruncated_block_dim["<<i<<"]="<<untruncated_block_dim[i]<<endl;

   //------Create space for the untruncated function and initialize the untruncated wave function----------------
   	untruncated_wave_function=new double * [untruncated_block_number];

	for(int i=0; i<untruncated_block_number; i++) {
		untruncated_wave_function[i]=new double [untruncated_block_dim[i]];

		for(int j=0; j<untruncated_block_dim[i]; j++) 
			untruncated_wave_function[i][j]=(double) 0;
	}

	for(int i=0; i<untruncated_block_number; i++) {
		for(int ns=0; ns<para.S+1; ns++)
		if((oldJ_sys=sup.sysnew_space->IndexOld[ns][J_sysnew_untrun[i]])!=-1) {
			for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)//find corresponding block
			if(sup.J_sysnew[j]==J_sysnew_untrun[i] && sup.J_envnew[j]==J_envnew_untrun[i] && sup.J_sys[j]==oldJ_sys && sup.J_env[j]==J_env_untrun[i]) {
				for(int a_env=0; a_env<sup.env_space->Sys_SubBlockNumber_Jn[J_env_untrun[i]]; a_env++) 
				for(int a_sys=0; a_sys<sup.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]; a_sys++) {
					position_old=a_env*sup.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys]+a_sys;
					position_new=a_env*sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[i]]+sup.sysnew_space->Start[ns][J_sysnew_untrun[i]]+a_sys;	//position of the elements in the new form of matrix
					untruncated_wave_function[i][position_new]=sup.WaveFunction_block[j][position_old];
				}
			}
		}
	}

//---------------------------------------------------------------------------------------------------------------

    //------Truncate the wave function by matrix-matrix multiplication-------------------------------------------
	for(int j_trun=0; j_trun<truncated_block_number; j_trun++) 	    //truncated wave function block
	for(int j_untrun=0; j_untrun<untruncated_block_number; j_untrun++)  //untruncated wave function block
	if(J_old[j_trun]==J_env_untrun[j_untrun] && J_new[j_trun]==J_envnew_untrun[j_untrun] && trun.OldSub[J_trun[j_trun]]==J_sysnew_untrun[j_untrun]) 
		dgemm_(&trans_T, &trans_N, &trun.Sys_SubBlockNumber_Jn[J_trun[j_trun]], &sup.env_space->Sys_SubBlockNumber_Jn[J_old[j_trun]], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[j_untrun]], &alpha, truncated_density_eigenvector[J_trun[j_trun]], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[j_untrun]], untruncated_wave_function[j_untrun], &sup.sysnew_space->Sys_SubBlockNumber_Jn[J_sysnew_untrun[j_untrun]], &beta, truncated_wave_function[j_trun], &trun.Sys_SubBlockNumber_Jn[J_trun[j_trun]]);

    //------Print the truncated wave function--------------------------------------------------------------------
	FILE *fw=fopen(Combine(Combine("truncated_wave_function/", 1), trun.TotSiteNo), "wb");

	fwrite(&truncated_block_number, sizeof(int), 1, fw);
	fwrite(J_trun, sizeof(int), truncated_block_number, fw);
	fwrite(J_old, sizeof(int), truncated_block_number, fw);
	fwrite(J_new, sizeof(int), truncated_block_number, fw);
	fwrite(truncated_block_dim, sizeof(int), truncated_block_number, fw);

	for(int i=0; i<truncated_block_number; i++) 
		fwrite(truncated_wave_function[i], sizeof(double), truncated_block_dim[i], fw);

	fclose(fw);

  //------Print truncated_density_eigenvector: valid for both systrun and envtrun---------------------------------
  	FILE *fp=fopen(Combine(Combine("truncated_density_eigenvector/", 1), trun.TotSiteNo), "wb");

	fwrite(&trun.Sys_Number_Jn, sizeof(int), 1, fp);
	fwrite(trun.Sys_Value_Jn, sizeof(int), trun.Sys_Number_Jn, fp);
	fwrite(trun.Sys_SubBlockNumber_Jn, sizeof(int), trun.Sys_Number_Jn, fp);
	fwrite(truncated_density_dim, sizeof(int), trun.Sys_Number_Jn, fp);  

	for(int i=0; i<trun.Sys_Number_Jn; i++) 
		fwrite(truncated_density_eigenvector[i], sizeof(double), truncated_density_dim[i], fp);

        fwrite(trun.OldSub, sizeof(int), trun.Sys_Number_Jn, fp);

	fclose(fp);
//----------------------------------------------------------------------------------------------------------------

  //------Delete untruncated and truncated wave function---------------------------------------------------------
	for(int i=0; i<untruncated_block_number; i++) 
		delete [] untruncated_wave_function[i];      	//delete [] untruncated_wave_function_excited[i];
	delete [] untruncated_wave_function;		     	//delete [] untruncated_wave_function_excited;

	delete [] J_sysnew_untrun;	delete [] J_envnew_untrun;	delete [] J_env_untrun;	
	delete [] untruncated_block_dim;

	for(int i=0; i<truncated_block_number; i++) 
		delete [] truncated_wave_function[i];      	//delete [] truncated_wave_function_excited[i];
	delete [] truncated_wave_function;		  	//delete [] truncated_wave_function_excited;

	delete [] J_trun;		delete [] J_old;	delete [] J_new;	delete [] truncated_block_dim;
  //------Delete truncated_density_eigenvector-------------------------------------------------------------------
	for(int i=0; i<trun.Sys_Number_Jn; i++)
		delete [] truncated_density_eigenvector[i];
	delete [] truncated_density_eigenvector;

	delete [] truncated_density_dim;
	delete [] trun.OldSub;
//----------------------------------------------------------------------------------------------------------------
}

//============================Truncated density eigenvector and wave function:envnew==============================
inline void SuperEnergy::Truncate_envnew_density_eigenvector(Parameter &para, Super &sup, Sub &old, Sub &trun) {
//------Create space for truncated_density_eigenvector: valid for both systrun and envtrun------------------------
	truncated_density_dim=new int [trun.Sys_Number_Jn];
	truncated_density_eigenvector=new double * [trun.Sys_Number_Jn];

	for(int i=0; i<trun.Sys_Number_Jn; i++) {
		truncated_density_dim[i]=trun.Sys_SubBlockNumber_Jn[i]*sup.envnew_space->Sys_SubBlockNumber_Jn[trun.OldSub[i]];//Truncated density eigenvectors are stored in an array with eigenvalues from large to small.
		truncated_density_eigenvector[i]=new double [truncated_density_dim[i]];

		for(int j=0; j<truncated_density_dim[i]; j++) 
			truncated_density_eigenvector[i][j]=old.dm_wave[trun.OldSub[i]][j];
	}
//---------------------------------------------------------------------------------------------------------------

//------Truncate the obtained wave function from (sys+ns,env+ne) to (sys+ns+envtrun)----------------------------
     //------Allocate space for the truncated wave function------------------------------------------------------
	truncated_block_number=0;
        for(int j_sysnew=0; j_sysnew<sup.sysnew_space->Sys_Number_Jn; j_sysnew++)
	for(int j_envtrun=0; j_envtrun<trun.Sys_Number_Jn; j_envtrun++) {
                J_min=abs(sup.sysnew_space->Sys_Value_Jn[j_sysnew]-trun.Sys_Value_Jn[j_envtrun]);
                J_max=sup.sysnew_space->Sys_Value_Jn[j_sysnew]+trun.Sys_Value_Jn[j_envtrun];
                J_num=(J_max-J_min)/2+1;

                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                        for(int j_s=0; j_s<para.S+1; j_s++)
                        if(sup.sysnew_space->IndexOld[j_s][j_sysnew]!=-1) 
                                truncated_block_number++;
                }
        }

     //------Create space for the angular indices of the blocks--------------------------------------------------
     	J_trun=new int [truncated_block_number];		//J_trun=J_envtrun
        J_old=new int [truncated_block_number];			//J_old=J_sys
        J_new=new int [truncated_block_number];			//J_new=J_sysnew
        truncated_block_dim=new int [truncated_block_number];	//truncated_block_dim=Dim_envtrun*Dim_sys

        for(int i=0; i<truncated_block_number; i++) {
                J_trun[i]=0;    J_old[i]=0;     J_new[i]=0;     truncated_block_dim[i]=0;
        }

     //------Initialize the values of the above angular indices--------------------------------------------------
     	index=0;
	for(int j_sysnew=0; j_sysnew<sup.sysnew_space->Sys_Number_Jn; j_sysnew++)
	for(int j_envtrun=0; j_envtrun<trun.Sys_Number_Jn; j_envtrun++) {
		J_min=abs(sup.sysnew_space->Sys_Value_Jn[j_sysnew]-trun.Sys_Value_Jn[j_envtrun]);
		J_max=sup.sysnew_space->Sys_Value_Jn[j_sysnew]+trun.Sys_Value_Jn[j_envtrun];
		J_num=(J_max-J_min)/2+1;

                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                        for(int j_s=0; j_s<para.S+1; j_s++)	
                        if((oldJ_sys=sup.sysnew_space->IndexOld[j_s][j_sysnew])!=-1) {
                                J_trun[index]=j_envtrun;        J_old[index]=oldJ_sys;
                                J_new[index]=j_sysnew;
                                truncated_block_dim[index++]=trun.Sys_SubBlockNumber_Jn[j_envtrun]*sup.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys];
                        }
                }
        }

     //------Create space for the truncated wave function--------------------------------------------------------
     	truncated_wave_function=new double * [truncated_block_number];

        for(int i=0; i<truncated_block_number; i++) {
                truncated_wave_function[i]=new double [truncated_block_dim[i]];

                for(int j=0; j<truncated_block_dim[i]; j++) 
                        truncated_wave_function[i][j]=(double) 0;
        }
//---------------------------------------------------------------------------------------------------------------

     //------Allocate space for the untruncated wave function: angular numbers J_env for a given J_envnew are combined: in order to perform the matrix-matrix multiplication of calculating the truncated wave function
	untruncated_block_number=0;
        for(int j_sysnew=0; j_sysnew<sup.sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<sup.envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sup.sysnew_space->Sys_Value_Jn[j_sysnew]-sup.envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sup.sysnew_space->Sys_Value_Jn[j_sysnew]+sup.envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;

                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                        for(int j_s=0; j_s<para.S+1; j_s++)	//oldJ_sys from small to large
                        if(sup.sysnew_space->IndexOld[j_s][j_sysnew]!=-1) 
                                untruncated_block_number++;
                }
        }

     //------Create space for the angular numbers of the untruncated blocks--------------------------------------
 	J_sysnew_untrun=new int [untruncated_block_number];
        J_envnew_untrun=new int [untruncated_block_number];
        J_sys_untrun=new int [untruncated_block_number];
        untruncated_block_dim=new int [untruncated_block_number];

        for(int i=0; i<untruncated_block_number; i++) {
                J_sysnew_untrun[i]=0;   J_envnew_untrun[i]=0;   J_sys_untrun[i]=0;  untruncated_block_dim[i]=0;
        }

     //------Initialize the above angular numbers----------------------------------------------------------------
     	index=0;
     	for(int j_sysnew=0; j_sysnew<sup.sysnew_space->Sys_Number_Jn; j_sysnew++)
        for(int j_envnew=0; j_envnew<sup.envnew_space->Sys_Number_Jn; j_envnew++) {
                J_min=abs(sup.sysnew_space->Sys_Value_Jn[j_sysnew]-sup.envnew_space->Sys_Value_Jn[j_envnew]);
                J_max=sup.sysnew_space->Sys_Value_Jn[j_sysnew]+sup.envnew_space->Sys_Value_Jn[j_envnew];
                J_num=(J_max-J_min)/2+1;

                for(int n=0; n<J_num; n++)
                if(para.Total_j==J_min+2*n) {
                        for(int j_s=0; j_s<para.S+1; j_s++)
                        if((oldJ_sys=sup.sysnew_space->IndexOld[j_s][j_sysnew])!=-1) {
                                J_sysnew_untrun[index]=j_sysnew;	J_envnew_untrun[index]=j_envnew;
				J_sys_untrun[index]=oldJ_sys;
				untruncated_block_dim[index++]=sup.envnew_space->Sys_SubBlockNumber_Jn[j_envnew]*sup.sys_space->Sys_SubBlockNumber_Jn[oldJ_sys];
                        }
                }
        }

     //------Create space for the untruncated function and initialize the untruncated wave function--------------
	untruncated_wave_function=new double * [untruncated_block_number];

        for(int i=0; i<untruncated_block_number; i++) {
                untruncated_wave_function[i]=new double [untruncated_block_dim[i]];

                for(int j=0; j<untruncated_block_dim[i]; j++) 
                        untruncated_wave_function[i][j]=(double) 0;
        }

	for(int i=0; i<untruncated_block_number; i++) {
		for(int ne=0; ne<para.S+1; ne++)
		if((oldJ_env=sup.envnew_space->IndexOld[ne][J_envnew_untrun[i]])!=-1) {
			for(int j=0; j<sup.BlockNumber_for_TargetSpin; j++)//find the block
			if(sup.J_sysnew[j]==J_sysnew_untrun[i] && sup.J_envnew[j]==J_envnew_untrun[i] && sup.J_sys[j]==J_sys_untrun[i] && sup.J_env[j]==oldJ_env) {
				for(int a_env=0; a_env<sup.env_space->Sys_SubBlockNumber_Jn[oldJ_env]; a_env++) 
				for(int a_sys=0; a_sys<sup.sys_space->Sys_SubBlockNumber_Jn[J_sys_untrun[i]]; a_sys++) {
					position_old=a_env*sup.sys_space->Sys_SubBlockNumber_Jn[J_sys_untrun[i]]+a_sys;
					position_new=(sup.envnew_space->Start[ne][J_envnew_untrun[i]]+a_env)*sup.sys_space->Sys_SubBlockNumber_Jn[J_sys_untrun[i]]+a_sys;
					untruncated_wave_function[i][position_new]=sup.WaveFunction_block[j][position_old];
				}
			}
		}
	}
//---------------------------------------------------------------------------------------------------------------

     //------Truncate the wave function by matrix-matrix multiplication------------------------------------------
	for(int j_trun=0; j_trun<truncated_block_number; j_trun++) 	    //truncated wave function block
	for(int j_untrun=0; j_untrun<untruncated_block_number; j_untrun++)  //untruncated wave function block
	if(J_old[j_trun]==J_sys_untrun[j_untrun] && J_new[j_trun]==J_sysnew_untrun[j_untrun] && trun.OldSub[J_trun[j_trun]]==J_envnew_untrun[j_untrun]) 
		dgemm_(&trans_N, &trans_N, &sup.sys_space->Sys_SubBlockNumber_Jn[J_old[j_trun]], &trun.Sys_SubBlockNumber_Jn[J_trun[j_trun]], &sup.envnew_space->Sys_SubBlockNumber_Jn[J_envnew_untrun[j_untrun]], &alpha, untruncated_wave_function[j_untrun], &sup.sys_space->Sys_SubBlockNumber_Jn[J_old[j_trun]], truncated_density_eigenvector[J_trun[j_trun]], &sup.envnew_space->Sys_SubBlockNumber_Jn[J_envnew_untrun[j_untrun]], &beta, truncated_wave_function[j_trun], &sup.sys_space->Sys_SubBlockNumber_Jn[J_old[j_trun]]);

    //------Print the truncated wave function--------------------------------------------------------------------
	FILE *fw=fopen(Combine(Combine("truncated_wave_function/", 2), trun.TotSiteNo), "wb");

        fwrite(&truncated_block_number, sizeof(int), 1, fw);
        fwrite(J_trun, sizeof(int), truncated_block_number, fw);
        fwrite(J_old, sizeof(int), truncated_block_number, fw);
        fwrite(J_new, sizeof(int), truncated_block_number, fw);
        fwrite(truncated_block_dim, sizeof(int), truncated_block_number, fw);

        for(int i=0; i<truncated_block_number; i++) 
                fwrite(truncated_wave_function[i], sizeof(double), truncated_block_dim[i], fw);

        fclose(fw);

    //------Print truncated_density_eigenvector: valid for both systrun and envtrun------------------------------
	FILE *fp=fopen(Combine(Combine("truncated_density_eigenvector/", 2), trun.TotSiteNo), "wb");

        fwrite(&trun.Sys_Number_Jn, sizeof(int), 1, fp);
        fwrite(trun.Sys_Value_Jn, sizeof(int), trun.Sys_Number_Jn, fp);
        fwrite(trun.Sys_SubBlockNumber_Jn, sizeof(int), trun.Sys_Number_Jn, fp);
	fwrite(truncated_density_dim, sizeof(int), trun.Sys_Number_Jn, fp);

        for(int i=0; i<trun.Sys_Number_Jn; i++) 
                fwrite(truncated_density_eigenvector[i], sizeof(double), truncated_density_dim[i], fp);

        fwrite(trun.OldSub, sizeof(int), trun.Sys_Number_Jn, fp);

        fclose(fp);
//---------------------------------------------------------------------------------------------------------------

//------Delete untruncated and truncated wave function-----------------------------------------------------------
	for(int i=0; i<untruncated_block_number; i++) 
                delete [] untruncated_wave_function[i];		//delete [] untruncated_wave_function_excited[i];
        delete [] untruncated_wave_function;			//delete [] untruncated_wave_function_excited;

        delete [] J_sysnew_untrun;      delete [] J_envnew_untrun;      delete [] J_sys_untrun;
        delete [] untruncated_block_dim;

        for(int i=0; i<truncated_block_number; i++) 
                delete [] truncated_wave_function[i];		//delete [] truncated_wave_function_excited[i];
        delete [] truncated_wave_function;			//delete [] truncated_wave_function_excited;

        delete [] J_trun;          delete [] J_old;        delete [] J_new;        delete [] truncated_block_dim;

    //------Delete truncated_density_eigenvector------------------------------------------------------------------
        for(int i=0; i<trun.Sys_Number_Jn; i++)
                delete [] truncated_density_eigenvector[i];
        delete [] truncated_density_eigenvector;

	delete [] truncated_density_dim;
        delete [] trun.OldSub;
}

//===============================================================================================================
//In the end of each finite sweep, the wave function does not need to be truncated, and the truncated density 
//eigenvectors may not be stored, which would not be used
//===============================================================================================================
SuperEnergy::SuperEnergy(Super &sup, Sub &trun, const int &n):Conjugate(sup.Dim) { 
	FILE *fp=fopen(Combine(Combine("truncated_wave_function/", n), trun.TotSiteNo), "wb");
	fwrite(sup.WaveFunction, sizeof(double), sup.Dim, fp);
//	fwrite(sup.WaveFunction_excited, sizeof(double), sup.Dim, fp);
	fclose(fp);

	delete [] trun.OldSub;
}

//=================================================Delete superenergy=============================================
SuperEnergy::~SuperEnergy() {}                                                      
//====================================================END=========================================================
