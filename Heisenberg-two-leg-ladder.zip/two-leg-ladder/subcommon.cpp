#include<iostream>
#include<iomanip>
#include<stdlib.h>
#include<stdio.h>
using namespace std;

#include"subcommon.h"
#include"common.h"
//==================================Initialize the system and environment blocks=================================
SubCommon::SubCommon() {}

//===========================================CreateSpace 1=======================================================
//  				Create Spaces for Jn and number of subblock 
//===============================================================================================================
void SubCommon::CreateSpace1() {
        Sys_Value_Jn=new int [Sys_Number_Jn];           //Spin values of each quantum angular momentum number J, Sys_Value_Jn[J]=2*J
        Sys_SubBlockNumber_Jn=new int [Sys_Number_Jn];
        for(int i=0; i<Sys_Number_Jn; i++) {
                Sys_Value_Jn[i]=0;      Sys_SubBlockNumber_Jn[i]=0;
        }

        if(IndexNo==1) {                                //This part only exists in the adding new site process
                IndexOld=new int *[2];
                Start=new int *[2];
                for(int i=0; i<2; i++) {
                        IndexOld[i]=new int [Sys_Number_Jn]; 
                        Start[i]=new int [Sys_Number_Jn];
                        for(int j=0; j<Sys_Number_Jn; j++) {
                                IndexOld[i][j]=-1;
                                Start[i][j]=0;
                        }
                }
        }
}

//=============================================Create Space H====================================================
void SubCommon::Create_H() {
        H=new double * [Sys_Number_Jn];

        for(int i=0; i<Sys_Number_Jn; i++) {   

		int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i];
                H[i]=new double [Dim];

                for(int j=0; j<Dim; j++) 
                        H[i][j]=(double) 0;

        }
}

//=============================================Create Space S_Dia================================================
void SubCommon::Create_S_Dia() {
        S_Dia=new double ** [operator_number];

        for(int n=0; n<operator_number; n++) {        
                S_Dia[n]=new double * [Sys_Number_Jn];

                for(int i=0; i<Sys_Number_Jn; i++) {    
			int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i];
                        S_Dia[n][i]=new double [Dim];

                        for(int j=0; j<Dim; j++) 
                                S_Dia[n][i][j]=(double) 0;
                 
                }

        }
}

//=============================================Create Space S_M_Dia==============================================
void SubCommon::Create_S_M_Dia() {

	int Sys_Number_Jn_p=Sys_Number_Jn-1;

        S_M_Dia=new double ** [operator_number];

        for(int n=0; n<operator_number; n++) {  
                S_M_Dia[n]=new double * [Sys_Number_Jn_p];

                for(int i=0; i<Sys_Number_Jn_p; i++) {  
			int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i+1];
                        S_M_Dia[n][i]=new double [Dim];

                        for(int j=0; j<Dim; j++) 
                                S_M_Dia[n][i][j]=(double) 0;

                } 

        }
}

//==========================================Create Space 3=======================================================
//              Create Spaces for the eigenvalues and eigenstates of reduced density matrices
//===============================================================================================================
void SubCommon::CreateSpace3() {
        dm_eig=new double * [Sys_Number_Jn];
        dm_wave=new double * [Sys_Number_Jn];

        for(int i=0; i<Sys_Number_Jn; i++) {
		
		int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i];

                dm_eig[i]=new double [Sys_SubBlockNumber_Jn[i]];
                for(int j=0; j<Sys_SubBlockNumber_Jn[i]; j++) 
                        dm_eig[i][j]=(double) 0;

		dm_wave[i]=new double [Dim];
                for(int k=0; k<Dim; k++) 
                        dm_wave[i][k]=(double) 0;

        }
}

//===========================================Print===============================================================
void SubCommon::Print_space(const int &i, const int &lsys) {	

    	FILE *fp=fopen(Combine(Combine("mid/space/", i), lsys), "wb");

        fwrite(&TotSiteNo, sizeof(int), 1, fp);
        fwrite(&Sys_Number_Jn, sizeof(int), 1, fp);
        fwrite(Sys_Value_Jn, sizeof(int), Sys_Number_Jn, fp);
        fwrite(Sys_SubBlockNumber_Jn, sizeof(int), Sys_Number_Jn, fp);

        fclose(fp);

}

//===============================================Print operators=================================================
void SubCommon::Print_operator_H(const int &i, const int &lsys) {

        FILE *fp=fopen(Combine(Combine("mid/operator/", i), lsys), "wb");

        fwrite(&TotSiteNo, sizeof(int), 1, fp);
	fwrite(&operator_number, sizeof(int), 1, fp);
        fwrite(&Sys_Number_Jn, sizeof(int), 1, fp);
        fwrite(Sys_Value_Jn, sizeof(int), Sys_Number_Jn, fp);
        fwrite(Sys_SubBlockNumber_Jn, sizeof(int), Sys_Number_Jn, fp);

	for(int i=0; i<Sys_Number_Jn; i++) {
		int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i];
                fwrite(H[i], sizeof(double), Dim, fp);
	}

	fclose(fp);

}

//===========================================Print_operator_S_Dia================================================
void SubCommon::Print_operator_S_Dia(const int &i, const int &lsys) {

        FILE *fp=fopen(Combine(Combine("mid/operator/", i), lsys), "ab");

        for(int n=0; n<operator_number; n++)
        for(int i=0; i<Sys_Number_Jn; i++) {
		int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i];
                	fwrite(S_Dia[n][i], sizeof(double), Dim, fp);
	}

	fclose(fp);

}

//==========================================Print_operator_S_M_Dia===============================================
void SubCommon::Print_operator_S_M_Dia(const int &i, const int &lsys) {

	int Sys_Number_Jn_p=Sys_Number_Jn-1;

        FILE *fp=fopen(Combine(Combine("mid/operator/", i), lsys), "ab");

        for(int n=0; n<operator_number; n++)
        for(int i=0; i<Sys_Number_Jn_p; i++) {
		int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i+1];
                	fwrite(S_M_Dia[n][i], sizeof(double), Dim, fp);
	}

        fclose(fp);

}

//=====================================Read angular space from hard disk=========================================
SubCommon::SubCommon(char *space, const int &i, const int &lsys) {

        IndexNo=3;	//Only CreateSpace1 with *Sys_Value_Jn and *Sys_SubBlockNumber_Jn

        FILE *fr=fopen(Combine(Combine("mid/space/", i), lsys), "rb");

	fread(&TotSiteNo, sizeof(int), 1, fr);
        fread(&Sys_Number_Jn, sizeof(int), 1, fr);

	CreateSpace1();
        fread(Sys_Value_Jn, sizeof(int), Sys_Number_Jn, fr);
        fread(Sys_SubBlockNumber_Jn, sizeof(int), Sys_Number_Jn, fr);

        fclose(fr);

}

//=========================================Read operator from hard disk==========================================
SubCommon::SubCommon(const int &i, const int &lsys) {

  	IndexNo=0;

        FILE *fr=fopen(Combine(Combine("mid/operator/", i), lsys), "rb");

        fread(&TotSiteNo, sizeof(int), 1, fr);
	fread(&operator_number, sizeof(int), 1, fr);
        fread(&Sys_Number_Jn, sizeof(int), 1, fr);

        CreateSpace1();

        fread(Sys_Value_Jn, sizeof(int), Sys_Number_Jn, fr);
        fread(Sys_SubBlockNumber_Jn, sizeof(int), Sys_Number_Jn, fr);

	Create_H();

  	for(int i=0; i<Sys_Number_Jn; i++) {
		int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i];
       			fread(H[i], sizeof(double), Dim, fr);
	}

	Create_S_Dia(); 

	for(int n=0; n<operator_number; n++)
        for(int i=0; i<Sys_Number_Jn; i++) {
		int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i];
               		fread(S_Dia[n][i], sizeof(double), Dim, fr);
	}
  
	Create_S_M_Dia();

	int Sys_Number_Jn_p=Sys_Number_Jn-1;
	
	for(int n=0; n<operator_number; n++)
       	for(int i=0; i<Sys_Number_Jn_p; i++) {
                int Dim=Sys_SubBlockNumber_Jn[i]*Sys_SubBlockNumber_Jn[i+1];
              		fread(S_M_Dia[n][i], sizeof(double), Dim, fr);
	}

        fclose(fr);

}

//=============================================Delete the calss SubCommon========================================
SubCommon::~SubCommon() {
	if(IndexNo==0) {	//For initialization and truncation
		FreeSpace_H();
		FreeSpace_S_Dia();
		FreeSpace_S_M_Dia();
		FreeSpace1();
	}

	else if(IndexNo==1) {
		FreeSpace1();	//For site increase without creating space for operators
	}

	else if(IndexNo==3) {
		FreeSpace1();
	}

	else if(IndexNo==2) {		//For site increase with creating space for operators

		if(ope_sign=='H')
			FreeSpace_H();

		else if(ope_sign=='S')
			FreeSpace_S_Dia();

		else if(ope_sign=='M')
			FreeSpace_S_M_Dia();

		FreeSpace1();
	}

	else if(IndexNo==4) {
                for(int i=0; i<Sys_Number_Jn; i++) {    //Free space 3
                        delete [] dm_eig[i];   delete [] dm_wave[i];
                }
                delete [] dm_eig;      delete [] dm_wave;

		FreeSpace1();
	}
}

//===============================================Free Space H====================================================
inline void SubCommon::FreeSpace_H() {
        for(int i=0; i<Sys_Number_Jn; i++) 
                delete [] H[i];
        delete [] H;
}

//===============================================Free Space S_Dia================================================
inline void SubCommon::FreeSpace_S_Dia() {
        for(int n=0; n<operator_number; n++) {
                for(int i=0; i<Sys_Number_Jn; i++) {
                        delete [] S_Dia[n][i];
                }
        delete [] S_Dia[n];
        }
        delete [] S_Dia;
}

//===============================================Free Space S_M_Dia==============================================
inline void SubCommon::FreeSpace_S_M_Dia() {
        int Sys_Number_Jn_p=Sys_Number_Jn-1;

        for(int n=0; n<operator_number; n++) {
                for(int i=0; i<Sys_Number_Jn_p; i++) {
                        delete [] S_M_Dia[n][i];
                }
        delete [] S_M_Dia[n];
        }
        delete [] S_M_Dia;
}

//==============================================Free Space 1=====================================================
inline void SubCommon::FreeSpace1() {
        if(IndexNo==1) {
                for(int i=0; i<2; i++) {
                        delete [] IndexOld[i];  delete [] Start[i];
                }
                delete [] IndexOld;     delete [] Start;
        }

        delete [] Sys_Value_Jn;
        delete [] Sys_SubBlockNumber_Jn;
}
//=====================================================END=======================================================
