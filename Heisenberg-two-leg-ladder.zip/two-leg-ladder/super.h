#include "LSMatrixDiagonalization.h"

class Super:public LSMatrixDiagonalization {

public:
  //------Construct the space for wave function blocks
	Super(Parameter &para, Sub *sys_space1, Sub *env_space1, Sub *sysnew_space1, Sub *envnew_space1);

	Sub *sys_space;
	Sub *env_space;
	Sub *sysnew_space;
	Sub *envnew_space;

  //------Construct the space for diagonalization
	Super(char *iteration, Parameter &para, Sub *sys1, Sub *env1, Super &space);

	Sub *sys;
	Sub *env;
	
	int Dim;
	int BlockNumber_for_TargetSpin;

	int *J_sys, *J_env, *J_sysnew, *J_envnew, *Dim_block;

        int *Table_1to2_Num;
        int *Table_1to2_Site;
        int **Table_2to1;

	double *WaveFunction;
	double *WaveFunction_excited;
	double **WaveFunction_block;
	double **WaveFunction_excited_block;

  //------For diagonalization
        int BlockNumber_for_TargetSpin_config_3;
        int *J_sys_config_3, *J_env_config_3, *J_sysnew_config_3, *J_envnew_config_3, *Dim_block_config_3;

        double *six_j_1_sys_n;
        double *six_j_1_e_env;
        double **nine_j_config_2;

        double **six_j_1_config_3;
        double *six_j_1_config_3_diaele;
        double *six_j_2_config_3;
        double **nine_j_config_3;
        double **nine_j_config_3_inverse;

        void getMatrixDiagElement(double *f, const int &dim);
	void H_V(const double *f, double *g, const int &dim);
        void NormalizedCopy(const double *f1, double *f2);

        Super(Sub *sys_space1, Sub *env_space1, Sub *sysnew_space1, Sub *envnew_space1, Parameter &para);

	~Super();	//Delete super functions

private:

	int control_number, QuantumNumber;

	int N, StartSite, inc, index, SiteNum, site_s, site_e, dimension;
        int operator_number_sys, operator_number_env;
	int Dim_config_3;

	char destruct, side_L, side_R, uplo, trans_N, trans_T;

        double beta, alpha_p, beta_p, alpha;
	double J_n, J_nn, J_nnn;

        int *Table, *Table_sys, *Table_env;
	double *Interaction;

	double **f1;
	double **g1;
	double **f2;
	double **g2;
	double **f3;
	double **g3;
	
	double **S_Dia_sys;
	double **S_M_Dia_sys;
	double **S_Dia_env;
	double **S_M_Dia_env;

	inline void AllocateBlockNumber(Parameter &para);
	inline void AllocateBlockNumber_config_3(Parameter &para);

      	inline void Allocate_6j_config_1_2(Parameter &para, Super &space);
	inline void Allocate_9j_config_2(Parameter &para, Super &space);
	inline void Allocate_6j_config_3(Parameter &para);
	inline void Allocate_9j_config_3(Parameter &para, Super &space);

	inline void H_Sys_and_Env();
	inline void H_Sys_Ns();
	inline void H_Ne_Env();
	inline void H_Sys_Ne();
	inline void H_Ns_Env();
	inline void H_Ns_Ne();
	inline void H_Sys_Env();
};	
