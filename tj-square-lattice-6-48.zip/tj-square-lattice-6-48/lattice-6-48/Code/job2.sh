#!/bin/bash
#SBATCH -p G1Part_vip08
#SBATHC -N 1
#SBATCH -n 1
#SBATCH -c 10
source /es01/paratera/parasoft/module.sh
module load mpi/intel/18
module load gsl/2.4
srun DMRG_test
